//Si en combo de Contacto se selecciona (otro) reci�n se puede ingresar nombre
function fxValidateChangeContact() {
   if ((document.frmdatos.cmbContContact.value=="") || (document.frmdatos.cmbContContact.value!=0)) {
      document.frmdatos.txtContTelephone1.value="";
      document.frmdatos.txtContTelephone2.value="";
      document.frmdatos.txtContName.value="";
      document.frmdatos.txtContLastName.value="";
      document.frmdatos.txtContName.readOnly=true;
      document.frmdatos.txtContLastName.readOnly=true;
   }
   else {
      document.frmdatos.txtContName.readOnly=false;
      document.frmdatos.txtContLastName.readOnly=false;
   }
}


function fxTimeFieldValid(timeField) {
   timeStr = timeField.value;
   if ( timeStr == "" ) return true;
   if ( !IsValidTime(timeStr) ) {
      timeField.focus();
      timeField.select();
      return false;
   }
   return true;
}


function fxMakeDpto(name) {
   this.name = name;
   this.length = 0;
}
         
function fxNewDpto(name, id) {
   DptosIndex++
   ProvsIndex = -1;
   distIndex=-1;
   Dptos[DptosIndex] = new fxMakeDpto(name);
   codigo[DptosIndex] = new fxMakeDpto(id);
}

function fxCargarProvs(cat) {
   for (var i = document.frmdatos.cmbContDistrict.options.length; i > 0; i--) document.frmdatos.cmbContDistrict.options[i] = null;
   document.frmdatos.cmbContDistrict.selectedIndex=0;
   fxRelateProvs(cat);
}
         
function fxRelateProvs(cat) {
   with (document.frmdatos.cmbContProvince) {
      for (var i = options.length; i > 0; i--) options[i] = null;
      if (cat > 0) {
         DptosIndex = cat - 1;
         for (var i = 0; i < Dptos[DptosIndex].length; i++) options[i + 1] = new Option(Dptos[DptosIndex][i].name);
         for (var i = 0; i < Dptos[DptosIndex].length; i++) options[i + 1].value = (codigo[DptosIndex][i].name);
         options[0].selected = true;
      }
   }
   ProvsIndex = 0;
}
         
function fxMakeProv(name) {
   this.name = name;
   this.length = 0;
}

function fxNewProv(name, id) {
   ProvsIndex++;
   distIndex=-1;
   Dptos[DptosIndex][ProvsIndex] = new fxMakeProv(name);
   Dptos[DptosIndex].length++;
   codigo[DptosIndex][ProvsIndex] = new fxMakeProv(id);
   codigo[DptosIndex].length++;
}
         
function fxMakeDist(name) {
   this.name = name;
}

function fxNewDist(name, id) {
   distIndex++;
   Dptos[DptosIndex][ProvsIndex][distIndex] = new fxMakeDist(name);
   Dptos[DptosIndex][ProvsIndex].length++;
   codigo[DptosIndex][ProvsIndex][distIndex] = new fxMakeDist(id);
   codigo[DptosIndex][ProvsIndex].length++;
}
         
function fxCargarDist(cat) {
   with (document.frmdatos.cmbContDistrict) {
      for (var i = options.length; i > 0; i--) options[i] = null;
      if (cat > 0) {
         ProvsIndex = cat - 1;
         for (var i = 0; i < Dptos[DptosIndex][ProvsIndex].length; i++) options[i + 1] = new Option(Dptos[DptosIndex][ProvsIndex][i].name);
         for (var i = 0; i < Dptos[DptosIndex][ProvsIndex].length; i++) options[i + 1].value = (codigo[DptosIndex][ProvsIndex][i].name);
        options[0].selected = true;
      }
  }
  distIndex = 0;
}


function fxMakeSubject(id, descr, level) {
   this.id = id;
   this.descr = descr;
   this.level = level;
}


function fxLoadRootSubject() {
   var subjObj = null;
   var j = 0;
   with (document.frmdatos.cmbContSubject1) {
      for (i=0; i < subjArr.length ; i++) {
         subjObj = subjArr[i];
         if (subjObj.level == "0") {
            options[j+1] = new Option(subjObj.descr, subjObj.id);
            j++;
         }
      }
      options[0].selected = true;
   }
}
         
function fxLoadChildSubject(rootSubjId) {
   var subjObj = null;
   var j = 0;
   var i = 0;
   with (document.frmdatos.cmbContSubject2) {
      for (i = options.length; i > 0; i--) options[i] = null;
      for (i = 0; i < subjArr.length ; i++) {
         subjObj = subjArr[i];
         if (subjObj.id == 8) continue;
         if (subjObj.level == rootSubjId) {
            options[j+1] = new Option(subjObj.descr, subjObj.id);
            j++;
         }
      }
      options[0].selected = true;
   }
}



//Pop up de representantes
function fxListRepresentative(formname, textname, hiddenname){
   var url="";
   url = "/portal/pls/portal/WEBSALES.NP_CONTACT_NEW_PL_PKG.PL_CONT_REPRESENT_SEARCH?av_formname=" + formname + "&av_textname=" + textname + "&av_hiddenname=" + hiddenname+ "&av_searchtype=";
   WinAsist = window.open(url,"WinAsist","toolbar=no,location=0,directories=no,status=yes,menubar=0,scrollbars=no,resizable=no,screenX=100,top=80,left=100,screenY=80,width=550,height=520,modal=yes");
}
         
//Obtiene valores de la direcci�n seleccionada
function fxvalidateAddress() {
   url="/portal/pls/portal/WEBSALES.NP_CONTACT_NEW_PL_PKG.PL_GET_ADDRESS?"
   	+"an_addressid="+document.frmdatos.hdnContAddress.value;
   parent.bottomFrame.location.replace( url );
}


function fxMakeMedio(id,name,addressallowed,contactnumbergenerate,confregisterallowed,mandatorycontactphone,defaultmediastatusid,contactsubtypeallowed,defaultcontactsubtypeid,motiveallowed,contacttype,contactdescmaxlength,sendtypeallowed,vstatus,vsubtype) {
   this.id  = id;
   this.name = name;
   this.npaddressallowed = addressallowed;
   this.npcontactnumbergenerate = contactnumbergenerate;
   this.npconfirmregisterallowed = confregisterallowed;
   this.npmandatorycontactphone = mandatorycontactphone;
   this.npdefaultmediastatusid = defaultmediastatusid;
   this.npcontactsubtypeallowed = contactsubtypeallowed;
   this.npdefaultcontactsubtypeid = defaultcontactsubtypeid;
   this.npmotiveallowed = motiveallowed;
   this.npcontacttype = contacttype;
   this.npcontactdescmaxlength = contactdescmaxlength;
   this.npsendtypeallowed = sendtypeallowed;
   this.vstatus = vstatus;
   this.vsubtype = vsubtype;
}
         
function fxMakeStatus(id,name,datehoursatartallowed,datehourstartcalc,hourendallowed,datehourendcalc,meaning) {
   this.id = id;
   this.name = name;
   this.npdatehourstartallowed = datehoursatartallowed;
   this.npdatehourstartcalc = datehourstartcalc;
   this.nphourendallowed = hourendallowed;
   this.npdatehourendcalc = datehourendcalc;
   this.npmeaning = meaning;
}

function fxMakeSubtype(id,name,nptag1,maximum) {
   this.id = id;
   this.name = name;
   this.nptag1 = nptag1;
   this.maxquantity = maximum;
}

function fxMakeMotive(id,name,vsubmotive) {
   this.id = id;
   this.name = name;
   this.vsubmotive = vsubmotive;
}


function fxMakeSubMotive(id,name,associatedspeech) {
   this.id = id;
   this.name = name;
   this.npassociatedspeech = associatedspeech;
}

     
//Si se elige opci�n de �ltimo contacto no aparece para creaci�n de uno nuevo
function fxValidateLastContact() {
   if (document.frmdatos.cmbContLastContact.value!="") {
      div_table.style.display="none";
   }
   else {
      div_table.style.display="";
   }
}




function fxValidateText(objeto,etiqueta, min, max){
/*
Objetive: 	Validar la cadena dentro de un textarea.
Input:		-objeto: Nombre del objeto. Ej. frmFormulario.txtNombre
		-etiqueta: Cadena con el nombre de la etiqueta o label del Textarea.
		-min: Cantidad m�nima de caracteres. Con el valor 0 se acepta que el input este vac�o
		-max: Cantidad m�xima de caracteres.
Output:		-true
-false
*/
   var strAlertMessage;
   var bolResult= true;
   var valTextoSimple = /^.*$/;
   if (objeto.value.length < min){
      strAlertMessage = "El campo \"" + etiqueta + "\" debe tener como m�nimo " + min + " caracteres";
      bolResult = false;
   }
   else if (objeto.value.length > max){
      strAlertMessage = "El campo \"" + etiqueta + "\" debe tener como m�ximo " + max + " caracteres";
      bolResult = false;
   }


   if (bolResult == false) {
      alert(strAlertMessage);
      objeto.select();
      objeto.focus();
      return (false);
   }

   return (true);
}


function makePage(campaignpageid,pagename,pageurl) {
   this.id  = campaignpageid;
   this.name = pagename;
   this.url = pageurl;
}


function makeCategory(campaignpagecategoryid,category,Vpages) {
   this.id  = campaignpagecategoryid;
   this.name = category;
   this.vpages = Vpages;
}


//Obtiene valor del campo descripci�n para un nuevo contacto
function fxValidateNewMotive(index) {
   if (document.frmdatos.cmbContSubMotive.value!=""){
      for(j=0;j<Vmedias.size();j++) {
         objMedio = Vmedias.elementAt(j);
         if (objMedio.id == document.frmdatos.cmbContMedia.value){
            ArrMotives = objMedio.vmotive;
            for(k=0;k<ArrMotives.size();k++) {
               objMotive = ArrMotives.elementAt(k);
               if (objMotive.id==document.frmdatos.cmbContMotive.value){
                  ArrSubMotives = objMotive.vsubmotive;
                  index=index-1;
                  objSubMotive = ArrSubMotives.elementAt(index);
                  document.frmdatos.txtContDescription.value=objSubMotive.npassociatedspeech;
                }
            }
         }
      }
   }
   else {
      document.frmdatos.txtContDescription.value="";
   }
}



//Obtiene valor del campo descripci�n para un contacto en edici�n
function fxValidateEditMotive(index) {
   if (document.frmdatos.cmbContSubMotive.value!=""){
      for(k=0;k<Vmotive.size();k++) {
         objMotive = Vmotive.elementAt(k);
         if (objMotive.id==document.frmdatos.cmbContMotive.value){
            ArrSubMotives = objMotive.vsubmotive;
            index=index-1;
            objSubMotive = ArrSubMotives.elementAt(index);
            document.frmdatos.txtContDescription.value=objSubMotive.npassociatedspeech;
         }
      }
   }
   else {
      document.frmdatos.txtContDescription.value="";
   }
}



//Obtiene todos los submotivos de un motivo para un nuevo contacto
function fxLoadNewSubMotive(index){
   DeleteSelectOptions(document.frmdatos.cmbContSubMotive);
   if (document.frmdatos.cmbContMotive.selectedIndex!="") {
      for(j=0;j<Vmedias.size();j++) {
         objMedio = Vmedias.elementAt(j);
         if (objMedio.id == document.frmdatos.cmbContMedia.value){
            ArrMotives = objMedio.vmotive;
            index=index-1;
            objMotive = ArrMotives.elementAt(index);
	    if (objMotive.id==document.frmdatos.cmbContMotive.value){
               ArrSubMotives = objMotive.vsubmotive;
   	       for(k=0;k<ArrSubMotives.size();k++) {
                  objSubMotive = ArrSubMotives.elementAt(k);
                  AddNewOption(document.frmdatos.cmbContSubMotive,objSubMotive.id,objSubMotive.name);
	       }
            }
	    
         }
      }
   }
  document.frmdatos.txtContDescription.value="";
}


//Obtiene valores del submotivo en edici�n
function fxLoadEditSubMotive(index) {
   DeleteSelectOptions(document.frmdatos.cmbContSubMotive);
   if (document.frmdatos.cmbContMotive.value!=""){
      for(k=0;k<Vmotive.size();k++) {
         objMotive = Vmotive.elementAt(k);
         if (objMotive.id==document.frmdatos.cmbContMotive.value){
            ArrSubMotives = objMotive.vsubmotive;
            for(m=0;m<ArrSubMotives.size();m++) {
               objSubMotive = ArrSubMotives.elementAt(m);
               AddNewOption(document.frmdatos.cmbContSubMotive,objSubMotive.id,objSubMotive.name);
            }
         }
      }
   }
   document.frmdatos.txtContDescription.value="";
}


function fxOnChangeNewContactStatus(){
   try{
      fxOnChangeNewContactStatusExt();
   }catch(e){}
}

function fxOnChangeNewContactType(){ 	
   try{
      fxOnChangeNewContactTypeExt();
   }catch(e){}
}
         
function fxOnChangeNewContactDate(){
   try{
      fxOnChangeNewContactDateExt();
   }catch(e){}
}


function fxOnChangeNewContactMedia(){
   try{
      fxOnChangeNewContactMediaExt();
   }catch(e){}
}


function fxOnChangeEditContactStatus(){
   try{
      fxOnChangeEditContactStatusExt();
   }catch(e){}
}

function fxOnChangeEditContactType(){
	
   try{
      fxOnChangeEditContactTypeExt();
   }catch(e){
   }
}

function fxOnChangeEditContactDate(){

   try{
      fxOnChangeEditContactDateExt();
   }catch(e){}
}

        
//Pop up de direcciones del cliente o el site
function fxListAddress(){
   var url="";
   var siteid ="";
   if (document.frmdatos.hdnSiteId != null)
      siteid=document.frmdatos.hdnSiteId.value;
   url = "/portal/pls/portal/WEBSALES.NP_CONTACT_NEW_PL_PKG.PL_CONTACT_ADDRESS?"
         +"an_customerid="+document.frmdatos.hdnCustomerId.value
         +"&an_siteid="+siteid;
   WinAsist = window.open(url,"WinAsist","toolbar=no,location=0,directories=no,status=yes,menubar=0,scrollbars=no,resizable=no,screenX=100,top=80,left=100,screenY=80,width=700,height=300,modal=yes");
}

//Validaciones antes de ser guardado
function fxValidateContactNew() {
   var strMedio  = "";
   var strStatus = "";

   if (document.frmdatos.cmbContLastContact.value=="") {
      var strMedio  = document.frmdatos.cmbContMedia[document.frmdatos.cmbContMedia.selectedIndex].text;
      var strStatus = document.frmdatos.cmbContMediaStatus[document.frmdatos.cmbContMediaStatus.selectedIndex].text;

      if (document.frmdatos.cmbContMedia.value == "") {
         alert("Debe seleccionar un medio.")
         document.frmdatos.cmbContMedia.focus();
         return false;
      }
      if ((document.frmdatos.cmbContSendType.value=="M") && (document.frmdatos.hdnSendTextMensPhoneNumberList.value=="")){
         alert("Debe seleccionar al menos un n�mero");
         document.frmdatos.cmbContSendType.focus();
         return false;
      }
      if (document.frmdatos.hdnvisualizationtype.value==1) {
         if (document.frmdatos.txtContName.value=="") {
            alert("Debe ingresar el nombre del contacto.")
            document.frmdatos.txtContName.focus();
            return false;
         }
         if (document.frmdatos.txtContLastName.value=="") {
            alert("Debe ingresar el apellido del contacto.")
            document.frmdatos.txtContLastName.focus();
            return false;
         }
      }
      if ((document.frmdatos.hdnvisualizationtype.value==2) && (document.frmdatos.cmbContContact!=null) && (document.frmdatos.cmbContContact.value == 0)) {
         alert("Debe ingresar un contacto.")
         document.frmdatos.cmbContContact.focus();
         return false;
      }
      if (document.frmdatos.hdnvisualizationtype.value==3) {
	 if (div_cmbContact.style.display==""){
            if (document.frmdatos.cmbContContact.value == "") {
               alert("Debe elegir contacto.")
               document.frmdatos.cmbContContact.focus();
               return false;
            }
            if ((document.frmdatos.cmbContContact.value == 0) && (document.frmdatos.txtContName!=null) && (document.frmdatos.txtContName.value=="")) {
               alert("Debe ingresar el nombre del contacto.")
               document.frmdatos.txtContName.focus();
               return false;
            }
            if ((document.frmdatos.cmbContContact.value == 0) && (document.frmdatos.txtContLastName!=null) && (document.frmdatos.txtContLastName.value=="")) {
               alert("Debe ingresar el apellido del contacto.")
               document.frmdatos.txtContLastName.focus();
               return false;
            }
         }
      }
      if ((div_phone1.style.display=="") && (!ContentOnlyNumberDec(document.frmdatos.txtContTelephone1.value))){
         alert("El tel�fono s�lo debe contener caracteres num�ricos");
         document.frmdatos.txtContTelephone1.focus();
         return false;
      }
      
      if (div_sendtype.style.display == ""){
        if ((div_txtContact.style.display=="") && (!ContentOnlyNumberDec(document.frmdatos.txtContTelephone2.value))){
            alert("El tel�fono s�lo debe contener caracteres num�ricos");
            document.frmdatos.txtContTelephone2.focus();
            return false;
        }
      }

      id=document.frmdatos.cmbContMedia.value;
      for(j=0;j<Vmedias.size();j++) {
         objMedio = Vmedias.elementAt(j);
         if (objMedio.id == id){
            if ((div_phone1.style.display=="") && (objMedio.npmandatorycontactphone=="S") && (document.frmdatos.txtContTelephone1.value=="")) {
               alert("Debe ingresar el n�mero telef�nico");
               document.frmdatos.txtContTelephone1.focus();
               return false;
            }
            if ((div_txtContact.style.display=="") && (objMedio.npmandatorycontactphone=="S") && (document.frmdatos.txtContTelephone2.value=="")) {
               alert("Debe ingresar el n�mero telef�nico");
               document.frmdatos.txtContTelephone2.focus();
               return false;
            }
         }
      }
      if (document.frmdatos.cmbContMediaStatus.value == "") {
         alert("Debe seleccionar el estado del contacto.");
         document.frmdatos.cmbContMediaStatus.focus();
         return false;
      }
      /*S�lo cuando hdnProgramDateMax este seteado se permitir� registrar en Open*/
      statusid=document.frmdatos.cmbContMediaStatus.value;
      for(j=0;j<Vmedias.size();j++) {
         objMedio = Vmedias.elementAt(j);
         if (objMedio.id == id){
            Vstatus=objMedio.vstatus;
            for(k=0;k<Vstatus.size();k++) {
               objStatus = Vstatus.elementAt(k);
               if (objStatus.id == statusid){
                  if ((objStatus.npmeaning=="P") && (div_date.style.display=="")) {
                     if (document.frmdatos.hdnProgramDateMax.value=="") {
                        alert("No puede registrar una comunicaci�n en estado Programada");
                        document.frmdatos.cmbContMediaStatus.focus();
                        return false;
                     }else if (!fxDaysBefore(document.frmdatos.txtContDate, 0, "Contacto "+strMedio+"/"+strStatus)){
                        return false;
                     }
                  }
               }
            }
         }
      }
      if ((div_address1.style.display=="") && ((document.frmdatos.txtContAddress1.value!="") || (document.frmdatos.txtContAddress2.value!=""))){
	if (document.frmdatos.cmbContDepartment.value=="") {
           alert("Debe seleccionar un departamento.")
           document.frmdatos.cmbContDepartment.focus();
           return false;
	}
	if (document.frmdatos.cmbContProvince.value=="") {
	   alert("Debe seleccionar una provincia.")
           document.frmdatos.cmbContProvince.focus();
           return false;
	}
	if (document.frmdatos.cmbContDistrict.value=="") {
	   alert("Debe seleccionar un distrito.")
           document.frmdatos.cmbContDistrict.focus();
           return false;
	}
      }
      if ((div_date.style.display=="") && (document.frmdatos.txtContDate.value=="")) {
         alert("Debe ingresar un valor para la fecha de inicio.")
         document.frmdatos.txtContDate.focus();
         return false;
      }
      if ((div_date.style.display=="") && (document.frmdatos.txtContInitHour.value=="")) {
         alert("Debe ingresar un valor para la hora de inicio.")
         document.frmdatos.txtContInitHour.focus();
         return false;
      }
      if ((div_endhour.style.display=="") && (document.frmdatos.txtContEndHour.value=="")) {
         alert("Debe ingresar un valor para la hora fin.")
         document.frmdatos.txtContEndHour.focus();
         return false;
      }
      if ((div_date.style.display=="") && (div_endhour.style.display=="") && (!fxCompareHour(document.frmdatos.txtContInitHour,document.frmdatos.txtContEndHour))){
         alert("La hora fin debe ser mayor a la hora inicio");
	 document.frmdatos.txtContEndHour.focus();
         return false;
      }

      if ((div_date.style.display=="") && (document.frmdatos.hdnObjecttype.value=="CAMDET")) {
         if ((document.frmdatos.hdnProgramDateMax.value!="") && (TiempoFecha1ToFecha2(document.frmdatos.txtContDate.value,document.frmdatos.hdnProgramDateMax.value)<0)) {
            alert("La fecha debe ser menor a la fecha fin de campa�a ("+document.frmdatos.hdnProgramDateMax.value+")");
            document.frmdatos.txtContDate.focus();
            return false;
         }
      }
      if ((div_date.style.display=="") && (!isValidDate(document.frmdatos.txtContDate.value))) {
         alert("Debe ingresar fecha de inicio v�lida.")
         document.frmdatos.txtContDate.focus();
         return false;
      }
      if ((div_date.style.display=="") && (!fxDaysBefore(document.frmdatos.txtContDate, -7, "Contacto"))){
         document.frmdatos.txtContDate.focus();
         return false;
      }
      if (trim(document.frmdatos.txtContDescription.value)=="") {
         alert("Debe ingresar la descripci�n.")
         document.frmdatos.txtContDescription.focus();
         return false;
      }
      id=document.frmdatos.cmbContMedia.value;
      for(j=0;j<Vmedias.size();j++) {
         objMedio = Vmedias.elementAt(j);
         if (objMedio.id == id){
            if(objMedio.npcontactdescmaxlength!="") {
               if (!fxValidateText(frmdatos.txtContDescription,"Descripci�n",0,objMedio.npcontactdescmaxlength)){
                  document.frmdatos.txtContDescription.focus();
                  return false;
               }
            }
         }
      }
      if ((div_motive.style.display=="") && (document.frmdatos.cmbContMotive.value!="") && (document.frmdatos.cmbContSubMotive.value=="")){
         alert("Debe seleccionar un submotivo.")
         document.frmdatos.cmbContSubMotive.focus();
         return false;
      }
      if (div_confirmation.style.display=="") {
         txtData = new String(document.frmdatos.txtContDestiny.value);
         if (document.frmdatos.cmbContConfirmation.selectedIndex!=0){
            if (txtData.length>0){
               if (document.frmdatos.cmbContConfirmation.selectedIndex==1){    //Validad mail
                  if (!jsValidarEmail(document.frmdatos.txtContDestiny, "Destino de confirmaci�n")){
                     document.frmdatos.txtContDestiny.focus();
                     return false;
                  }
               }
               else{
                  if (!ContentOnlyNumber(txtData)){  //Valida s�lo n�meros
                     alert("Debe ingresar un n�mero de tel�fono v�lido.");
                     document.frmdatos.txtContDestiny.focus();
                     return false;
                  }
                  else{
                     if (document.frmdatos.cmbContConfirmation.selectedIndex==2 && txtData.length!=8){ //Valida Nextel (8 dig.)
                        alert("El destino de confirmaci�n debe ser un n�mero con 8 d�gitos.");
                        document.frmdatos.txtContDestiny.focus();
                        return false;
                     }
                     else if (document.frmdatos.cmbContConfirmation.selectedIndex==3 && txtData.length!=7){ //Valida Tlf.Fijo (7 dig.)
                        alert("El destino de confirmaci�n debe ser un n�mero con 7 d�gitos.");
                        document.frmdatos.txtDestinoConfirm.focus();
                        return false;
                     }
                  }
               }
            }
         }
      }
      return true;
   }
}


function makeContactDetail(
			  	  wn_swtodoid,           wn_customerid,     wn_npsiteid,             wv_sitename,              wn_npmediaid,      wv_npmedia,
                                  wn_npmediastatusid,    wv_mediastatus,    wv_swstatus,             wn_swcontactid,           wv_contactname,    wv_npnombrecontacto,
                                  wv_npcontactlastname,  wv_npcontactphone, wv_swcitasuperv,         wv_npaddress1,            wv_npaddress2,     wn_npdepartmentid,
                                  wn_npprovinceid,       wn_npdistrictid,   wn_npsubjectid,          wv_subject,               wn_npsubsubjectid, wv_subsubject,
                                  wv_date,               wv_sweststarttime, wv_swestendtime,         wn_npinteractionmotiveid, wv_swdescription,  wv_npcontactnumber,
                                  wn_npcontactsubtypeid, wv_npconfirmvia,   wv_npconfirmdestination, wv_npassignedto,          wv_area,           wn_swassignedtoid,
                                  wn_swopportunityid,    wv_timestamp,      wv_npupdateallowed,      wv_typebusinessobject,    wv_statusedit,     wv_npcontactsubtypedesc,	  wv_npphoneextension){

this.wn_swtodoid 	  = wn_swtodoid;
this.wn_customerid 	  = wn_customerid;
this.wn_npsiteid 	  = wn_npsiteid;
this.wv_sitename 	  = wv_sitename;
this.wn_npmediaid 	  = wn_npmediaid;
this.wv_npmedia 	  = wv_npmedia;
this.wn_npmediastatusid   = wn_npmediastatusid;
this.wv_mediastatus	  = wv_mediastatus;
this.wv_swstatus	  = wv_swstatus;
this.wn_swcontactid       = wn_swcontactid;
this.wv_contactname       = wv_contactname;
this.wv_npnombrecontacto  = wv_npnombrecontacto;
this.wv_npcontactlastname = wv_npcontactlastname;
this.wv_npcontactphone    = wv_npcontactphone;
this.wv_swcitasuperv	  = wv_swcitasuperv;
this.wv_npaddress1        = wv_npaddress1;
this.wv_npaddress2        = wv_npaddress2;
this.wn_npdepartmentid    = wn_npdepartmentid;
this.wn_npprovinceid      = wn_npprovinceid;
this.wn_npdistrictid      = wn_npdistrictid;
this.wn_npsubjectid       = wn_npsubjectid;
this.wv_subject		  = wv_subject;	
this.wn_npsubsubjectid	  = wn_npsubsubjectid;
this.wv_subsubject        = wv_subsubject;
this.wv_date              = wv_date;
this.wv_sweststarttime    = wv_sweststarttime; 
this.wv_swestendtime          = wv_swestendtime;
this.wn_npinteractionmotiveid = wn_npinteractionmotiveid;
this.wv_swdescription         = wv_swdescription;       
this.wv_npcontactnumber       = wv_npcontactnumber;
this.wn_npcontactsubtypeid    = wn_npcontactsubtypeid;
this.wv_npconfirmvia          = wv_npconfirmvia;
this.wv_npconfirmdestination  = wv_npconfirmdestination;
this.wv_npassignedto          = wv_npassignedto;
this.wv_area                  = wv_area;
this.wn_swassignedtoid        = wn_swassignedtoid;
this.wn_swopportunityid       = wn_swopportunityid;
this.wv_timestamp             = wv_timestamp;
this.wv_npupdateallowed       = wv_npupdateallowed;
this.wv_typebusinessobject    = wv_typebusinessobject;
this.wv_statusedit            = wv_statusedit;
this.wv_npcontactsubtypedesc  = wv_npcontactsubtypedesc;
this.wv_npphoneextension  = wv_npphoneextension;

}