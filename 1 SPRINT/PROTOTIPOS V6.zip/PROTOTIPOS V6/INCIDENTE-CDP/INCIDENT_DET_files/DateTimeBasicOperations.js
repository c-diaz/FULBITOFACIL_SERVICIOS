   function IsValidTime(timeStr) {
      // Forzamos para que no pasen formatos de hora en donde se incluyan los segundos.
      // var timePat = /^(\d{1,2}):(\d{2})(:(\d{2}))?(\s?(AM|am|PM|pm))?$/;
      var timePat = /^(\d{1,2}):(\d{2})$/;
      var matchArray = timeStr.match(timePat);
      
      if (matchArray == null) {
         alert("Formato de hora no v�lido.");
         return false;
      }

      hour = matchArray[1];
      minute = matchArray[2];
      // second = matchArray[4];
      // ampm = matchArray[6];
      
      // if (second=="") { second = null; }
      // if (ampm=="") { ampm = null }
      
      if (hour < 0  || hour > 23) {
         alert("La hora debe estar entre 0 y 23.");
         return false;
      }
      
      if (minute<0 || minute > 59) {
         alert ("Los minutos deben estar entre 0 y 59.");
         return false;
      }
      
      /*
      if (second != null && (second < 0 || second > 59)) {
         alert ("Los segundos deben estar entre 0 y 59.");
         return false;
      }
      */

      return true;
   }

   /*
   Purpose: Verifica validez del contenido de campo que contiene hora
   Param1: timeField    -> Campo de hora
   */
   function isTimeFieldValid(timeField) {
      timeStr = timeField.value;
      if ( timeStr == "" ) return true;
      if ( !IsValidTime(timeStr) ) {
         timeField.focus();
         timeField.select();
         return false;
      }
      return true;
   }   
   
   function isValidDate(dateStr) {
      var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{4})$/;
      var matchArray = dateStr.match(datePat);
      if (matchArray == null) {
         alert(dateStr + " no es una fecha v�lida. Int�ntelo nuevamente.")
            return false;
      }
      day = matchArray[1];
      month = matchArray[3];
      year = matchArray[4];
      if (month < 1 || month > 12) {
         alert("El mes debe estar entre 1 y 12.");
         return false;
      }
      if (day < 1 || day > 31) {
         alert("Los d�as deben estar entre 1 y 31.");
         return false;
      }
      if ((month==4 || month==6 || month==9 || month==11) && day==31) {
         alert("El mes no tiene 31 d�as!")
            return false;
      }
      if (month == 2) {
         var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
         if (day>29 || (day==29 && !isleap)) {
            alert("Febrero " + year + " no tiene " + day + " d�as!");
            return false;
         }
      }
      return true;
   }
   
   
   /*
   Purpose: Verifica el valor de campo fecha dentro de un rango (N� de dias antes y N� de dias despues)
   Param1: dateField    -> Campo de fecha
   Param2: daysBefore   -> N� dias antes
   Param3: daysAfter    -> N� dias despues
   Param4: ObjDescr     -> Nombre del Campo para enviar mensaje alert
   */
   function isDateFieldBetweenRange(dateField, daysBefore, daysAfter, ObjDescr) {
      dateStr = dateField.value; // Fecha est� en formato DD/MM/YYYY
      if ( dateStr == "" ) return true;
      if ( !isValidDate(dateStr) ) {
         dateField.focus();
         dateField.select();
         return false;
      }
      var today = new Date();
      today = new Date((today.getMonth()+1)+"/"+today.getDate()+"/"+today.getYear());
      
      dateStr = dateStr.substr(3,2)+"/"+dateStr.substr(0,2)+"/"+dateStr.substr(6);  // Convierte Fecha a formato MM/DD/YYYY
      var checkDate = new Date(dateStr); //Date.parse(dateStr);
      var diference = DifferenceBetweenDates(today, checkDate, 'd', false );
     
      if (diference > daysAfter) {
         msg = "Fecha de " + ObjDescr + " no puede ser mayor a " + (daysAfter==0? "hoy" : Math.abs(daysAfter) + " dias")
         alert(msg)
	 try{
            dateField.focus();
            dateField.select();
	 }
	 catch(e){};

         return false;
      }else if (diference < daysBefore) {
         msg = "Fecha de " + ObjDescr + " no puede ser menor a " + (daysBefore==0? "hoy" : Math.abs(daysBefore) + " dias")
         alert(msg)
	 try{
            dateField.focus();
            dateField.select();
	 }
	 catch(e){};
         return false;
      }
      return true;
      
   }


   /*verifica la fecha para un n�mero de d�as antes*/
   function fxDaysBefore(dateField, daysBefore, ObjDescr){
      dateStr = dateField.value; // Fecha est� en formato DD/MM/YYYY
      if ( dateStr == "" ) return true;
      if ( !isValidDate(dateStr) ) {
         dateField.focus();
         dateField.select();
         return false;
      }
      var today = new Date();
      today = new Date((today.getMonth()+1)+"/"+today.getDate()+"/"+today.getYear());

      dateStr = dateStr.substr(3,2)+"/"+dateStr.substr(0,2)+"/"+dateStr.substr(6);  // Convierte Fecha a formato MM/DD/YYYY
      var checkDate = new Date(dateStr); //Date.parse(dateStr);
      var diference = DifferenceBetweenDates(today, checkDate, 'd', false );

      if (diference < daysBefore) {
         msg = "Fecha de " + ObjDescr + " no puede ser menor a " + (daysBefore==0? "hoy" : Math.abs(daysBefore) + " dias")
         alert(msg)
         dateField.focus();
         dateField.select();
         return false;
      }
      return true;
   }
   
   /*
   Purpose: Calcula la diferencia entre fechas en Dias, Horas, Minutos, Segundos. Depende del parametro "interval"
   Los parametros "start" y "end" son Objetos "Date" de JavaScript
   "interval"-> Dias -> "d" o "D",  Horas ->"h" o "H", Minuto -> "m" o "M", Segundos -> "s" o "S"
   "rounding" -> Si es necesario redondear-> true, false -> caso contrario
   */
   function DifferenceBetweenDates( startDate, endDate, interval, rounding ) {
      
      var retValue = 0;
      var number = Date.parse( endDate ) - Date.parse( startDate ) ; // diferencia entre las fechas, en milisegundos
      
      switch (interval.charAt(0)) { // Que diferencia hallar? Dias, horas, minutos, Segundos
      case 'd': case 'D':
         retValue = parseInt(number / 86400000) ; // Un dia tiene 86400000 milisegundos
         if(rounding) retValue += parseInt((number % 86400000)/43200001) ;
         break ;
      case 'h': case 'H':
         retValue = parseInt(number / 3600000 ) ; // Una hora tiene 3600000 milisegundos
         if(rounding) retValue += parseInt((number % 3600000)/1800001) ;
         break ;
      case 'm': case 'M':
         retValue = parseInt(number / 60000 ) ; // Una hora tiene 60000 milisegundos
         if(rounding) retValue += parseInt((number % 60000)/30001) ;
         break ;
      case 's': case 'S':
         retValue = parseInt(number / 1000 ) ; // Una hora tiene 1000 milisegundos
         if(rounding) retValue += parseInt((number % 1000)/501) ;
         break ;
      default: // Si "interval" no es uno de los valores ingresados, asumimos que la diferencia es por dias
         retValue = parseInt(number / 86400000) ; // Un dia tiene 86400000 milisegundos
         if(rounding) retValue += parseInt((number % 86400000)/43200001) ;
         break ;
      }
      return retValue ;
   }



   /*
   Purpose: Compara 2 fechas y indica si cumple con el operador proporcinado, 
            Esta funcion asume que ya se verficado el formato de la fecha. "DD/MM/YYYY"
   */
   function compareDates(strStartDate , operador ,strEndDate){
      var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{4})$/;
      var matchArray = strStartDate.match(datePat);
      var startDay = matchArray[1];
      var startMonth = matchArray[3];
      var startYear = matchArray[4];
      
      matchArray = strEndDate.match(datePat);
      var endDay = matchArray[1];
      var endMonth = matchArray[3];
      var endYear = matchArray[4];
   
      var startdate = new Date(startYear-0,startMonth-1,startDay-0);
      var enddate   = new Date(endYear-0,endMonth-1,endDay-0);
      
      starttime = Date.UTC(y2k(startdate.getYear()),startdate.getMonth(),startdate.getDate(),0,0,0);
      endtime = Date.UTC(y2k(enddate.getYear()),enddate.getMonth(),enddate.getDate(),0,0,0);
      
      if (eval("starttime "+operador+" endtime")){
           return true;
      }else {
         return false
      }
   }
   
   /* Funci�n que corrige el problema del a�o 200 */
   function y2k(number) { 
      return (number < 1000) ? number + 1900 : number; 
   }

  /*Compara horas*/
  function fxCompareHour(inithour,endhour){
     posini = document.frmdatos.txtContInitHour.value.indexOf(":");
     horaini = parseInt(document.frmdatos.txtContInitHour.value.substring(0,posini),10);
     minini = parseInt(document.frmdatos.txtContInitHour.value.substring(posini+1),10);

     posini = document.frmdatos.txtContEndHour.value.indexOf(":");
     horafin = parseInt(document.frmdatos.txtContEndHour.value.substring(0,posini),10);
     minfin = parseInt(document.frmdatos.txtContEndHour.value.substring(posini+1),10);

     horainicial = horaini*60+minini;
     horafinal = horafin*60+minfin;

     if (horafinal < horainicial)
        return false;
     else
  	return true;
  }