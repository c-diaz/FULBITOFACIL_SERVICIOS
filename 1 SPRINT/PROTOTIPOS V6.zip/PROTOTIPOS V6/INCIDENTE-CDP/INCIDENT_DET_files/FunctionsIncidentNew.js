function makeSubject(subject) {
   this.subject = subject;
}

function makeSubjectType(subject,type) { 
   this.subject = subject;
   this.type = type;
}

function makeSubjectTypeSpec(specificationId,subject,type,specification,priority,status) {
   this.specificationId = specificationId;
   this.subject         = subject; 
   this.type            = type;
   this.specification   = specification;
   this.priority        = priority;
   this.status		= status;
}


/*function makeAction(actionId,name,status,statusDesc,order,incDate,userLogin,nptype,executionMode,flgSP) {
   this.actionId      = actionId;
   this.name          = name; 
   this.status        = status;
   this.statusDesc    = statusDesc;
   this.order         = order;
   this.incDate       = incDate;
   this.userLogin     = userLogin;
   this.nptype        = nptype;
   this.executionMode = executionMode;
   this.flgSP         = flgSP;
}*/

function makeAction(actionId,name,status,statusDesc,order,incDate,userLogin,nptype,executionMode,flgSP,resolutionId) {
   this.actionId      = actionId;
   this.name          = name; 
   this.status        = status;
   this.statusDesc    = statusDesc;
   this.order         = order;
   this.incDate       = incDate;
   this.userLogin     = userLogin;
   this.nptype        = nptype;
   this.executionMode = executionMode;
   this.flgSP         = flgSP;
   this.resolutionId  = resolutionId;
}

   
function fxAddRowTableAction(v_objDocument,tableID,obj_vAction) {
   form = document.frmdatos;
   var index_arg;
   var table = v_objDocument.all ? v_objDocument.all[tableID]:v_objDocument.getElementById(tableID);
   var elemText;
   var row = table.insertRow(-1);
   row.className = "CellContent";
   row.align = "center";
   row.id = "IdAction"+obj_vAction.actionId;
   if (document.all) {
      for (index_arg = 1; index_arg<=8; index_arg++) {
         var cell = row.insertCell(index_arg - 1);
         elemText="";
            switch (index_arg){
               case 1: 
                  elemText =  "<input type='checkbox' name='chkActionId' value='"+ obj_vAction.actionId +"' onclick='fxValidateExecActPermited(this)'>";			      
                  break;
               case 2: 
                  elemText =  " <input type='text'   name='txtActionOrder'           value='"+ obj_vAction.order +"' size='2'>"
			      +"<input type='hidden' name='hdnActionId'              value='"+ obj_vAction.actionId +"'>"
			      +"<input type='hidden' name='hdnActionIdToExecute'     value='0'>"
			      +"<input type='hidden' name='hdnActionStatus'          value='"+obj_vAction.status+"'>"
			      +"<input type='hidden' name='hdnActionStatusDate'      value='"+obj_vAction.incDate+"'>"
		   	      +"<input type='hidden' name='hdnActionStatusUserLogin' value='"+obj_vAction.userLogin+"'>"
			      +"<input type='hidden' name='hdnExecutionScheduleDate' >"
			      +"<input type='hidden' name='hdnExecutionMode'         value='"+obj_vAction.executionMode+"'>"
			      +"<input type='hidden' name='hdnActionDefault'         value='0'>"
			      +"<input type='hidden' name='hdnIsForEditing'          value=''>";

                  break;
               case 3: 
		  cell.align = "left";
                  elemText =  "<label>"+ obj_vAction.name+ "</label>";
                  break;
               case 4: 
                  elemText =  "<label>"+ obj_vAction.statusDesc+ "</label>";
                  break;
               case 5: 
                  elemText =  "<label>"+obj_vAction.incDate+"</label>";
                  break;
               case 6: 
                  elemText =  "<label>"+obj_vAction.userLogin+"</label>";
                  break; 
               case 7: 
                  elemText = "<div id='IdActionScheduleDate"+obj_vAction.actionId+"' style='display:none'>"
			     +"<input type='text' name='txtExecutionScheduleDate' size='10' maxlength='10' onBlur='return isDateFieldValid(this)' value=''>"
			    // +"<a href=\"javascript:show_calendar('frmdatos.txtExecutionScheduleDate["+ row.rowIndex +"]',null,null,'DD/MM/YYYY');\" onMouseOver=\"window.status='Fecha';return true;\" onMouseOut=\"window.status='';return true;\">"
			    // +"<img src='/websales/images/show-calendar.gif' width='24' height='22' border='0'></a>"
			     +"&nbsp;<i>DD/MM/YYYY</i>"
			     +"</div>";

                  break;
               case 8: 
                  elemText =  "<a href=\"javascript:\" onclick=\"javascript:fxHideRow(this,'IdSectorAction',"+ obj_vAction.actionId +")\"><img src='/websales/images/Eliminar.gif'  border='0' width='20' height='20'></a>";
                  break;
                  default:
            }  /* end_switch */
               cell.innerHTML = elemText;
      } /* end_for */
   }  /* end_if */

   wn_items =(table.rows.length -1); /* numero de items  */
   if (wn_items>1){
      wb_existItem =true;
   }
}



function fxOnChangeNewContactStatusExt(){
   fxUpdateNoticationDate();

}

function fxOnChangeNewContactTypeExt(){
   fxUpdateNoticationDate();

}

function fxOnChangeNewContactDateExt(){  
   fxUpdateNoticationDate();

   //INI--SECCION RETENCIONes ACTUALIZAR LA FECHA EFECTIVA DE SUSPENSION---RPE�A--------
   try{
        fxChangeFechaEfectiva(v_form.txtContDate.value);
   }catch(e){

   }
   //FIN--------------------------------------------------------------------------------

}


//Si se cumplen las condiciones, actualiza la fecha de notificaci�n 
//del reclamo con la fecha del contacto

function fxUpdateNoticationDate(){ 
   //Aqui va la l�gica de cambio de fecha de notificaci�n  
   var v_form      = document.frmdatos;
   var v_mediaId   = v_form.cmbContMedia.value;
   var v_status    = v_form.cmbContMediaStatus.value;
   var v_type      = v_form.cmbContType.value;
   var v_statusMeaning   = false;
   var v_typeActFecNotif = false;

   var  ArrStatus  = null;
   var  ArrSubtype = null;

   if (v_form.hdnFlagComplaintInstance  != null){
	   var v_flagInstance = v_form.hdnFlagComplaintInstance.value;
	}   
   for(j=0;j<Vmedias.size();j++) {
      objMedio = Vmedias.elementAt(j);
      if (objMedio.id == v_mediaId ){
         ArrStatus = objMedio.vstatus;
         ArrSubtype = objMedio.vsubtype;
         break;
      }
   }    
   if(ArrStatus != null){
      for(k=0;k<ArrStatus.size();k++) {
         objStatus = ArrStatus.elementAt(k);         
         if( (v_status == objStatus.id) && (objStatus.npmeaning == "C")){
            v_statusMeaning = true;    
            break;
         }                        
      }
   }   

   if(ArrStatus != null){
      for(k=0;k<ArrSubtype.size();k++) {
         objType = ArrSubtype.elementAt(k);	
         if( (v_type == objType.id) && (objType.nptag1 == "ACT_FEC_NOTIF")){   
            v_typeActFecNotif = true;    
            break;
         }                        
      }
   }
   
    var indexCompare = 0;	
   if( v_statusMeaning && v_typeActFecNotif ){ // if 1
      //se cambia la fecha de notificaci�n del incidente
      var v_txtContDate = v_form.txtContDate.value;	 	  
      if (v_txtContDate  != "" )
         if ( v_form.txtComplaintNotifDate != null ){
            if( v_form.txtComplaintNotifDate.value != "" ){	//2
            	//indexCompare = fxGetGreatestFromCompareDates(v_txtContDate,"",v_form.txtComplaintNotifDate.value,"");
				indexCompare = fxGetGreatestFromCompareDates(v_txtContDate,"",v_form.hdnComplaintNotifDate.value,"");
				if (indexCompare == 1){																 				
					v_form.txtComplaintNotifDate.value = v_txtContDate;
				}					
				else{				
					v_form.txtComplaintNotifDate.value = v_form.hdnComplaintNotifDate.value;
				}
						
				if(div_tables.style.display == "none" && v_flagInstance == 1){						
					 v_form.txtComplaintNotifDate.value = "";
				}
				else{
					if(div_tables.style.display == "none"){				
						 v_form.txtComplaintNotifDate.value = v_form.hdnComplaintNotifDate.value;
					}				
				}							
			
	    	  }			
			else{//2		
				if (v_form.hdnComplaintNotifDate.value != null){
					if(v_form.hdnComplaintNotifDate.value != ""){					
						if(compareDate(v_txtContDate ,"<",v_form.hdnComplaintNotifDate.value) || 
						v_txtContDate == v_form.hdnComplaintNotifDate.value){
							v_form.txtComplaintNotifDate.value = v_form.hdnComplaintNotifDate.value;						
						}
						else{
							v_form.txtComplaintNotifDate.value = v_txtContDate;						
						}
					}
					else{
						v_form.txtComplaintNotifDate.value = v_txtContDate;	
					}
				}
				else{
	            	v_form.txtComplaintNotifDate.value = v_txtContDate;		
					//v_form.txtComplaintNotifDate.value = v_form.hdnComplaintNotifDate.value;
				}
	            return true;
			}
         }	 

   }//if 1
	else{	
      if (v_form.hdnComplaintNotifDate != null ){
         v_form.txtComplaintNotifDate.value = v_form.hdnComplaintNotifDate.value;
	  }
	  else {
			if(v_form.txtComplaintNotifDate != null){ 
				v_form.txtComplaintNotifDate.value = "";
			}
		}
	  if (v_form.hdnFlagComplaintInstance !=null){		
	  	if (v_flagInstance == 1){
		 	v_form.txtComplaintNotifDate.value = "";
		}     	  	
	 }
   }// else 
   return false;
}// funcion



function makeResolution(resolutionName,resolutionid) {
   this.resolutionName = resolutionName;
   this.resolutionid   = resolutionid;
}



function fxAddRowTableComplaint(v_objDocument,tableID) {
   var index_arg;
   var table = v_objDocument.all ? v_objDocument.all[tableID]:v_objDocument.getElementById(tableID);
   var elemText;
   var row = table.insertRow(-1);
   row.className = "CellContent";
   row.align = "center";
   var v_rowIndex = row.rowIndex; 
   //row.id = "IdAction"+obj_vAction.actionId;
   if (document.all) {
      for (index_arg = 1; index_arg<=8; index_arg++) {
         var cell = row.insertCell(index_arg - 1);
         elemText="";
            switch (index_arg){
               case 1: 
		  cell.noWrap = true;
                  elemText =   "<input type='hidden' name='hdnComplaintStatus'    value=''>"
			      +"<input type='hidden' name='hdnComplaintPhaseDate' value=''>"
			      +"<input type='hidden' name='hdnComplaintPhaseTime' value=''>"
			      +"<input type='text' name='txtComplaintPhaseDate' size='6' maxlength='10' onBlur='return isDateFieldValid(this)' value=''>"
                              +"<!--&nbsp;&nbsp;<a  href=\"javascript:show_calendar('frmdatos.txtComplaintPhaseDate["+v_rowIndex+"]',null,null,'DD/MM/YYYY');\" onMouseOver=\"window.status='Fecha';return true;\" onMouseOut=\"window.status='';return true;\">"
                              +"<img src='/websales/images/show-calendar.gif' width='24' height='22' border='0'></a> -->"                              
                              +"&nbsp;&nbsp;<input type='text' name='txtComplaintPhaseTime' size='2' maxlength='5'>";
		      
                  break;
               case 2: 
                  elemText = "<input type='hidden' name='hdnComplaintInstance' value=''>"
			     +"<select id='cmb_complaintInstance' name='cmb_complaintInstance' " 			     +"onchange=\"fx_fillComplaintType(this.value,document.frmdatos.cmb_complaintType["+row.rowIndex+"],document.frmdatos.hdnComplaintInstance["+row.rowIndex+"],'')\">"
                             +"   <OPTION VALUE=''>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</OPTION>"
                             +"</select>";
			
                  break;
               case 3: 
                  elemText =  "<input type='hidden' name='hdnComplaintType' value=''>"
			     +"<select name='cmb_complaintType' style='display:block' onchange='fxValidateChangeType(this,"+v_rowIndex+")'>"
                             +"   <option>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>"
                             +"</select>";
                  break;
               case 4: 
                  elemText =  
			      "<input type='hidden' name='hdnComplaintResSourceId' value=''>"
			     +"<input type='hidden' name='hdnComplaintResolutionId' value=''>"
			     +"<select name='cmb_complaintResolution' onchange='fxSetParameterResolution(this,"+v_rowIndex+")'>"
                             +"  <OPTION VALUE=''>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</OPTION>"
                             +"</select>";
                  break;
               case 5: 
                  elemText =  "<input type='hidden' name='hdnComplaintResolutionBy'>";
                  break;
               case 6: 
                  elemText =  "<input type='hidden' name='hdnComplaintResolutionDate'>";
                  break; 
               case 7: 
                  elemText =  "<a href=\"javascript:\" onclick=\"javascript:fxHideRowComplaint("+row.rowIndex+")\"><img src='/websales/images/Eliminar.gif'  border='0' width='20' height='20'></a>";
                  break;
                  default:
            }  /* end_switch */
               cell.innerHTML = elemText;
      } /* end_for */
   }  /* end_if */

   wn_items =(table.rows.length -1); /* numero de items  */
   if (wn_items>1){
      wb_existItem =true;
   }
}

function fxMakeIncSection(sectionId,objectType,objectId,evenType,eventHandler,status){
            //ejemplo 1,"SPECIFICACION","1254","NEW_ONDISPLAY","ValidateSection12()"
            this.sectionId    = sectionId;
            this.objectType   = objectType;
            this.objectId     = objectId;
            this.evenType     = evenType;
            this.eventHandler = eventHandler 
            this.status       = status;      //ACTIVE,DELETED
 }


function fxAddRowTableSectionsIdentifyObjs(v_objDocument,tableID,obj_section) {

   var index_arg;
   var table = v_objDocument.all ? v_objDocument.all[tableID]:v_objDocument.getElementById(tableID);
   var elemText;
   var row = table.insertRow(-1);
   var v_rowIndex = row.rowIndex;
   if (document.all) {
      for (index_arg = 1; index_arg<=1; index_arg++) {
         var cell = row.insertCell(index_arg - 1);
         elemText="";
            switch (index_arg){
               case 1:
                  elemText =   "<input type='hidden' name='hdnIncSectionSectionId' value='"+obj_section.sectionId+"'>"
			       +"<input type='hidden' name='hdnIncSectionObjectType' value='"+obj_section.objectType+"'>"
			       +"<input type='hidden' name='hdnIncSectionObjectId' value='"+obj_section.objectId+"'>"
   			       +"<input type='hidden' name='hdnIncSectionStatus' value='"+obj_section.status+"'>";

		
                  break;
                  default:
            }  /* end_switch */
               cell.innerHTML = elemText;
      } /* end_for */
   }  /* end_if */
  
}




function fxGetGreatestFromCompareDates(v_firstDate,v_firstTime,v_secondDate,v_secondTime){
   if(compareDate(v_firstDate ,"<",v_secondDate)){
            if (v_firstDate == v_secondDate){
                    if (v_firstTime == v_secondTime)
                       return 0;
                    else{
                       if(v_firstTime <= v_secondTime)
                          return 2;
                       else
                          return 1;
                    }
             }
			else
              return 2;
    }
	else
      return 1;

}


function makeDevice(deviceNumber){
      this.deviceNumber     =deviceNumber;
}