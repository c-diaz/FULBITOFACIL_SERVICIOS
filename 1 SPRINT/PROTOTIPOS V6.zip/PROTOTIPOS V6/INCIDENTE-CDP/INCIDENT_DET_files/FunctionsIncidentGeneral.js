//Obtiene el objeto dato el Id de un objeto
/*function fxGetObjectReference(objectId){

    var obj = document.all ? document.all[objectId]:document.getElementById(objectId);
    return obj;
}*/

//Obtiene el objeto dato el Id de un objeto
function fxGetObjectReference(v_document,objectId){

    var obj = v_document.all ? v_document.all[objectId]:v_document.getElementById(objectId);
    return obj;
}


//Elimina una fila de una tabla html
//parametro1 objTable: es la referencia al objetoTable
//parametro1 objRow: es la referencia a la fila que se desea eliminar

function fxDeleteRowTable(objTable,objRow){
   objTable.deleteRow(objRow.rowIndex); 

}

