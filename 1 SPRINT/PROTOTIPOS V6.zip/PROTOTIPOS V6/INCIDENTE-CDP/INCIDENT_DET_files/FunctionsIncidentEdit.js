function fxAddRowTableContactComment(v_objDocument,tableID,obj_VCC,wn_row){
   var index_arg;
   var table = v_objDocument.all ? v_objDocument.all[tableID]:v_objDocument.getElementById(tableID);
   var elemText;
	
   var row = table.insertRow(-1);
   if ((wn_row % 2) == 0) {
		row.className = "ListRow0";
   }
   else{
		row.className = "ListRow1";
	}

   
   row.align = "center";
   row.id="rowData"+wn_row;
   var cell2 = null;
   var cad_description;
   if (document.all) {
      for (index_arg = 1; index_arg<=10; index_arg++) {
         var cell  = row.insertCell(index_arg - 1);
         elemText="";
            switch (index_arg){
               case 1: 
	   	  	   		cell.rowSpan = 2;     			
                if (obj_VCC.wv_typebusinessobject == "CONTACT")
  			   		if(obj_VCC.wv_npupdateallowed == "S")
                	    elemText =  "&nbsp;<a href='javascript:fxShowEdit("+obj_VCC.wn_swtodoid+",rowData"+wn_row+",rowDesc"+wn_row+","+wn_row+")'><img src='/websales/images/Editar.gif' border='0'></a>";
			   		else
 		        	    elemText =  "&nbsp;<a href='javascript:fxShowDetail("+obj_VCC.wn_swtodoid+")'><img src='/websales/images/viewDetail.gif' border='0'></a>";
 				else
                    elemText = "<label></label>";	
                  break;
               case 2: 
                  elemText =  "<label>"+obj_VCC.wv_date+" "+obj_VCC.wv_sweststarttime+"</label>";
                  break;
               case 3: 
                  elemText =  "<label>"+obj_VCC.wv_npmedia+"</label>";
                  break;
               case 4: 
                  elemText =  "<label>"+obj_VCC.wv_npnombrecontacto+" "+obj_VCC.wv_npcontactlastname+"</label>";
                  break;
               case 5: 
                  elemText =  "<label>"+obj_VCC.wv_swstatus+"</label>";
                  break;
               case 6: 
                  elemText =  "<label>"+obj_VCC.wv_npcontactsubtypedesc+"</label>";
                  break; 
               case 7: 
                  elemText =  "<label>"+obj_VCC.wv_npassignedto+"</label>";
                  break;
               case 8:
                  elemText =  "<label>"+obj_VCC.wv_area+"</label>";
                  break;
               case 9:
                  elemText =  "<label>"+obj_VCC.wv_npphoneextension+"</label>";
                  break;
               case 10: 

                  elemText =  "<label>"+obj_VCC.wv_npcontactnumber+"</label>"
		  	     +"<input type='hidden' name='hdnContRepSwtodoid'        value='"+obj_VCC.wn_swtodoid+"'>"
                  	     +"<input type='hidden' name='hdnContRepCompanyId'       value='"+obj_VCC.wn_customerid+"'>"
                  	     +"<input type='hidden' name='hdnContRepSiteId'          value='"+obj_VCC.wn_npsiteid+"'>"
                  	     +"<input type='hidden' name='hdnContRepSite'            value='"+obj_VCC.wv_sitename+"'>"
                  	     +"<input type='hidden' name='hdnContRepMediaId'         value='"+obj_VCC.wn_npmediaid+"'>"
                  	     +"<input type='hidden' name='hdnContRepContactId'       value='"+obj_VCC.wn_swcontactid+"'>"
                     	     +"<input type='hidden' name='hdnContRepName'            value='"+obj_VCC.wv_npnombrecontacto+"'>"
                  	     +"<input type='hidden' name='hdnContRepLastName'        value='"+obj_VCC.wv_npcontactlastname+"'>"
                  	     +"<input type='hidden' name='hdnContRepTelephone'       value='"+obj_VCC.wv_npcontactphone+"'>"
                  	     +"<input type='hidden' name='hdnContRepStatusId'        value='"+obj_VCC.wn_npmediastatusid+"'>"
                             +"<input type='hidden' name='hdnContRepStatus'          value='"+obj_VCC.wv_swstatus+"'>"
                  	     +"<input type='hidden' name='hdnContRepVisitmanager'    value='"+obj_VCC.wv_swcitasuperv+"'>"
                  	     +"<input type='hidden' name='hdnContRepAddress1' 	     value='"+obj_VCC.wv_npaddress1+"'>"
                  	     +"<input type='hidden' name='hdnContRepAddress2'        value='"+obj_VCC.wv_npaddress2+"'>"
                      	     +"<input type='hidden' name='hdnContRepDepartmentId'    value='"+obj_VCC.wn_npdepartmentid+"'>"
                             +"<input type='hidden' name='hdnContRepProvinceId'      value='"+obj_VCC.wn_npprovinceid+"'>"
                             +"<input type='hidden' name='hdnContRepDistrictId'      value='"+obj_VCC.wn_npdistrictid+"'>"
                             +"<input type='hidden' name='hdnContRepSubjectId'       value='"+obj_VCC.wn_npsubjectid+"'>"
                             +"<input type='hidden' name='hdnContRepSubSubjectId'    value='"+obj_VCC.wn_npsubsubjectid+"'>"
                             +"<input type='hidden' name='hdnContRepDate'            value='"+obj_VCC.wv_date+"'>"
                             +"<input type='hidden' name='hdnContRepStartHour'       value='"+obj_VCC.wv_sweststarttime+"'>"
                             +"<input type='hidden' name='hdnContRepEndHour'         value='"+obj_VCC.wv_swestendtime+"'>"
                             +"<input type='hidden' name='hdnContRepMotiveId'        value='"+obj_VCC.wn_npinteractionmotiveid+"'>"
                             +"<input type='hidden' name='hdnContRepContactNumber'   value='"+obj_VCC.wv_npcontactnumber+"'>"
                             +"<input type='hidden' name='hdnContRepTypeId'          value='"+obj_VCC.wn_npcontactsubtypeid+"'>"
                             +"<input type='hidden' name='hdnContRepConfirmation'    value='"+obj_VCC.wv_npconfirmvia+"'>"
                             +"<input type='hidden' name='hdnContRepDestiny'         value='"+obj_VCC.wv_npconfirmdestination+"'>"
                             +"<input type='hidden' name='hdnContRepswopportunityid' value='"+obj_VCC.wn_swopportunityid+"'>"
                             +"<input type='hidden' name='hdnContReptimestamp'       value='"+obj_VCC.wv_timestamp+"'>"
                             +"<input type='hidden' name='hdnContRepassignedtoid'    value='"+obj_VCC.wn_swassignedtoid+"'>"
                             +"<input type='hidden' name='hdnmodify' value='0'>"
			     +"<textarea name='hdnContRepDescription' style='display:none'>"+ obj_VCC.wv_swdescription +"</textarea>"
			     +"<input type='hidden' name='hdnContRepOldStatus' value='"+obj_VCC.wn_npmediastatusid+"'>";

                  break;
                  default:
            }  /* end_switch */
               cell.innerHTML = elemText;
      } /* end_for */
      
      //INI--PARA LA DESCRIPCION DEL CONTACTO O COMENTARIO------------------------------------------------
      var row2 = table.insertRow(-1);//para la descripci�n
	  if ( (wn_row % 2) == 0) {
		row2.className = "ListRow0";
   	  }
   	  else{
		row2.className = "ListRow1";
	  }     
      row2.align = "left";
      row2.id="rowDesc"+wn_row;
      cell  = row2.insertCell(0);
      elemText="";
      cell.colSpan = 9;

	  elemText='<p>'+obj_VCC.wv_swdescription.replace(/\n/g,"<br />")+'</p>';


      cell.innerHTML = elemText;
      //FIN----------------------------------------------------------------------------------------------	

   }  /* end_if */

}

