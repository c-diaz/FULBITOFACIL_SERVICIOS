/*----------------------------------------------------------------------------\
|                             DHTML Menu 1.00                                 |
|-----------------------------------------------------------------------------|
| Navigators				Version											  |										  
| Internet Explorer			6.0 	                                          |
| Internet Explorer			5.0			(Bugs con <select>)                   |
|-----------------------------------------------------------------------------|
|                  Copyright (c) 2003 Nextel			                      |
| - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - |
| - LLamar funciones Javascript												  |
|	Las funciones deben comenzar en "jsMC"									  |
|		Ej. jsMC_abrirventana												  |
|-----------------------------------------------------------------------------|
| History:					                                                  |
| 2003-06-13 | Creaci�n	 		Tosh�o Maruyama								  |
| 2003-11-04 | Modificaci�n	 	Tosh�o Maruyama								  |	
| 2007-09-19 | Modificaci�n     Evelyn Ocampo								  |				
|                               Se agreg� c�digo a la funcion toHtml de manera|
|                               que para men� de primer nivel aparezca la     |
|                               p�gina correspondiente.                       | 							
|-----------------------------------------------------------------------------|
| File Dependencies:														  |
|	- menu.css																  |
|	- blank.png													              |
|	- menu_item.htm													          |
|-----------------------------------------------------------------------------|
| Version Dependencies:														  |
|	- offsetTop, offsetLeft			v4 (Table, tr, td, body)				  |
|	- clientTop, clientLeft			v4 (Table, tr, td, body)				  |
\----------------------------------------------------------------------------*/
/*############################################################################*/
/* Variables */
/*############################################################################*/
	var folder_icon = "/web_operacion/images/";
	var folder_iframe = "/web_operacion/js/";
	var folder_trans = "/web_operacion/images/";

/*############################################################################*/
/* Navigator Version */
/*############################################################################*/
	var useragent = navigator.userAgent;
	var bName = (useragent.indexOf('Opera') > -1) ? 'Opera' : navigator.appName;
	var pos = useragent.indexOf('MSIE');
	var bVer;
	if (pos > -1) {
		bVer = useragent.substring(pos + 5);
		var pos = bVer.indexOf(';');
		bVer = bVer.substring(0,pos);
	}
	
	var pos = useragent.indexOf('Opera');
	if (pos > -1)	{
		bVer = useragent.substring(pos + 6);
		var pos = bVer.indexOf(' ');
		bVer = bVer.substring(0, pos);
	}
	
	if (bName == "Netscape") {
		var bVer = useragent.substring(8);
		var pos = bVer.indexOf(' ');
		bVer = bVer.substring(0, pos);
	}
	
	if (bName == "Netscape" && parseInt(navigator.appVersion) >= 5) {
		var pos = useragent.lastIndexOf('/');
		bVer = useragent.substring(pos + 1);
	}
	
	/*
	// alert("Browser Name: "+ bName + "\nBrowser Version: " + bVer);
	
	function jsMenuKeydown(obj_name, win_event){
		var intKeyCode = win_event.keyCode;
		switch ( intKeyCode ) {
			case 27: //ESC
				jsHideAll(obj_name);
				break;
		}//switch
	}
	*/
/*############################################################################*/
/* Menu */
/*############################################################################*/
	function Menu(name){
		/*
			Objetive:	Objeto wrapper del menu
			Atribute:	- align: 	- 0: Horizontal;
									- 1: Vertical
		*/
		this.align = 0; 				// Alineamiento
		this.items = new Array();		// Array de botones
		this.menuOpened = new Array();	// Guarda los layers abiertos
		this.menuIndex	= 0;
		this.x = 8;							// Coordenada x en la pantalla
		this.y = 125;							// Coordenada y en la pantalla
		this.width;
		this.name = name;
		this.menuLevel = 0;				// Cantidad de niveles
		this.selectHid = 0;				// Bandera que indica si se han ocultado los hidden
		this.parOpened = 0;				// Si se ha abierto el primer nivel del men�. (Parent Opened)
		return this;
	}
	
	// Methods
	Menu.prototype.setAlign = function (align) {
		this.align = align;
	};
	
	Menu.prototype.setParOpened = function (bit) {
		this.parOpened = bit;
	};
	
	Menu.prototype.setItem = function (obj) {
		/* Objetive: Agrega objetos del tipo MenuItem al arreglo */
		var index = this.items.length; 
		this.items[index] = obj; 
		return this.items[index];
	};
	
	Menu.prototype.toHtml = function () {
		var strMenu = ""; 
		var strSubMenu = "";
		var strSubMenuDiv = "";
		var strIcono, strEvent;
		strMenu += "<table border=0 cellpadding=1 cellspacing=0><tr><td><div id=divMenu style='position:relative; z-index:10; visibility: visible;'><table border=0 cellpadding=3 cellspacing=0 name=tlbMenu id=tlbMenu class=clsTable>\n";
		// Vertical
		if (this.align==1){
			for (var i=0; i<this.items.length; i++){
				strEvent = "onClick=\""+this.name+".setParOpened(1); ";
				if (this.items[i].items.length>0){
					strSubMenu += jsSetMenuDiv(i, this.items[i].items, this.name, 1);
					strEvent += " jsShowMenu('"+i+"', this, "+this.name+", 0);\" onMouseOver=\"jsShowMenu('"+i+"', this, "+this.name+", 0)\"";
				}else{
					if (this.items[i].url.length>0){
						strEvent += " window.location='"+this.items[i].url+"'; ";	
					}
					strEvent += " jsShowMenu('', this, "+this.name+", 0);\" onMouseOver=\"jsShowMenu('', this, "+this.name+", 0)\"";
				}
				
				// Icono
				if (this.items[i].icon!=""){
					strIcono = "<img src='"+folder_icon+this.items[i].icon+"' width=16 height=16 border=0>";
				}else{
					strIcono = "&nbsp;";	
				}
				strMenu += "<tr "+strEvent+" onmouseout=\"jsMenuOut(this)\" class=clsMenuItem><td width=16>"+strIcono+"</td><td nowrap>" + this.items[i].title + "</td><td width=16>&nbsp;<!--icono--></td></tr>\n";		
			}
		}
		// Horizontal
			
		strMenu += "</table></td></tr></table>\n";
		
		for (var i=1; i<=this.menuLevel; i++) {
			strSubMenuDiv += "<div id=divFrame"+i+" style='position:absolute; width:50; height:80; z-index:9; visibility: hidden;'><iframe src='"+folder_iframe+"menu_item.htm' name=ifrmBlank"+i+" scrolling='no' border=0></iframe></div>\n"
		}
				
		return strSubMenuDiv + strMenu + strSubMenu + "<div id=divBlank style='position:absolute; height:"+ document.body.clientHeight+"; width:"+document.body.clientWidth+"; z-index:0; top:0; left:0; visibility: hidden;'><a href='javascript:jsVoid()' onclick=\"jsHideAll("+this.name+"); "+this.name+".setParOpened(0);\" class=clsDivBlank><img src=\""+folder_trans+"blank.png\" height="+ document.body.clientHeight+"; width="+document.body.clientWidth+" border=0></a></div>";
	};
	
	Menu.prototype.setup = function (){
		/* Objetive: Setea Coordenadas del Menu */
		var objPosition = jsObjGetPosition("tlbMenu");
		this.x = objPosition.x;
		this.y = objPosition.y;
		this.width = document.all.tlbMenu.clientWidth;
	}

	function jsSetMenuDiv(index, obj, obj_parent, level){
		var strMenu = "";
		var strSubMenu = "";
		var strEvent, strIcono, strArrow;
		
		strMenu += "<div id='divMenu-"+index+"' style='position:absolute; z-index:12; visibility: hidden;' class=clsMenu><table border=0 cellpadding=3 cellspacing=0 width=100 class=clsTable>\n";
		
		if (eval(obj_parent).menuLevel < level) {
			eval(obj_parent).menuLevel = level;
		}
		
		for (var i=0; i<obj.length; i++){
			// Icono
			if (obj[i].icon!=""){
				strIcono = "<img src='"+ folder_icon +obj[i].icon+"' width=16 height=16 border=0>";
			}else{
				strIcono = "&nbsp;";	
			}
			if (obj[i].items.length>0){
				strSubMenu += jsSetMenuDiv(index + "-" + i, obj[i].items, obj_parent, level+1);
				strEvent = "onMouseOver=\"jsShowMenu('"+index + "-" + i +"', this, "+obj_parent+", "+level+")\"";
				strArrow = 4;
			}else{
				strUrl = obj[i].url;
				strEvent = "onMouseOver=\"jsShowMenu('', this, "+obj_parent+", "+level+")\" onClick=\"jsHideAll("+obj_parent+"); ";
				// Para poder llamar una funci�n de Javascript
				if (obj[i].url.indexOf("javascript:") >-1){
					strEvent += obj[i].url.substring(11) +"\"";	
				}else{
					strEvent += "window.location='"+obj[i].url+"'\" oncontextmenu=\"jsMC_RClick('"+obj[i].url+"')\"";
				}
				strArrow = "";
			}
			
			if (obj[i].title.toLowerCase()=="separator"){
				strMenu += "<tr class=clsMenuItem><td colspan=3><div class=\"separator-line\"></div></td></tr>\n";
			}else{
				strMenu += "<tr onmouseout=\"jsMenuOut(this)\" "+strEvent+" class=clsMenuItem><td width=16>"+strIcono+"</td><td nowrap>&nbsp;"+obj[i].title+"</td><td width=20 class=clsArrow>"+strArrow+"</td></tr>\n";
			}
		}
		strMenu += "</table></div>\n";
		return strMenu + strSubMenu
	}
		
/*############################################################################*/
/* MenuItem */
/*############################################################################*/
	function MenuItem(title, url, icon){
		this.title = title;
		this.url = url;
		this.icon = icon;
		this.items = new Array();	// Arreglo de items
				
		this.disabled = false;
		//this.mnemonic = null;
		//this.shortcut = null;
		//this.toolTip = "";
		//this.target = null;			// Para uso con Frames
		this.visible = true;	
		return this;
	}

	// Methods	
	MenuItem.prototype.setItem = function (objMenuItem) {
		var index = this.items.length; 
		this.items[index] = objMenuItem; 
		return this.items[index];
	};
	
	MenuItem.prototype.getTitle = function () {
		return this.title;
	};

/*############################################################################*/
/* Eventos del Menu  */
/*############################################################################*/
	function jsShowMenu(objName, obj, obj_parent, level){
		var x, y, arrLevel, obj_aux;
		
		jsMenuItem_over(obj); // Cambio de Color
		
		if (obj_parent.parOpened == 1){
			document.getElementById("divBlank").style.visibility='visible';
			// Cerrar ventana
			if (obj_parent.menuIndex>0){
				if (obj_parent.menuIndex != level){
					var index = --obj_parent.menuIndex;
					for (var i=index; i>=level ; i-- ){
						document.getElementById("divMenu-" + obj_parent.menuOpened[i].name).style.visibility='hidden';
						document.getElementById("divFrame" + (i+1)).style.visibility='hidden';
					}
				}
				obj_parent.menuIndex = level;
			}
			
			arrLevel = objName.split("-");
			if (objName.length>0){
				if (arrLevel.length == 1){
					x = obj_parent.x;
					y = obj_parent.y;					
				}else{
					x = obj_parent.menuOpened[obj_parent.menuIndex-1].x;
					y = obj_parent.menuOpened[obj_parent.menuIndex-1].y;
				}
				
				x += obj.clientWidth;
				y += obj.offsetTop;
				
				obj_aux = document.getElementById("divMenu-" + objName).style;
				obj_aux.posLeft = x-10;
				obj_aux.posTop = y;
				obj_aux.visibility='visible';
		
				// IE6.0
				if (parseFloat(bVer)>= 6){
					obj_aux = document.getElementById("divFrame" + (level+1)).style;
					obj_aux.posLeft = x-10;
					obj_aux.posTop = y;
					obj_aux.width  = document.getElementById("divMenu-" + objName).clientWidth;
					obj_aux.height = document.getElementById("divMenu-" + objName).clientHeight;
					obj_aux.visibility='visible';

					obj_aux = document.getElementById("ifrmBlank" + (level+1));
					obj_aux.width  = document.getElementById("divMenu-" + objName).clientWidth + 2;
					obj_aux.height = document.getElementById("divMenu-" + objName).clientHeight + 2;
				}else{
					// Oculta todos los objetos <select>
					if (obj_parent.selectHid==0){
						for (var i=0; i<document.all.length; i++) { 
							 o = document.all(i);
							 if (o.type == 'select-one' || o.type == 'select-multiple') { 
								 // todo: add check for select in div? 
								 if (o.style) o.style.display = 'none'; 
							 } 
						}				
						obj_parent.selectHid=1;
					}			
				}	
				obj_parent.menuOpened[level] = new jsMenuPosition(objName, x, y);
				obj_parent.menuIndex++;	
			}
		}
	}
	
	function jsMenuOut(obj){
		jsMenuItem_out(obj)
	}
	
	function jsHideAll(obj){
		// Cerrar todas las ventanas
		document.getElementById("divBlank").style.visibility='hidden';
		if (obj.menuIndex>0){
			var index = --obj.menuIndex;
			for (var i=index; i>=0 ; i-- ){
				document.getElementById("divMenu-" + obj.menuOpened[i].name).style.visibility='hidden';
				if (parseFloat(bVer)>= 6 && i>=0 && i< obj.menuLevel){
					// IE6.0
					document.getElementById("divFrame" + (i+1)).style.visibility='hidden';
				}
			}
			obj.menuIndex = 0;
		}
		// IE6.0
		if (parseFloat(bVer)< 6){
			if (obj.selectHid==1){
				for (var i=0; i<document.all.length; i++) { 
					o = document.all(i);
					 if (o.type == 'select-one' || o.type == 'select-multiple') { 
						 // todo: add check for select in div? 
						 if (o.style) o.style.display = ''; 
					 } 
				}	
				obj.selectHid=0;
			}							
		}
	}
	
	function jsVoid(){}
		
/*############################################################################*/
/* Util  */
/*############################################################################*/
	function jsObjPosition(x, y){
		this.x = x;
		this.y = y;
		return this;	
	};

	function jsMenuPosition(name, x, y){
		this.name = name;
		this.x = x;
		this.y = y;	
	}
	
	function jsObjGetPosition(obj){
		var strTag;
		var objElement = eval("document.all."+obj);
		var strCadena = "objElement";
		var objTag;
		var intTop, intLeft;
		//var intCont; // Sirve para poder obtener la etiqueta que envuelve el input

		//intTop = document.body.clientTop + document.body.offsetTop;
		/*
		if (document.body.topMargin!=""){
			//intTop += parseInt(document.body.topMargin);
		}
		
		//intLeft = document.body.clientLeft + document.body.offsetLeft;

		if (document.body.leftMargin!=""){
			//intLeft += parseInt(document.body.leftMargin);
		}
		*/
		
		intTop = document.body.clientTop + document.body.offsetTop  + eval("document.all."+obj).offsetTop; 
		intLeft = document.body.clientLeft + document.body.offsetLeft + eval("document.all."+obj).clientLeft + eval("document.all."+obj).offsetLeft;
		
		while (strTag != "BODY") {
			strCadena += ".parentNode";
			objTag = eval(strCadena);
			strTag = eval(strCadena + ".tagName");
			
		    if (strTag == "TD"){
		       intTop += objTag.clientTop + objTag.offsetTop;
		       intLeft += objTag.clientLeft + objTag.offsetLeft;
			}
			
			if (strTag == "TABLE"){
				intTop += objTag.clientTop + objTag.offsetTop;
				intLeft += objTag.clientLeft + objTag.offsetLeft;
				if (objTag.cellSpacing != ""){
		  	   		intTop += parseInt(objTag.cellSpacing);
		       		intLeft += parseInt(objTag.cellSpacing);
	       		}
			}
		}
		return new jsObjPosition(intLeft, intTop);
	};
	
	function jsMenuItem_over(obj){
		obj.style.color = "#FF0000";
		obj.style.backgroundColor = "#e8e4b7";
	}

	function jsMenuItem_out(obj){
		obj.style.color = "#006699";
		obj.style.backgroundColor = "#FFFFFF";
	}
	
	function jsMC_win(sUrl,iWidth,iHeight) {   
		var msgWindow;
		var myArgs;
	        
	    myArgs = "width=" + iWidth + "," 
	                 + "height=" + iHeight + "," 
	                 + "location=0," 
	                 + "menubar=0," 
	                 + "resizable=0," 
	                 + "scrollbars=1," 
	                 + "status=0," 
	                 + "titlebar=0," 
	                 + "toolbar=0," 
	                 + "hotkeys=0," 
	                 + "screenx=50," 
	                 + "screeny=50," 
	                 + "left=50," 
	                 + "top=50";           
		msgWindow = open(sUrl, '', myArgs); 
	    msgWindow.focus(); 
	}
	
	function jsMC_RClick(sUrl) {   
		/* Objetive: Al dar click derecho se abre una nueva p�gina */
		var newWindow;
		var myArgs = '';
	   	
		newWindow = open('', '', myArgs); 
		newWindow.document.writeln("<HEAD><TITLE>Portal Nextel</TITLE></HEAD>");
		newWindow.document.writeln("<frameset rows='99%,*' frameborder='NO' border='0' framespacing='0'>");
		newWindow.document.writeln("<frame name='mainFrame' scrolling='AUTO' noresize src='"+sUrl+"'>");
        newWindow.document.writeln("<frame name='bottomFrame' scrolling='NO' noresize src='/websales/Bottom.html'>");
        newWindow.document.writeln("</frameset>");
        newWindow.document.writeln("<noframes><body bgcolor='#FFFFFF'></body></noframes>");
         
		event.returnValue=false;
		//return false;
	    //newWindow.focus(); 
	}