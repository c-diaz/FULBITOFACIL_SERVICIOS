/*
    Developer :   Robert Moreno  
*/

function ItemBorrado(item_id){
   this.item_id = item_id;
}

var vItemsBorrado = new Vector();

function fEditPromotion(idPromoHeader,PromoHeaderName){
   var form = document.frmdatos;
   var item_adde_period, item_adde_type;
   if (getNumRows("items_table")>1){
      item_adde_period  = form.item_adde_period[arguments[2]].value;
      item_adde_type    = form.item_adde_type[arguments[2]].value;
   }else{
      item_adde_period  = form.item_adde_period.value;
      item_adde_type    = form.item_adde_type.value;
   }

   for (var i=1; i < subjArr.length ; i++) {
            subjObj = subjArr[i];
            if (subjObj.subtypeid == form.cmbSubCategoria.value) {
               producttype             = subjObj.product_type;
               handsetallowed          = subjObj.handset_allowed;
               mainobjecttype          = subjObj.main_object_type;
               producthandling         = subjObj.product_handling;
               rateplanhandling        = subjObj.rate_plan_handling;
               additionalservice       = subjObj.additional_service;
               consignmentallowed      = subjObj.consig;
               specialtyid             = subjObj.subtypeid;
               pricetype               = subjObj.price_type;
               servicetype             = subjObj.service_type;
               additionalobjecttype    = subjObj.additional_object_type;
               mainobjectvalidation    = subjObj.main_object_validation;
               additionalobjectvalid   = subjObj.additional_object_valid;
            }
   }

   var frameUrl = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT02_PL_PKG.PL_ORDER_PROMOTION_EDIT"
                  +"?item_index=0"
                  +"&item_code=0"
                  +"&item_product_id="
                  +"&item_product_dsc="
                  +"&item_prod_line_id="
                  +"&item_plan_id="
                  +"&item_plan_dsc="
                  +"&item_quantity="
                  +"&txtnpTelefono="
                  +"&hdnnpTelefonoNuevo="
                  +"&item_imei="
                  +"&hdnnpImeiNuevo="
                  +"&item_product_price="
                  +"&item_except_prodprice="
                  +"&item_total="
                  +"&item_adde_period="            + item_adde_period
                  +"&item_adde_type="              + item_adde_type
                  +"&item_own_equip="
                  +"&hdnnpPromoHeaderId="          + idPromoHeader
                  +"&hdnnpPromoHeaderName="        + PromoHeaderName
                  +"&hdnnpPromoDetailId="
                  +"&hdnnpOracleCode="
                  +"&hdnnpRealImei="
                  +"&item_services="
                  +"&product_type="                + escape(producttype)
                  +"&specialtyid="                 + escape(specialtyid)
                  +"&customer_id_bscs="            + escape(form.txtCodBSCS.value)
                  +"&handset_allowed="             + escape(handsetallowed)
                  +"&main_object_type="            + escape(mainobjecttype)
                  +"&product_handling="            + escape(producthandling)
                  +"&rate_plan_handling="          + escape(rateplanhandling)
                  +"&additional_service_allowed="  + escape(additionalservice)
                  +"&consignment_allowed="         + escape(consignmentallowed)
                  +"&price_type="                  + escape(pricetype)
                  +"&service_type="                + escape(servicetype)
                  +"&tipo_compa�ia="               + escape(form.txtTipoCompania.value)
                  +"&additional_object_type="      + escape(additionalobjecttype)
                  +"&main_object_validate="        + escape(mainobjectvalidation)
                  +"&additional_object_valid="     + escape(additionalobjectvalid)
                  +"&prod_release_id_orig="
                  +"&prod_release_name_orig="
                  +"&plan_orig="
                  +"&plan_id_orig=";
   var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
   var popupWin = window.open(winUrl, "detalle","status=yes, location=0, width=450, height=500, left=50, top=100, screenX=50, screenY=100");
}


/*agrega una nueva promocion*/
function fAddPromotion(){
   var form = document.frmdatos;
   var producttype;
   var handsetallowed;
   var mainobjecttype;
   var producthandling;
   var rateplanhandling;
   var additionalservice;
   var consignmentallowed;
   var pricetype;
   var servicetype;
   var additionalobjecttype;
   var mainobjectvalidation;
   var additionalobjectvalid;

   if (form.cmbSite.length > 1 && form.hdnClientSitesFlag.value == "1") {
      if (form.cmbSite.value==""){
         alert("Seleccione un site de la compa�ia");
         form.cmbSite.focus();
         return;
      }
   }

   if (form.cmbSubCategoria.value != "") {
      var subjObj = null;
      for (i=1; i<subjArr.length ; i++) {
         subjObj = subjArr[i];
         if (subjObj.subtypeid == form.cmbSubCategoria.value) {
            producttype                = subjObj.product_type;
            handsetallowed             = subjObj.handset_allowed;
            mainobjecttype             = subjObj.main_object_type;
            producthandling            = subjObj.product_handling;
            rateplanhandling           = subjObj.rate_plan_handling;
            additionalservice          = subjObj.additional_service;
            consignmentallowed         = subjObj.consig;
            specialtyid                = subjObj.subtypeid;
            pricetype                  = subjObj.price_type;
            servicetype                = subjObj.service_type;
            additionalobjecttype       = subjObj.additional_object_type;
            mainobjectvalidation       = subjObj.main_object_validation;
            additionalobjectvalid      = subjObj.additional_object_valid;
         }
      }
      var form = document.frmdatos;
      var frameUrl = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT02_PL_PKG.PL_ORDER_PROMOTION_EDIT"
                     +"?item_index=0"
                     +"&item_code=-1"
                     +"&item_product_id="
                     +"&item_product_dsc="
                     +"&item_prod_line_id="
                     +"&item_plan_id="
                     +"&item_plan_dsc="
                     +"&item_quantity="
                     +"&txtnpTelefono="
                     +"&hdnnpTelefonoNuevo="
                     +"&item_imei="
                     +"&hdnnpImeiNuevo="
                     +"&item_product_price="
                     +"&item_except_prodprice="
                     +"&item_total="
                     +"&item_adde_period="
                     +"&item_adde_type="
                     +"&item_own_equip="
                     +"&hdnnpPromoHeaderId="
                     +"&hdnnpPromoHeaderName="
                     +"&hdnnpPromoDetailId="
                     +"&hdnnpOracleCode="
                     +"&hdnnpRealImei="
                     +"&item_services="
                     +"&product_type="                + escape(producttype)
                     +"&specialtyid="                 + escape(specialtyid)
                     +"&customer_id_bscs="            + escape(form.txtCodBSCS.value)
                     +"&handset_allowed="             + escape(handsetallowed)
                     +"&main_object_type="            + escape(mainobjecttype)
                     +"&product_handling="            + escape(producthandling)
                     +"&rate_plan_handling="          + escape(rateplanhandling)
                     +"&additional_service_allowed="  + escape(additionalservice)
                     +"&consignment_allowed="         + escape(consignmentallowed)
                     +"&price_type="                  + escape(pricetype)
                     +"&service_type="                + escape(servicetype)
                     +"&tipo_compa�ia="               + escape(form.txtTipoCompania.value)
                     +"&additional_object_type="      + escape(additionalobjecttype)
                     +"&main_object_validate="        + escape(mainobjectvalidation)
                     +"&additional_object_valid="     + escape(additionalobjectvalid)
                     +"&prod_release_id_orig="
                     +"&prod_release_name_orig="
                     +"&plan_orig="
                     +"&plan_id_orig=";
      var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
      var popupWin = window.open(winUrl, "detalle","status=yes, location=0, width=450, height=500, left=50, top=100, screenX=50, screenY=100");
   }
   else {
      alert("Debe seleccionar la Sub Categoria");
      return;
   }
}

function validateSave(){

   form = document.frmdatos;
   /*form.btnGrabar.disabled = true;*/
   /*form.btnGrabarInbox.disabled = true;*/

   if (form.flgSave.value=="1"){ return; }

   var wv_fecha_firma         = form.txtFechaHoraFirma.value.substring(0,10);
   var wv_hora_firma          = form.txtFechaHoraFirma.value.substring(11,16);
   var wn_decrip_long;

   /* COMPA�IA */
   if (form.txtCompany.value == "" && form.txtCompanyId.value == ""){
      alert("Debe seleccionar una Compa�ia");
      form.txtCompany.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   }

   /* FECHA Y HORA DE FIRMA */
   if (form.txtEstadoOrden.value == "TIENDA01" || form.txtEstadoOrden.value == "ADM_VENTAS" || form.txtEstadoOrden.value == "CALLCENTER FF" || form.txtEstadoOrden.value == "BACKOFFICE") {
      if (form.txtFechaHoraFirma.value == ""){
         alert("Debe ingresar la fecha y hora de firma");
         /*form.btnGrabar.disabled = false;*/
         /*form.btnGrabarInbox.disabled = false;*/
         form.txtFechaHoraFirma.select();
         return;
      };
   
      /*if (!isValidDate(wv_fecha_firma) || !isValidHour(wv_hora_firma + ":00") ){*/
      if (!isValidDate(wv_fecha_firma) || !isValidHour(wv_hora_firma) ){
         /*form.btnGrabar.disabled = false;*/
         /*form.btnGrabarInbox.disabled = false;*/
         form.txtFechaHoraFirma.select();
         return;
      };
   };

   /* SITE */
   // Es obligatorio solo si la cuenta se maneja por Sites o Centos de Costo
   var bUnknwnSiteFlg = null;
   try {
      bUnknwnSiteFlg = form.chkUnkwnSite.checked;
   }catch(e) {
      bUnknwnSiteFlg = false;
   }
   
   // Si hay Sites, e sobligatorio seleccionar
   if (form.hdnClientSitesFlag.value == "1") {
      if (form.cmbSite.value == ""  && form.cmbSite.length > 1 ) {
         if (!bUnknwnSiteFlg) {
            alert("Debe seleccionar un Site");
            form.cmbSite.focus();
            /*form.btnGrabar.disabled = false;*/
            /*form.btnGrabarInbox.disabled = false;*/
            return;
         }
      }
   }

   /* Validaci�n de la Descripci�n */
   wn_decrip_long = form.txtDetalle.value.length;
       if ( wn_decrip_long > 4000) {
       alert("El campo 'Descripci�n' tiene " + wn_decrip_long +" letras y es mayor que el maximo permitido (4000). Disminuya la"+
        " cantidad de letras.");
       form.txtDetalle.select();
       return;
    };

   /* VENDEDOR */
   if (form.cmbVendedor.value == "" ){
      alert("Debe seleccionar un Vendedor");
      if (form.cmbVendedor.disabled == false){
         form.cmbVendedor.focus();
      };
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   }
   else {
      form.hdnVendedor.value = form.cmbVendedor.options[form.cmbVendedor.selectedIndex].text;
   };
   
   /* Inicio Data */
   try{
    if (form.hdnDataFieldsVisibles.value == "S"){
      form.hdncmbVendedorData.value    = form.cmbVendedorData.options[form.cmbVendedorData.selectedIndex].text;
      form.hdnVendedorDataId.value    = form.cmbVendedorData.options[form.cmbVendedorData.selectedIndex].value;
      if (form.hdnVendedorDataId.value == ""){
        alert("El Vendedor Data es obligatorio");
        form.cmbVendedorData.focus();
        return false;
      }
    }
  }catch(e){}
  /* Fin Data */

   if (form.txtDirEntrega.value == "" ){
      alert("Debe ingresar la direcci�n de Entrega");
      form.txtDirEntrega.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   };

   if (form.txtNumSolicitud.value == "" ){
      alert("Debe ingresar una Numero de Solicitud");
      form.txtNumSolicitud.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   };

   if (form.cmbCategoria.value == "" ){
      alert("Debe seleccionar una Categor�a");
      form.cmbCategoria.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   }

   if (form.cmbSubCategoria.value == "" ){
      alert("Debe seleccionar una Subcategor�a");
      form.cmbSubCategoria.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   }

   var wv_minutespoolingflg;
   var wv_category   = form.cmbCategoria.options[form.cmbCategoria.selectedIndex].text;
   var wv_subcategory   = form.cmbSubCategoria.options[form.cmbSubCategoria.selectedIndex].text;

   for (var k=1; k < subjArr.length ; k++) {
      subjObj = subjArr[k];
      if (subjObj.subtypeid == form.cmbSubCategoria.value) {
         wv_minutespoolingflg  = subjObj.minutespoolingflg;    
    break;
      }
   }

   //******************************************************//
   //**   MODIFICACION PARA BOLSA                         *//
   //******************************************************//
   // Verificamos si la orden maneja bolsa y valida el ingreso de los campos

   if (wv_minutespoolingflg == "S" && trBolsa.className == "show" ){


      // Verificamos que si se esta realizando una transaccion de BOLSA/DESAC o BOLSA/CAMBIO deba existir una Bols Activa del cliente
      if (form.hdnValidateTransPoolingBag.value == "0" && wv_category == "BOLSA"){
         if (wv_subcategory == "DESACTIVACION" || wv_subcategory == "CAMBIO" ){
            alert("La compa�ia no tiene una Bolsa de Minutos Activa; transacci�n de " + wv_subcategory +" de Bolsa no permitida. Verifique.");
            return false;
         }
      }


      if (form.hdnValidateTransPoolingBag.value == "1" && wv_category == "BOLSA"){

         // Validamos que en Creacion de la bolsa la compa�ia no tenga una bolsa activa.
         if (wv_subcategory == "CREACION"){
            alert("La compa�ia ya tiene una Bolsa de Minutos Activa; transacci�n de " + wv_subcategory +" de Bolsa no permitida.");
            return false;
         }

	 // Validamos que en Cambio de bolsa se seleccione una bolsa distinta a la actual
         if (wv_subcategory == "CAMBIO" && form.hdnProductoBolsaAct.value == form.cmbProductoBolsa.value){
            alert("Para realizar la transacci�n necesita cambiar el tipo de Bolsa de Minutos actual; transacci�n de " + wv_subcategory +" de Bolsa no permitida.");
	    form.cmbProductoBolsa.focus();
            return false;
         }
      }	


      if (!(wv_category == "BOLSA" && wv_subcategory == "DESACTIVACION") ) {

         if (form.cmbProductoBolsa.value != "" && form.hdnProductoBolsaAct.value != form.cmbProductoBolsa.value){

           if (form.txtFechaActiv.value == ""){
              alert("Debe indicar la Fecha Ejecuci�n de la transaci�n de Bolsa");
              form.txtFechaActiv.focus();
              return false;
           }


           if (!isDateFieldBetweenRange(form.txtFechaActiv, 1, 30, "Activaci�n de Bolsa")){
              return false;
           }
								
           if (form.cmbRespPago.value == ""){
              alert("Debe seleccionar un Responsable de Pago");
              form.cmbRespPago.focus();
              return false;
           }
         }
      }
   }
   //******************************************************//


   if (form.txtEstadoOrden.value == "" ){
      alert("Debe indicar el Estado de la Orden");
      form.txtEstadoOrden.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   }

   if (form.cmbFormaPago.selectedIndex==0){
      alert("Debe Seleccionar la Forma de Pago");
      form.cmbFormaPago.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   }

   if (form.cmbLugarAtencion.value==""){
      alert("Debe Seleccionar un Lugar de Atenci�n");
      form.cmbLugarAtencion.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled = false;*/
      return;
   }

   /* Valida Datos adicionales de la orden */
   if (!validateOrdenFieldAdd("table_order_add")){
      return;
   }


   //******************************************************//
   //**   MODIFICACION PARA BOLSA           *//
   //******************************************************//
   // Si la la compa�ia tiene una bolsa activa al momento de
   if (wv_minutespoolingflg == "S" && trBolsa.className == "show" ){
      if (form.cmbProductoBolsa.value != ""){
         if (form.hdnProductoBolsaMinAct.value != ""){
            var wn_size_vector = vProductoBolsaVector.size();
            for(j=0; j<wn_size_vector ; j++){
               objProductoBolsa = vProductoBolsaVector.elementAt(j);
               if (objProductoBolsa.bolsaid == form.cmbProductoBolsa.value){
                  if (parseFloat(form.hdnProductoBolsaMinAct.value) > parseFloat(objProductoBolsa.bolsaincludedmin)){
                     if (!confirm("Ud. selecciono una Bolsa menor a la que tiene actualmente. Su plantilla se reseteara, todos los equipos formaran parte del grupo por defecto y los minutos se redistribuir�n equitativamente. Desea continuar? ")){
                        return false;
                     }
                  }
                  // Guardamos la cantidad de minutos que dispone la bolsa actual
                  form.hdnProductoBolsaMinNew.value = objProductoBolsa.bolsaincludedmin;
               }
            }
         } 
      }
   }
   //******************************************************//


   if (form.flgSave.value   == "1"){
      return;
   }

   /* Obtenemos el valor de los ComboBox que pueden estar deshabilitados */
   form.hdnSite.value               = form.cmbSite.value;
   form.hdnVendedorId.value         = form.cmbVendedor.value;
   form.hdnProductoBolsaId.value    = form.cmbProductoBolsa.value;
   form.hdnFechaActiv.value         = form.txtFechaActiv.value;
   form.hdnRespPagoId.value         = form.cmbRespPago.value;

   form.flgSave.value   = "1";
   // form.cmbVendedor.disabled = false;
   form.target="bottomFrame"
   form.action = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_PL_PKG.PL_AC_ORDER_NEW_SAVE";
   form.submit();
   // form.cmbVendedor.disabled = true;
};


function searchCustomer(){
   form = document.frmdatos;
   v_companhia = form.txtCompany.value;
   if ( v_companhia=="" ){limpiaCampos(); } ;
   url = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_SEARCH_CUSTOMER?av_searchnom="+escape(v_companhia)+"&pv_uso="+"crear";
   url = "/portal/pls/portal/WEBSALES.NPSL_GENERAL_PL_PKG.WINDOW_FRAME?av_title="+escape("Ordenes > Busqueda de Compa�ia")+"&av_url="+escape(url);
   WinAsist = window.open(url,"WinAsist","toolbar=no,location=0,directories=no,status=yes,menubar=0,scrollbars=no,resizable=no,screenX=100,top=80,left=100,screenY=80,width=700,height=500,modal=yes");
};

/* Permite recuperar la informacion de la Compa�ia */
function validateCustomer(){
   form = document.frmdatos;
   if ( form.txtCompany.value!="" && (form.txtCompany.value!=form.hdnCustomerName.value || form.txtCompanyId.value=="")){
      limpiaCampos();
      form.txtNextel.value = "";
      var a = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_PL_PKG.PL_VALIDATE_CUSTOMER?v_companhia="+escape(form.txtCompany.value).replace("+","%2B")+"&v_CustomerId="+"&v_uso="+"crear";
      parent.bottomFrame.location.replace(a);
      if (form.txtCompany!=null)  {
         form.txtCompany.value=""; }
      if (form.txtCompanyId!=null)  {
         form.txtCompanyId.value=""; }
      if (form.hdnCustomerName!=null) {
         form.hdnCustomerName.value=""; }
   }
   else{
      if (form.txtCompany.value==""){
         limpiaCampos();
      };
   }
   /* limpiamos el flag que nos sirve para cargar las Categorias de acuerdo a la empresa */
   form.hdnFlagLoadCategoria.value = 0;
   limpiaCampos_Combo(form.cmbCategoria);
   limpiaCampos_Combo(form.cmbSubCategoria);
   limpiaCampos_Combo(form.cmbRespPago);  

}

/*Elimina todos los items ingresados a la orden*/
function fDeleteAllItems(){
   var table = document.all ? document.all["items_table"]:document.getElementById("items_table");
   var table2 = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   if (getNumRows("items_table")>0){
      for (var i=wn_items; i >0 ; i--)
         fDeleteItemWithoutRecalculate(i);

      if (getNumRows("table_imeis")>0)
         if ((table2.rows.length-1) == 1)
            table2.deleteRow(1);
         else
            for (var i=(table2.rows.length-1); i>0 ; i--)
               table2.deleteRow(i);
   }
   wn_items=(table.rows.length-1);
   CalculateTotalSalesPrice();
}


function fDeleteItemWithoutRecalculate(index){
   var table = document.all ? document.all["items_table"]:document.getElementById("items_table");
   wb_existItem=(wn_items>=1)?false:wb_existItem;
   wb_existItem=(wn_items>2)?true:false;
   table.deleteRow(index);
   wn_items=(table.rows.length-1);
}

function getCustomerDetail2(){
   form = document.frmdatos;
   customerId = form.txtCompanyId.value;
   if (customerId==""){
      alert("Primero debe ingresar el nombre de la empresa");
      return;
   }
   url = "/portal/page/portal/nextel/CUST_DETAIL?customerId=" + customerId;
   url = "/portal/pls/portal/WEBSALES.NPSL_GENERAL_PL_PKG.WINDOW_FRAME?av_title="+escape("PORTAL NEXTEL")+"&av_url="+escape(url);
   window.open(url,"WinCustomer","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,screenX=60,top=40,left=60,screenY=40,width=850,height=600");
   return;
}

function checkEnterKey(e){
   var CR= 13;
   var NS = (window.Event) ? 1 : 0;
   var keycode = (NS) ? e.which : e.keyCode;
   return (keycode == CR);
}

function checkKey(e,num1){
   form = document.frmdatos;
   if (checkEnterKey(e)){
   if (num1==10 || num1==11) {form.txtDetalle.focus(); };
   if (num1==12)             {form.txtDetalle.focus(); };
   };
}

function SelectSiteData(objThis){
   form = document.frmdatos;
   if (objThis.value != ""){
      try {
         form.chkUnkwnSite.checked = false;
      }catch(e) {}
      var txt_Site = parseFloat(objThis.value);
      var txt_subtipo = form.cmbSubCategoria.options[form.cmbSubCategoria.selectedIndex].value;
      parent.bottomFrame.location.replace("/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_LOAD_SITE_DATA?AN_SITE="+txt_Site+"&AV_CREATEBY="+wvs_swcreatedby+"&AN_SWSPECIALTYID="+txt_subtipo);
   }else {
      var a = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_PL_PKG.PL_VALIDATE_CUSTOMER?v_companhia=&v_CustomerId="+form.txtCompanyId.value+"&v_uso="+"crear"+"&v_custcode=";
      parent.bottomFrame.location.replace(a);
   }
}

function ChangeSalesMan(objThis){
   form = document.frmdatos;
   var txtCustomerId    = form.txtCompanyId.value;
   var txtSite          = form.cmbSite.value;
   var txtUnknwnSiteId  = "0";
   try{
      form.hdnUnkwnSiteId.value;
   }catch(e){}
   var txtVendedorId    = objThis.options[objThis.selectedIndex].value; 
   var txtVendedor   = objThis.options[objThis.selectedIndex].text;
   var txtIdspecialty   = form.cmbSubCategoria.options[form.cmbSubCategoria.selectedIndex].value;
   var txtCustAlcanceExclusividad  = form.hdnCustAlcanceExclusividad.value;//JGALINDO
   if (form.hdnOrderCreator.value == txtVendedorId) {
      return;
   }
   if (txtVendedor != ""){
      url= "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_PL_PKG.PL_CHANGE_SALESMAN?an_swcustomerid="+txtCustomerId+"&an_swsiteid="+txtSite+"&an_vendedorid="+txtVendedorId+"&av_vendedorname="+txtVendedor+"&an_swspecialtyid="+txtIdspecialty+"&an_alcExclusivity="+txtCustAlcanceExclusividad+"&an_unknwnSiteId="+txtUnknwnSiteId;
      parent.bottomFrame.location.replace(url);
   }
}

function SelectDealer(objThis){
   form = document.frmdatos;
   var txt_vendedor = objThis.options[objThis.selectedIndex].value;
   
   if (txt_vendedor != ""){
      parent.bottomFrame.location.replace("/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_SELECT_DEALER?AN_IDVENDEDOR="+txt_vendedor);
   }
}


function ValidateSelectedSalesMan(objThis){
   form = document.frmdatos;
   var txtCustomerId   = form.txtCompanyId.value;
   var txtSite         = form.cmbSite.value;
   var txtVendedorId   = objThis.options[objThis.selectedIndex].value;  
   var txtVendedor   = objThis.options[objThis.selectedIndex].text;
   var txtIdspecialty   = form.cmbSubCategoria.options[form.cmbSubCategoria.selectedIndex].value;
   if (txtVendedor != ""){
      url= "/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_VALIDATE_SALESMAN?an_swcustomerid="+txtCustomerId+"&an_swsiteid="+txtSite+"&an_vendedorid="+txtVendedorId+"&av_vendedorname="+txtVendedor+"&an_swspecialtyid="+txtIdspecialty;
      parent.bottomFrame.location.replace(url);
   }
}

function SelectSalesData(objThis){
   form = document.frmdatos;
   var wv_minutespoolingflg;
   MostrarRegiones(); /* Mostramos las regiones de Items, Imeis y Servicios que puedieran estar ocultas */
   OcultarRegiones(); /*  Ocultamos las regiones segun el ProductType */
   LoadProductType(objThis.value); /* Obtenemos el valor de ProductType para la SubCategoria */
   var table2 = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   if (getNumRows("items_table")>0)
      if (!confirm("Se eliminaran los items asociados a este Sub Categoria, desea continuar?")){
         form.cmbSubCategoria.value = form.hdnSubCategoriaIdAnt.value;
         return false;
      }
      else{

         /* Inicio: inicializamos el valor del grupo de items a cero , para volver a ingresar nuevos items */
         form.hdn_item_imei_grupo.value  = 0;

         if (getNumRows("table_imeis")>0)
            if ((table2.rows.length-1) == 1)
               table2.deleteRow(1);
            else
               for (var i=(table2.rows.length-1); i>0 ; i--)
                  table2.deleteRow(i);
      }
   fDeleteAllItems();
   deleteAllValues(form.cmbSelectedServices);  /* borramos el combo de servicios seleccionados */
   var txt_site                        = form.cmbSite.value;
   var txt_customerid                  = form.txtCompanyId.value;
   var txt_subtipo                     = objThis.options[objThis.selectedIndex].value;
   var txt_tipocompania                = form.txtTipoCompania.value;
   form.hdnSubCategoriaIdAnt.value     = objThis.options[objThis.selectedIndex].value;
   form.hdnSubCategoria.value          = objThis.options[objThis.selectedIndex].text;
   wn_flag_lugar_Atencion = 1;  /* habilitamos el flag para ejecutar la funcion "SelectLugarAtencion" */
   LoadEstadoOrden(objThis);

   for (var k=1; k < subjArr.length ; k++) {
      subjObj = subjArr[k];
      if (subjObj.subtypeid == form.cmbSubCategoria.value) {
         wv_minutespoolingflg  = subjObj.minutespoolingflg;
    break;
      }
   }

   // Modificaciones para Bolsa de Minutos
   form.cmbProductoBolsa.value = "";
   form.txtFechaActiv.value    = "";
   form.cmbRespPago.value      = "";

   if (wv_minutespoolingflg == "S"){
      trBolsa.className   =  "show";
   }
   else{
      if (wv_minutespoolingflg == "N"){
         trBolsa.className   =  "hidden";
      }
   }
   // Fin Bolsa.

   if (objThis.value == ""){
      return;
   }

   a = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_LOAD_SALES_SUBTIPO?AN_SWCUSTOMERID="+txt_customerid+"&AN_SWSITEID="+txt_site+"&AN_SWSPECIALTYID="+txt_subtipo+"&AV_SWCREATEBY="+wvs_swcreatedby+"&AVS_SWPERSONID="+wvs_swpersonid+"&ANS_APPID="+wns_appid+"&AN_PEDIDOID="+wn_PedidoId+"&av_tipocompania="+txt_tipocompania;
   parent.bottomFrame.location.replace(a);
   fSetPromotion();
}

function LoadProductType(SubCategoryId){
   var subjObj = null;
   for (i=1; i<subjArr.length ; i++) {
      subjObj = subjArr[i];
      if (subjObj.subtypeid == SubCategoryId) {
         form.hdnProductType.value = subjObj.product_type;}
   }
};

/* funcion que inicialmente muestra las regiones de Items, Imeis y servicios para su posterior manejo */
function MostrarRegiones(){
   divTableItems.className    = "show";
   divImeisItems.className    = "show";
   divServicios.className     = "show";
   divItemCrear.className     = "show";
   divLeyendaTotal.className  = "show";
}

/* funcion que oculta las regiones de Items, Imeis y serviciosde acuerdo al valor del ProductType */
function OcultarRegiones(){
   for (i=1; i < subjArr.length ; i++) {
      subjObj = subjArr[i];
      if (subjObj.subtypeid == document.frmdatos.cmbSubCategoria.value) {
         if (subjObj.product_type == 0) {
            divTableItems.className    = "hidden";
            divImeisItems.className    = "hidden";
            divServicios.className     = "hidden";
            divItemCrear.className     = "hidden";
            divLeyendaTotal.className  = "hidden";
         };
      };
   };
}


/* Obtenemos el valor del WorkflowType de una Sub Categoria */
function LoadWorkflowtype(lugar_atencion_id) {
   form = document.frmdatos;
   var subjObj = null;
   var txt_vtype;
   for (i=1; i < workflowArr.length ; i++) {
      subjObj = workflowArr[i];
      if (subjObj.atentionid == lugar_atencion_id) {
         form.hdnWorkflowType.value = subjObj.workflow;
         txt_vtype =  subjObj.vtype;
         form.hdnLugarDespachoType.value = txt_vtype;
         /*  PARCHE por verificar - JLN 02/07/2004 */
         if (wv_npprocessgroup == "Recursos_Humanos"){
            form.hdnWorkflowType.value = "EMPLEADOS"; };
      }
   }

   if (txt_vtype =="Fisica" && form.cmbFormaPago.value == "Diferido"){
      form.cmbFormaPago.value = "";
      return;
   };
}

function LoadEstadoOrden(objThis) {
   var subjObj = null;
   for (i=1; i < subjArr.length ; i++) {
      subjObj = subjArr[i];
      if (subjObj.subtypeid == objThis.value) {
         document.frmdatos.txtEstadoOrden.value = subjObj.inbox;
         if (subjObj.inbox == "TIENDA01" || subjObj.inbox == "ADM_VENTAS" || subjObj.inbox == "CALLCENTER FF" || subjObj.inbox == "BACKOFFICE") {
            document.frmdatos.txtFechaHoraFirma.readOnly = false; };
         else { document.frmdatos.txtFechaHoraFirma.readOnly = true; }
         return;
      }
   }
}


function makeSubject(subtypeid,inbox,consignment,product_type,handset_allowed,main_object_type,product_handling,rate_plan_handling,additional_service,price_type,service_type,additional_object_type,main_object_validation,additional_object_valid,minutespoolingflg, flagaddenda) {
   this.subtypeid = subtypeid;
   this.inbox = inbox;
   this.consig= consignment;
   this.product_type=product_type;
   this.handset_allowed=handset_allowed;
   this.main_object_type=main_object_type;
   this.product_handling=product_handling;
   this.rate_plan_handling=rate_plan_handling;
   this.additional_service=additional_service;
   this.price_type= price_type;
   this.service_type=service_type;
   this.additional_object_type=additional_object_type;
   this.main_object_validation=main_object_validation;
   this.additional_object_valid=additional_object_valid;
   this.minutespoolingflg = minutespoolingflg;
   this.flagaddenda	= flagaddenda; 	
}


var subjArr = new Array();

function SelectLugarAtencion(subcategoryid) {
   form = document.frmdatos;
   var txt_subcategory     = subcategoryid;
   limpiaCampos_Combo(form.cmbLugarAtencion);
   parent.bottomFrame.location.replace("/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_LOAD_ATENCION_LIST?AN_SPECIALTYID="+txt_subcategory+"&AN_BUILDINGID="+wns_npbuildingid+"&av_processgroup="+wv_npprocessgroup);
};

function limpiaCampos_Combo(theCombo){
// Reseteo lista de sites:
   var agt= navigator.userAgent.toLowerCase();
    var isExplorer = (agt.indexOf("msie") != -1);
   if (form!=null ) {
      if (theCombo=="undefined" || theCombo==null) {
         alert("Site no existe");
      }else{
         if (isExplorer == false){
            deleteOptionNS(form,theCombo)
         }
         else {
            deleteOptionIE(form,theCombo)
          };
       };
    };
}

function LoadListCategorias() {
   form = document.frmdatos;
   if (form.txtCompanyId.value == "") {
      alert("Seleccione un Compa�ia"); return;
   };

   if (form.txtTipoCompania.value == ""){
      alert("El Tipo de compa�ia no es valido");
      form.txtTipoCompania.select();
      form.txtTipoCompania.focus();
      return;
   };

   var wv_swtype = form.txtTipoCompania.value;
   var a = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_GET_ORDERTYPE_LIST?av_processgroup="+wv_npprocessgroup+"&av_swtype="+wv_swtype;
   parent.bottomFrame.location.replace(a);
}


function SelectSubTipoOrden(objThis){
   fSetPromotion();
   form = document.frmdatos;
   if (getNumRows("items_table")>0){
      if (!confirm("Se eliminaran los items asociados a este Categoria, desea continuar?")){
         form.cmbCategoria.value = form.hdnCategoriaIdAnt.value;
         return false;
      }
   }
   form.hdn_item_imei_grupo.value  = 0;
   fDeleteAllItems();
   deleteAllValues(form.cmbSelectedServices);
   if (form.cmbCategoria!=null){
      var txt_TipoOrden = objThis.options[objThis.selectedIndex].value;
      var wv_swtype = form.txtTipoCompania.value;
      limpiaCampos_Combo(form.cmbSubCategoria);
      form.cmbVendedor.disabled=true;
      form.hdnCategoriaIdAnt.value = objThis.value;
      parent.bottomFrame.location.replace("/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_SUB_TIPO_ORDEN?AV_TYPE="+txt_TipoOrden+"&AV_NPPROCESSGROUP="+wv_npprocessgroup+"&av_swtype="+wv_swtype);
   }
}

function makeWorkflow(atentionid,workflow,vtype) {
   this.atentionid   = atentionid;
   this.workflow     = workflow;
   this.vtype        = vtype;
};

var workflowArr = new Array();

function makeSite(siteid,npcodbscs) {
   this.siteid     = siteid;
   this.npcodbscs  = npcodbscs;
};

var SiteArr = new Array();

function CheckDate(obj) {
   var wv_datestr = obj.value;
   var wv_hoy_str = new Date();
   var day_act    = parseFloat(wv_hoy_str.getDate());
   var month_act  = parseFloat(wv_hoy_str.getMonth()+1);
   var year_act   = parseFloat(wv_hoy_str.getYear());

   var wv_message = "La fecha no debe ser anterior a la actual";

   if ( wv_datestr != "" ){
      if ( !isValidDate(wv_datestr)){
         obj.select();
         return;
      };

      var day_new    = parseFloat(wv_datestr.substring(0,2));
      var month_new  = parseFloat(wv_datestr.substring(3,5));
      var year_new   = parseFloat(wv_datestr.substring(6,10));

      if (year_new < year_act){
         alert(wv_message);
         obj.select();
         return;
      };
      if (year_new == year_act){
         if (month_new < month_act){
            alert(wv_message);
            obj.select();
            return;
         };
         if (month_new == month_act){
            if (day_new < day_act){
               alert(wv_message);
               obj.select();
               return;
            };
         }
      }
   }
   return true;
};

function limpiaCampos(){
   fxCleanImgCustValue();
   form = document.frmdatos;
   // Limpieza de Datos Comerciales
   form.txtCompanyId.value = "";
   form.txtCompanyNameCom.value="";
   form.txtRucDisabled.value="";
   form.txtRegion.value="";
   form.txtIndustria.value="";
   form.txtCodBSCS.value="";
   form.txtTipoCuenta.value="";
   form.txtRegionSite.value="";
   form.cmbVendedor.value="";
   form.txtTipoCompania.value="";
   form.txtDealer.value="";
   form.txtScoring.value="";
   form.txtLineaCredito.value="";
   form.txtDirLegal.value="";
   form.txtTelefono.value="";
   form.txtFax.value="";
   form.txtDirEntrega.value="";
   form.txtContactoUsuario.value="";
   form.txtTelefonoContacto.value="";
   form.txtFaxContacto.value="";
   form.txtGerenteGeneral.value="";
   form.txtTelefonoContGeneral.value="";
   form.txtFaxContGeneral.value="";
   form.txtDetalle.value="";
   form.txtNumSolicitud.value="";
   form.cmbCategoria.value="";
   form.cmbSubCategoria.value="";
   form.txtEstadoOrden.value="";
   form.txtFechaProceso.value="";
   form.cmbFormaPago.value="";
   form.txtFechaCancelacion.value="";
   form.txtImporteFactura.value="";
   form.cmbLugarAtencion.value="";
   form.txtDirFacturacion.value="";
   form.txtDirCorrespondencia.value="";
   form.txtContactoPagoFact.value="";
   form.txtTelefonoContPagoFact.value="";
   form.txtFaxContPagoFact.value="";
   form.hdnFlagEquipPlanBolsa.value="";
   try {
      form.hdnUnkwnSiteId.value="0";
      form.hdnSellerRegionId.value="0";
  }catch(e1) {}
   limpiaCampos_Combo(form.cmbSite);
   deleteAllItem("table_order_add");
   fDeleteAllItems();
   try {
      fxHideUnkwnSiteChkBox();
      form.chkUnkwnSite.checked = false;
   }catch(e) {}
}


function editPayment() {
   var form = document.frmdatos;
   var frameUrl = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT02_PL_PKG.PL_ORDER_PAYMENT_EDIT"
                  +"?hdnPagoBanco="          + escape(form.hdnPagoBanco.value)
                  +"&hdnPagoNroVoucher="     + escape(form.hdnPagoNroVoucher.value)
                  +"&hdnPagoImporte="        + escape(form.hdnPagoImporte.value)
                  +"&hdnPagoFecha="          + escape(form.hdnPagoFecha.value)
                  +"&hdnPagoDisponible="     + escape(form.hdnPagoDisponible.value)
                  +"&hdnRuc="                + escape(form.txtRucDisabled.value)
                  +"&txtImporteFactura="     + escape(form.txtImporteFactura.value)
                  +"&hdnTotalPaymentOrig="   + escape(form.hdnTotalPaymentOrig.value);
   var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
   var popupWin = window.open(winUrl, "Orden_Pagos","status=yes, location=0, width=450, height=500, left=50, top=100, screenX=50, screenY=100");
};


function fMuestraHelpFechaHora(){
   alert("Ejemplo de formato Fecha Hora Firma: 14/07/2004 16:05");
};

function fCopyCodBSCS(){
   var form = document.frmdatos;
   if (form.txtCodBSCS.value != ""){
      var txt_CodBSCS = form.txtCodBSCS.value;
      window.clipboardData.setData("Text",txt_CodBSCS);
      return;
   };
};


function fVerifModifDirEntrega(objThis){
   if (trim(objThis.value.toUpperCase()) != trim(document.frmdatos.hdnDirEntrega.value.toUpperCase())){
      document.frmdatos.txtDirEntregaMensaje.className = "show";
   };
   else {
      document.frmdatos.txtDirEntregaMensaje.className = "hidden"; }
};

 function fCopiaOdenId(){
      form = document.frmdatos;
      form.txtNumSolicitud.value = "P" + wn_PedidoId;
      form.txtNumSolicitud.focus();
      return;
   };


function fCopyVendedor(){
   var form = document.frmdatos;
   if (form.cmbVendedor.value != ""){
      var txt_Vendedor = form.cmbVendedor.options[form.cmbVendedor.selectedIndex].text;
      window.clipboardData.setData("Text",txt_Vendedor);
      return;
   };
};

function fValidarFormaPago(objThis){
   var form = document.frmdatos;
   var forma_pago = objThis.value

   if (forma_pago != ""){
      var tipo_LugarDespacho = fGetTypeDespacho(form.cmbLugarAtencion.value);
      if (forma_pago == "Diferido" && tipo_LugarDespacho != "Fulfillment" && form.cmbLugarAtencion.value != ""){
         form.cmbFormaPago.value = "";
         alert("Esta forma de pago no esta disponible para Tienda");
         return;
      };

      if (forma_pago == "Descuento por Planilla" && form.txtTipoCompania.value != "Employee"){
         form.cmbFormaPago.value = "";
         alert("Esta forma de pago s�lo es disponible para empleados");
         return;
      };
   }
   form.hdnFormaPagoOrig.value = form.cmbFormaPago.value;
};

function fGetTypeDespacho(lugar_despacho){
   for (i=1; i < workflowArr.length ; i++) {
      subjObj = workflowArr[i];
      if (subjObj.atentionid == lugar_despacho) {
         return subjObj.vtype;
      };
   };
};

function clearFields() {
   var form = document.frmdatos;
   for (i=0; i < wn_items; i++) {
      clearItemFields(i);
   }
}

function clearItemFields(item_index) {
   var form = document.frmdatos;
   if (getNumRows("items_table")>1){
      form.item_code[item_index].value = "-1";
      form.item_product_id[item_index].value = "";
      form.item_product_dsc[item_index].value = "";
      form.item_prod_line_id[item_index].value = "";
      form.item_plan_id[item_index].value = "";
      form.item_plan_dsc[item_index].value = "";
      form.item_quantity[item_index].value = "";
      form.txtnpTelefono[item_index].value = "";
      form.hdnnpTelefonoNuevo[item_index].value = "";
      form.item_imei[item_index].value = "";
      form.hdnnpImeiNuevo[item_index].value = "";
      form.item_product_price[item_index].value = "";
      form.item_except_prodprice[item_index].value = "";
      form.item_total[item_index].value = "";
      form.item_adde_period[item_index].value = "";
      form.item_adde_type[item_index].value = "";
      form.item_own_equip[item_index].value = "";
      form.hdnnpPromoHeaderId[item_index].value = "";
      form.hdnnpPromoDetailId[item_index].value = "";
      form.hdnnpOracleCode[item_index].value = "";
      form.hdnnpRealImei[item_index].value = "";
      form.item_services[item_index].value = "";
   }
   else{
      form.item_code              .value = "-1";
      form.item_product_id        .value = "";
      form.item_product_dsc       .value = "";
      form.item_prod_line_id      .value = "";
      form.item_plan_id           .value = "";
      form.item_plan_dsc          .value = "";
      form.item_quantity          .value = "";
      form.txtnpTelefono          .value = "";
      form.hdnnpTelefonoNuevo     .value = "";
      form.item_imei              .value = "";
      form.hdnnpImeiNuevo         .value = "";
      form.item_product_price     .value = "";
      form.item_except_prodprice  .value = "";
      form.item_total             .value = "";
      form.item_adde_period       .value = "";
      form.item_adde_type         .value = "";
      form.item_own_equip         .value = "";
      form.hdnnpPromoHeaderId     .value = "";
      form.hdnnpPromoDetailId     .value = "";
      form.hdnnpOracleCode        .value = "";
      form.hdnnpRealImei          .value = "";
      form.item_services          .value = "";
   }
}

function round(number,X) {
   X = (!X ? 2 : X);
   return Math.round(number*Math.pow(10,X))/Math.pow(10,X);
}

/* Funciones que calculan los datos ingresados */
function CalculateTotalByItem(item_number) {
   var form = document.frmdatos;
   if (getNumRows("items_table")>1) {
      var price = form.item_product_price[item_number].value;
      var exc_price = form.item_except_prodprice[item_number].value;
      price = (exc_price!="")?exc_price:price;
      var pos_coma  = price.indexOf(",",0);
      var pos_final = price.length;
      var price_new = price.substring(0,pos_coma) + price.substring(pos_coma+1,pos_final);
      var total = parseFloat(form.item_quantity[item_number].value)*parseFloat(price_new);
      if ( total >= 0 ) {
         form.item_total[item_number].value = CompletarNumeroDec(""+total);
      }else {
         form.item_total[item_number].value = "";
      }
   }
   else{
     var price = form.item_product_price.value;
     var exc_price = form.item_except_prodprice.value;
     price = (exc_price!="")?exc_price:price;
     var pos_coma  = price.indexOf(",",0);
     var pos_final = price.length;
     var price_new = price.substring(0,pos_coma) + price.substring(pos_coma+1,pos_final);
     var total = parseFloat(form.item_quantity.value)*parseFloat(price_new);
     if ( total >= 0 ) {
        form.item_total.value = CompletarNumeroDec(""+total)
     }else {
        form.item_total.value = "";
     }
   }
}

function CalculateTotalSalesPrice() {
   var form = document.frmdatos;
   var nrows=getNumRows("items_table");
   var total = 0;
   if (nrows> 1) {
     for (i=0; i < wn_items; i++) {
        valor = form.item_total[i].value;
        if (valor!="") {
           total = total + eval(valor) ;
        }
     }
   }
   if (nrows == 1){
      if (!wb_existItem) {
         valor = form.item_total.value;
         if (typeof(form.item_total.value) == "undefined"){
            valor = form.item_total[0].value;
         }
      }else{
         valor = form.item_total[0].value;
      }
      if (valor!="") {
         total = total + eval(valor) ;
      }
   }
   form.txtTotalSalesPrice.value = ( total != 0 )?CompletarNumeroDec(""+round(eval(total),2)):0;
   form.txtImporteFactura.value = ( total != 0 )?CompletarNumeroDec(""+round(eval(total),2)):0;
   var ImpFactura        =  form.txtImporteFactura.value;
   var TotalPaymentOrig  =  form.hdnTotalPaymentOrig.value;
   var PagoDisponible    =  form.hdnPagoDisponible.value;
   var TotalPayment      =  (Math.min(parseFloat((ImpFactura==""?"0":ImpFactura)),parseFloat((TotalPaymentOrig=="")?"0":TotalPaymentOrig) + parseFloat((PagoDisponible=="")?"0":PagoDisponible))).toString();
   /*Debo actualizar el Total pagado, ya que se ha modificado el importe de la Factura.*/
   if (parseFloat(TotalPaymentOrig) > 0 && parseFloat(TotalPaymentOrig) > parseFloat(ImpFactura)){
      form.txtnpTotalPayment.value  = ( TotalPaymentOrig!= 0 )?CompletarNumeroDec(""+round(eval(TotalPaymentOrig),2)):"0"; //TotalPaymentOrig;
   }
   else{
      form.txtnpTotalPayment.value   = ( TotalPayment != 0 )?CompletarNumeroDec(""+round(eval(TotalPayment),2)):"0";
   }
   /*Actualizamos el Saldo.*/
   var SaldoPayment = ((ImpFactura - form.txtnpTotalPayment.value)=="")?"0":(ImpFactura - form.txtnpTotalPayment.value);
   form.txtSaldo.value = ( SaldoPayment != 0 )?CompletarNumeroDec(""+round(eval(SaldoPayment),2)):0;
}

function SetZeroToBlank(quantity) {
   return (quantity == 0)?"":""+quantity;
}


function clearItemFields(item_index) {
   var form = document.frmdatos;
   if (getNumRows("items_table")>1){
      form.item_code[item_index].value = "-1";
      form.item_product_id[item_index].value = "";
      form.item_product_dsc[item_index].value = "";
      form.item_prod_line_id[item_index].value = "";
      form.item_plan_id[item_index].value = "";
      form.item_plan_dsc[item_index].value = "";
      form.item_quantity[item_index].value = "";
      form.txtnpTelefono[item_index].value = "";
      form.hdnnpTelefonoNuevo[item_index].value = "";
      form.item_imei[item_index].value = "";
      form.hdnnpImeiNuevo[item_index].value = "";
      form.item_product_price[item_index].value = "";
      form.item_except_prodprice[item_index].value = "";
      form.item_total[item_index].value = "";
      form.item_adde_period[item_index].value = "";
      form.item_adde_type[item_index].value = "";
      form.item_own_equip[item_index].value = "";
      form.hdnnpPromoHeaderId[item_index].value = "";
      form.hdnnpPromoDetailId[item_index].value = "";
      form.hdnnpOracleCode[item_index].value = "";
      form.hdnnpRealImei[item_index].value = "";
      form.item_services[item_index].value = "";
   }
   else{
      form.item_code              .value = "-1";
      form.item_product_id        .value = "";
      form.item_product_dsc       .value = "";
      form.item_prod_line_id      .value = "";
      form.item_plan_id           .value = "";
      form.item_plan_dsc          .value = "";
      form.item_quantity          .value = "";
      form.txtnpTelefono          .value = "";
      form.hdnnpTelefonoNuevo     .value = "";
      form.item_imei              .value = "";
      form.hdnnpImeiNuevo         .value = "";
      form.item_product_price     .value = "";
      form.item_except_prodprice  .value = "";
      form.item_total             .value = "";
      form.item_adde_period       .value = "";
      form.item_adde_type         .value = "";
      form.item_own_equip         .value = "";
      form.hdnnpPromoHeaderId     .value = "";
      form.hdnnpPromoDetailId     .value = "";
      form.hdnnpOracleCode        .value = "";
      form.hdnnpRealImei          .value = "";
      form.item_services          .value = "";
   }
}



function deleteAllValues(listField){
   for (i=listField.options.length-1; i>=0; i--){
      listField.options[i] = null;
   };
   /* si lo que borramos es el comoBox de Servicios  "*/
   if (listField.name == "cmbSelectedServices"){
      oOption = parent.mainFrame.document.createElement("option");
      oOption.value  = "";
      oOption.text   = "                  ";
      listField.add(oOption);
   };
}



/* no hace nada*/
    function fVoid(){
    };



/*function deleteItem(CellObject,item_id){
   var form = document.frmdatos;
   var item_pedido_numero = CellObject.parentNode.parentNode.parentNode.rowIndex;
   /* inicioFelipe 
   var item_promo_header_id = CellObject.parentNode.parentNode.childNodes.item(3).getAttribute("value");

   // finFelipe
      if (confirm("Desea eliminar el item?")){
         if (deleteItemEnabled){
            var table = document.all ? document.all["items_table"]:document.getElementById("items_table");
            wb_existItem=(wn_items>=1)?false:wb_existItem;
            wb_existItem=(wn_items>2)?true:false;
            DeleteItemImeis(item_pedido_numero);
            table.deleteRow(CellObject.parentNode.parentNode.parentNode.rowIndex);
            wn_items=(table.rows.length-1);
            if (item_id > 0) {
               vItemsBorrado.addElement(new ItemBorrado(item_id));
            };
            fSetNroItemOrder(wn_items);
            CalculateTotalSalesPrice();
            if (parseInt(document.frmdatos.hdnItemSelectService.value) == parseInt(item_pedido_numero) ){
               deleteAllValues(document.frmdatos.cmbSelectedServices);
            };
         }else {
            alert("No puede eliminar, cierre antes la ventana de edici�n de Items");
         };
         return false;
      }
   /*}      /
}*/

function DeleteItemImeis(item_row){
   var form = document.frmdatos;
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   var num_items = table.rows.length - 1;
   var cantidad_prod = 0;
   var borro_item_imei = false;
   var long_new_table; /* obtenemos la longuitud de la nueva tabla, despues de borrar los items */
   /* Inicio: Borrado de los items_imeis correspondientes a los items_pedido */
   if (table.rows.length  == 2){
      if (form.hdnIndice_imei.value == undefined){
         if (form.hdnIndice_imei[0].value == item_row){
            table.deleteRow(1); };
      }
      else{
         if (form.hdnIndice_imei.value == item_row){
            table.deleteRow(1); };
      };
   };
   else{
      if (table.rows.length > 2){
         for (k=(num_items-1); k >= 0; k--){
            if (k>0){
               if (form.hdnIndice_imei[k].value == item_row){
                  table.deleteRow(k+1); }
            };
            else{
               if (k==0){
                  if ( form.hdnIndice_imei.value == item_row )
                     table.deleteRow(1);
                  else
                     if ( form.hdnIndice_imei[0].value == item_row )
                        table.deleteRow(1);
               };
            };
         };
      };
   }; /* Fin */
   long_new_table = table.rows.length;
   /* Actualizamos los hidden que guardan el n�mero de item_pedido correspondiente */
   if (long_new_table == 2 ){
      if (num_items > 1){
         if (form.hdnIndice_imei[0].value > (item_row)){
            form.hdnIndice_imei[0].value = parseInt(form.hdnIndice_imei[0].value) - 1;}
      }
      else{
         if (num_items == 1){
            if (form.hdnIndice_imei.value == undefined){
               if (form.hdnIndice_imei[0].value > (item_row)){
                  form.hdnIndice_imei[0].value = parseInt(form.hdnIndice_imei[0].value) - 1;}
            }
            else{
               if (form.hdnIndice_imei.value > (item_row)){
                  form.hdnIndice_imei.value = parseInt(form.hdnIndice_imei.value) - 1;}
            }
         }
      }
   }
   else{
      if (long_new_table > 2){
         for (k=0; k <(long_new_table - 1); k++){
            if (form.hdnIndice_imei[k].value > (item_row)){
               form.hdnIndice_imei[k].value = parseInt(form.hdnIndice_imei[k].value) - 1;}
         };
      };
   };

   /*  Seleccionamos el primer item_imei que se encuentra vacio para continuar registrando imeis   */
   if (long_new_table == 2){
      form.item_imei_radio.checked = true;
      form.hdn_item_imei_selecc.value = 0; }
   else {
      if (long_new_table > 2){
         for (m=0; m<(long_new_table - 1); m++){
            if (form.item_imei_imei[m].value==""){
               form.item_imei_radio[m].checked = true;
               form.hdn_item_imei_selecc.value = m;
               return false;  }
         };
      };
   };
}

/* Para setear el numero de item del detalle del Pedido, despues de haber eliminado un item */
function fSetNroItemOrder(num_items){
   var table = document.all ? document.all["items_table"]:document.getElementById("items_table");
   var tbody = table.childNodes.item(0); //tbody
   var rows  = tbody.childNodes;
   var row;
   if (num_items == 0){
      return; }
   else{
      if (num_items > 0){
         for(var i=1;i<=num_items;i++){
            row=rows.item(i);
            element = row.getElementsByTagName("a");
            element.item(0).setAttribute("href","javascript:ChangeItemDetail("+(i-1).toString()+");");
         }
      }
   }
}

function getNumRows(tableID){
   var table = document.all ? document.all[tableID]:document.getElementById(tableID);
   return (table.rows.length-1) ; //restandole la cabecera de detalle
}

function enabledDelete(){
   deleteItemEnabled=true;
}

function fSetPromotion(){
   var mainobjecttype, pricetype, additionalobjecttype;
   for (var i=1; i<subjArr.length ; i++) {
      subjObj = subjArr[i];
      if (subjObj.subtypeid == form.cmbSubCategoria.value) {
         mainobjecttype             = subjObj.main_object_type;
         pricetype                  = subjObj.price_type;
         additionalobjecttype       = subjObj.additional_object_type;
      }
   }
   if (mainobjecttype=="H" && additionalobjecttype=="N" && pricetype==1){
      CellPromotion.className="show";
   }else{
      CellPromotion.className="hidden";
   }
}



function ChangeItemNewDetail(window_type) {
   
   var form = document.frmdatos;
   var producttype;
   var handsetallowed;
   var mainobjecttype;
   var producthandling;
   var rateplanhandling;
   var additionalservice;
   var consignmentallowed;
   var pricetype;
   var servicetype;
   var additionalobjecttype;
   var mainobjectvalidation;
   var additionalobjectvalid;
   var flagaddenda;

   var bUnknwnSiteFlg = null;
   try {
      bUnknwnSiteFlg = form.chkUnkwnSite.checked;
   }catch(e) {
      bUnknwnSiteFlg = false;
   }

   // Si hay Sites, e sobligatorio seleccionar
   if (form.hdnClientSitesFlag.value == "1") {
      if (form.cmbSite.value == ""  && form.cmbSite.length > 1 ) {
         if (!bUnknwnSiteFlg) {
            alert("Debe seleccionar un Site");
            form.cmbSite.focus();
            return;
         }
      }
   }

   if (form.cmbCategoria.value == ""){
      alert("Debe seleccionar una Categoria");
      form.cmbCategoria.focus();
      return;
   };

   if (form.cmbSubCategoria.value == ""){
      alert("Debe seleccionar una Sub Categoria");
      form.cmbSubCategoria.focus();
      return;
   };

   if (form.cmbSubCategoria.value != "") {
      var subjObj = null;
      for (i=1; i<subjArr.length ; i++) {
         subjObj = subjArr[i];
         if (subjObj.subtypeid == form.cmbSubCategoria.value) {
            producttype                = subjObj.product_type;
            handsetallowed             = subjObj.handset_allowed;
            mainobjecttype             = subjObj.main_object_type;
            producthandling            = subjObj.product_handling;
            rateplanhandling           = subjObj.rate_plan_handling;
            additionalservice          = subjObj.additional_service;
            consignmentallowed         = subjObj.consig;
            specialtyid                = subjObj.subtypeid;
            pricetype                  = subjObj.price_type;
            servicetype                = subjObj.service_type;
            additionalobjecttype       = subjObj.additional_object_type;
            mainobjectvalidation       = subjObj.main_object_validation;
            additionalobjectvalid      = subjObj.additional_object_valid;
 	    flagaddenda		       = subjObj.flagaddenda;
         }
      }

      var frameUrl = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT03_PL_PKG.PL_ORDER_ITEM_EDIT"
                     +"?item_index=0"
                     +"&item_typeWindow=" + window_type
                     +"&item_code=-1"
                     +"&item_product_id="
                     +"&item_product_dsc="
                     +"&item_prod_line_id="
                     +"&item_plan_id="
                     +"&item_plan_dsc="
                     +"&item_quantity="
                     +"&txtnpTelefono="
                     +"&hdnnpTelefonoNuevo="
                     +"&item_imei="
                     +"&hdnnpImeiNuevo="
                     +"&item_product_price="
                     +"&item_except_prodprice="
                     +"&item_total="
                     +"&item_adde_period="
                     +"&item_adde_type="
                     +"&item_own_equip="
                     +"&item_own_equip_new="
                     +"&hdnnpPromoHeaderId="
                     +"&hdnnpPromoDetailId="
                     +"&hdnnpOracleCode="
                     +"&hdnnpRealImei="
                     +"&item_services="
                     +"&product_type="                + escape(producttype)
                     +"&specialtyid="                 + escape(specialtyid)
                     +"&customer_id_bscs="            + escape(form.txtCodBSCS.value)
                     +"&handset_allowed="             + escape(handsetallowed)
                     +"&main_object_type="            + escape(mainobjecttype)
                     +"&product_handling="            + escape(producthandling)
                     +"&rate_plan_handling="          + escape(rateplanhandling)
                     +"&additional_service_allowed="  + escape(additionalservice)
                     +"&consignment_allowed="         + escape(consignmentallowed)
                     +"&price_type="                  + escape(pricetype)
                     +"&service_type="                + escape(servicetype)
                     +"&tipo_compa�ia="               + escape(form.txtTipoCompania.value)
                     +"&additional_object_type="      + escape(additionalobjecttype)
                     +"&main_object_validate="        + escape(mainobjectvalidation)
                     +"&additional_object_valid="     + escape(additionalobjectvalid)
                     +"&prod_release_id_orig="
                     +"&prod_release_name_orig="
                     +"&plan_orig="
                     +"&plan_id_orig="
                     +"&av_npadditionaldrivingfield="
                     +"&av_called_from="              + "ORD"
                     +"&hdnmodality="
                     +"&hdnreplacementmode="
		     +"&hdnaddendahandling="          + escape(flagaddenda);



      var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
      var popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
   };
}

function fCargaImei(objThis){
   if (glastKey==9){
      AddImei(objThis)}
};



function SeteaItemIndex(objThis){
   var oindexRow = objThis.parentNode.parentNode.rowIndex;
   form.hdn_item_imei_selecc.value = oindexRow -1;
}

function fValidaSimImeiRepetido(sim_imei_new){
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   for(i=0 ; i< (table.rows.length - 1) ; i++){
      if (form.item_imei_imei[i].value != "" && form.item_imei_imei[i].value == sim_imei_new){
         alert("SIM/IMEI ya esta registrado, verifique");
         form.txtImeis.focus();
         return true;
      };
   };
   return false;
};

function LastKeyDown(){
    glastKey = window.event.keyCode;
};

function AddImei(objThis){
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   var row_activo = false;
   var item_index;

   if (objThis.value == ""){
      return;
   };

   if (table.rows.length < 2){
      alert("No se puede realizar la acci�n");
      form.txtImeis.select();
      return;
   };

   if (table.rows.length == 2){
      if (form.item_imei_imei.value=="")
         row_activo = true;
   }
   else{
      if (table.rows.length > 2){
         if (fValidaSimImeiRepetido(objThis.value)){
            form.txtImeis.select();
            return; }

         for (m=0; m<(table.rows.length - 1); m++){
            if (form.item_imei_imei[m].value==""){
               row_activo = true;
               break; }
         }
      }
   }

   if (row_activo==false){
      alert("No se puede registrar el SIM/IMEI");
      form.txtImeis.select();
      return false;  };

   if (objThis.value.length != 15 || !ContentOnlyNumber(objThis.value) ) {
      alert("N�mero de SIM/IMEI no valido");
      form.txtImeis.select();
      return; };

   if (form.hdn_item_imei_selecc.value == ""){
      alert("Seleccione un Item de SIM/IMEI");
      form.txtImeis.select();
      return false; }

   if (row_activo){
      if (objThis.value!=""){
         if (table.rows.length == 2){
            if (form.item_imei_imei.value == ""){
               form.item_imei_imei.value = objThis.value;
               grid_region.scrollTop=table_imeis.childNodes.item(0).childNodes.item(1).childNodes.item(0).offsetTop;}
            else {
               alert("El campo seleccionado ya esta registrado");
               form.txtImeis.select();
               return false; };
         }
         else {
            if (form.item_imei_imei[form.hdn_item_imei_selecc.value].value == ""){
               form.item_imei_imei[form.hdn_item_imei_selecc.value].value = objThis.value;
               grid_region.scrollTop=table_imeis.childNodes.item(0).childNodes.item(form.hdn_item_imei_selecc.value).childNodes.item(0).offsetTop;};
            else{
               alert("El campo seleccionado ya esta registrado.");
               form.txtImeis.select();
               return false; };
         };
         objThis.value = "";
         if (table.rows.length==2){
            if (form.item_imei_imei.value==""){
               form.item_imei_radio.checked = true;
               form.hdn_item_imei_selecc.value = 0; };
         }
         else{
            if (table.rows.length > 2){
               for (m=0; m<(table.rows.length - 1); m++){
                  if (form.item_imei_imei[m].value==""){
                     form.item_imei_radio[m].checked = true;
                     form.hdn_item_imei_selecc.value = m;
                     break; }
               }
            }
         }
         form.hdnFlagItemImeis.value = "1";
      };
   }
   form.txtImeis.focus();
}

function ImeiBorra(){
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   if (table.rows.length < 2){
      alert("No se puede realizar la acci�n");
      return; };

   if (table.rows.length > 2){
      if (form.item_imei_imei[form.hdn_item_imei_selecc.value].value ==""){
         alert("No se puede realizar la acci�n, SIM/IMEI vacio");
         return; }
   };

   if (table.rows.length == 2){
      if (form.item_imei_imei.value ==""){
            alert("No se puede realizar la acci�n, SIM/IMEI vacio");
            return false;
      };
   };

   if (confirm("Desea borrar el SIM/IMEI de este item?")){
      if (form.hdn_item_imei_selecc.value == ""){
         alert("Seleccione un item");}
      else{
         try{
          parent.mainFrame.document.frmdatos.hdnChangedOrder.value="S";
         }catch(e){;}
         if (table.rows.length > 2){
            form.item_imei_imei[form.hdn_item_imei_selecc.value].value = "";
            form.item_imei_check[form.hdn_item_imei_selecc.value].value = "N"; }
         else{
            form.item_imei_imei.value = "";
            form.item_imei_check.value = "N"; }
      }
   }
};

      /*
        JPEREZ: 19/06/08
        Se modifica por cambio en espicificaciones: Ya no ser� Bad IMEI sino Bad SIM
        (el SIM es el que se marca como defectuoso)        
      */
function ImeiBadImei(){
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   if (table.rows.length < 2){
      alert("No se puede realizar la acci�n");
      return;
   };

   if (table.rows.length > 2){
      if (form.item_imei_sim[form.hdn_item_imei_selecc.value].value ==""){
         alert("No se puede realizar la acci�n, SIM/IMEI vacio");
         return false;
      }
      else {
         form.item_imei_bad[form.hdn_item_imei_selecc.value].value = form.item_imei_sim[form.hdn_item_imei_selecc.value].value ;
         form.item_imei_sim[form.hdn_item_imei_selecc.value].value = "";
      }
   }
   else {
      if (form.item_imei_sim.value ==""){
         alert("No se puede realizar la acci�n, SIM/IMEI vacio");
         return false;
      };
      else {
         form.item_imei_bad.value = form.item_imei_sim.value;
         form.item_imei_sim.value = "";
      }
   }
   try{
    parent.mainFrame.document.frmdatos.hdnChangedOrder.value="S";
   }catch(e){;}
};

function ImeiCkeckAll(){
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   var vForm = parent.mainFrame.document.frmdatos;
   if (table.rows.length < 2){
      alert("No se puede realizar la acci�n");
      return;
   };

   if (table.rows.length > 2)
      for(i=0; i<(table.rows.length - 1); i++)
         form.item_imei_check[i].value = "S";
   else
      form.item_imei_check.value = "S";
  
  try{
    vForm.hdnChangedOrder.value="S";
  }catch(e){;}
};

function ImeiUncheckOne(){
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   var vForm = parent.mainFrame.document.frmdatos;
   if (table.rows.length < 2){
      alert("No se puede realizar la acci�n");
      return;
   };

   if (table.rows.length > 2)
      form.item_imei_check[form.hdn_item_imei_selecc.value].value = "N";
   else
      form.item_imei_check.value = "N";
  
  try{
    vForm.hdnChangedOrder.value="S";
  }catch(e){;}
};


function ImeiListaImies() {
   table2 = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   table = document.all ? document.all["tableImeisAux"]:document.getElementById("tableImeisAux");
   var elmTBODY = document.getElementById("CuerpoTabla");
   var elmTR;
   var elmTD;
   var elmText;
   var j=0;
   var imei=""; //CEM

   if (table2.rows.length < 2){
      alert("No se puede realizar la acci�n");
      return;
   };

   if (document.all) {
      if (table2.rows.length > 2){
         for(i=0 ; i< (table2.rows.length - 1) ; i++){
            if (form.item_imei_imei[i].value != ""){
               var row = table.insertRow(-1);
               var cell = row.insertCell(j);
               elmText = form.item_imei_imei[i].value;
			   imei=imei+form.item_imei_imei[i].value+"\n"; //CEM
               cell.innerHTML = elmText;
            };
         };
      };
      else {
         if (table2.rows.length == 2){
            if (form.item_imei_imei.value != ""){
               var row = table.insertRow(-1);
               var cell = row.insertCell(j);
               elmText = form.item_imei_imei.value;
			   imei=imei+form.item_imei_imei[i].value+"\n"; //CEM
               cell.innerHTML = elmText;
            };
         };
      };
   }
   event.returnValue = false;
   //window.clipboardData.setData("Text",divDataImeis.innerHTML);
   window.clipboardData.setData("Text",imei); //CEM   
   alert("Data copiada exit�samente!");   
   /* Limpiamos la tabla  */
   var longuitud = table.rows.length - 1;
   for(i= longuitud ; i>=0 ; i--){
      table.deleteRow(i);
   }
   return;
}

function ChangeItemDetail(item_index) {
   var form = document.frmdatos;
   var num_rows = getNumRows("items_table");
/*
   if (getNumRows("items_table")>1){
      var idPromoheader    =  form.hdnnpPromoHeaderId[item_index].value;
      var PromoHeaderName  =  form.hdnnpPromoHeaderName[item_index].value;
   }else{
      var idPromoheader    =  form.hdnnpPromoHeaderId.value;
      var PromoHeaderName  =  form.hdnnpPromoHeaderName.value;
   }
   if (idPromoheader!="" && idPromoheader!=0 && idPromoheader!="0"){
      fEditPromotion(idPromoheader,PromoHeaderName,item_index);
      return ;
   }
*/
   for (i=1; i < subjArr.length ; i++) {
      subjObj = subjArr[i];
      if (subjObj.subtypeid == form.cmbSubCategoria.value) {
         producttype             = subjObj.product_type;
         handsetallowed          = subjObj.handset_allowed;
         mainobjecttype          = subjObj.main_object_type;
         producthandling         = subjObj.product_handling;
         rateplanhandling        = subjObj.rate_plan_handling;
         additionalservice       = subjObj.additional_service;
         consignmentallowed      = subjObj.consig;
         specialtyid             = subjObj.subtypeid;
         pricetype               = subjObj.price_type;
         servicetype             = subjObj.service_type;
         additionalobjecttype    = subjObj.additional_object_type;
         mainobjectvalidation    = subjObj.main_object_validation;
         additionalobjectvalid   = subjObj.additional_object_valid;
	 flagaddenda		 = subjObj.flagaddenda;
      }
   }

   var frameUrl = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT03_PL_PKG.PL_ORDER_ITEM_EDIT"
                  +"?item_index="                  + item_index
                  +"&item_code="                   + escape(eval("form.item_code"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_product_id="             + escape(eval("form.item_product_id"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_product_dsc="            + escape(eval("form.item_product_dsc"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_prod_line_id="           + escape(eval("form.item_prod_line_id"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_plan_id="                + escape(eval("form.item_plan_id"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_plan_dsc="               + escape(eval("form.item_plan_dsc"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_quantity="               + escape(eval("form.item_quantity"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&txtnpTelefono="               + escape(eval("form.txtnpTelefono"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&hdnnpTelefonoNuevo="          + escape(eval("form.hdnnpTelefonoNuevo"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_imei="                   + escape(eval("form.item_imei"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&hdnnpImeiNuevo="              + escape(eval("form.hdnnpImeiNuevo"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_product_price="          + escape(eval("form.item_product_price"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_except_prodprice="       + escape(eval("form.item_except_prodprice"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_total="                  + escape(eval("form.item_total"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_adde_period="            + escape(eval("form.item_adde_period"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_adde_type="              + escape(eval("form.item_adde_type"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_own_equip="              + escape(eval("form.item_own_equip"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_own_equip_new="          + escape(eval("form.item_own_equip_new"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&hdnnpPromoHeaderId="          + escape(eval("form.hdnnpPromoHeaderId"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&hdnnpPromoDetailId="          + escape(eval("form.hdnnpPromoDetailId"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&hdnnpOracleCode="             + escape(eval("form.hdnnpOracleCode"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&hdnnpRealImei="               + escape(eval("form.hdnnpRealImei"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&item_services="               + escape(eval("form.item_services"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&product_type="                + escape(producttype)
                  +"&specialtyid="                 + escape(specialtyid)
                  +"&customer_id_bscs="            + escape(form.txtCodBSCS.value)
                  +"&handset_allowed="             + escape(handsetallowed)
                  +"&main_object_type="            + escape(mainobjecttype)
                  +"&product_handling="            + escape(producthandling)
                  +"&rate_plan_handling="          + escape(rateplanhandling)
                  +"&additional_service_allowed="  + escape(additionalservice)
                  +"&consignment_allowed="         + escape(consignmentallowed)
                  +"&price_type="                  + escape(pricetype)
                  +"&service_type="                + escape(servicetype)
                  +"&tipo_compa�ia="               + escape(form.txtTipoCompania.value)
                  +"&additional_object_type="      + escape(additionalobjecttype)
                  +"&main_object_validate="        + escape(mainobjectvalidation)
                  +"&additional_object_valid="     + escape(additionalobjectvalid)
                  +"&prod_release_id_orig="        + escape(eval("form.hdnnpprodreleaseidorig"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&prod_release_name_orig="      + escape(eval("form.hdnswnameproducto"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&plan_orig="                   + escape(eval("form.hdnnpplanorig"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&plan_id_orig="                + escape(eval("form.hdnnpplanidorig"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&av_npadditionaldrivingfield="
                  +"&av_called_from="              + "ORD"
                  +"&hdnmodality="                 + escape(eval("form.hdnmodality"+(num_rows>1?"["+item_index+"]":"")+".value"))
                  +"&hdnreplacementmode="          + escape(eval("form.hdnreplacementmode"+(num_rows>1?"["+item_index+"]":"")+".value"))
		  +"&hdnaddendahandling="          + escape(flagaddenda);



   deleteItemEnabled = false;
   var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
   var popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
}

function fValidatePhone(objThis){
   form = document.frmdatos;
   limpiaCampos();

   /* limpiamos el flag que nos sirve para cargar las Categorias de acuerdo a la empresa */
   if (form.hdnFlagLoadCategoria!=null){
      form.hdnFlagLoadCategoria.value = 0;
   }
   if (form.cmbCategoria!=null && form.cmbSubCategoria!=null){
      limpiaCampos_Combo(form.cmbCategoria);
      limpiaCampos_Combo(form.cmbSubCategoria);
      limpiaCampos_Combo(form.cmbRespPago);
   }


   if (!ContentOnlyNumber(objThis.value)){
      alert("N�mero de Nextel no v�lido");
      form.txtNextel.select();
      return false;
   };
   
   form.txtCompany.value = "";
   if (objThis.value == ""){
      return false;
   };
   var a = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_VALIDATE_PHONE?av_nextel="+objThis.value;
   parent.bottomFrame.location.replace(a);
};


function fxShowException(bShow){
   if (bShow){
      divException.className="show";
   }else{
      divException.className="hidden";
   }
}



function SetExceptionBasicRent() {         
   var vform    = document.frmdatos;
   if (getNumRows("items_table")==0) {
      alert("Agregue al menos un item a la orden.");
      return false;
   }
   var popupWin = window.open("about:blank", "sc_exception","status=yes,scrollbars=yes,resizable=yes,location=0,width=900, height=500, left=50, top=100,screenX=50,screenY=100");            
   vform.action ="/portal/pls/portal/!WEBSALES.NPSL_ORDER_ITEM_PL_PKG.PL_ITEM_EXCEPTION_EDIT"
   vform.target ="sc_exception"
   vform.submit();
}


/* Permite limpiar las excepciones de un Item especifico */
function clearException(item){
   var form = document.frmdatos;
   if (wn_items==1){
      /* CAMPO DE EXCEPCIONES - Renta Basica */
      form.item_excepBasicRentDesc.value="";
      form.item_excepBasicRentException.value="";
      /* CAMPO DE EXCEPCIONES - Renta de Alquiler */
      form.item_excepRentDesc.value="";
      form.item_excepRentException.value="";
      /* CAMPO DE EXCEPCIONES - Servicios Gratis */
      form.item_excepServiceId.value="";
      form.item_excepServiceDiscount.value="";
      /* CAMPO DE EXCEPCIONES - Minutos Adicionales */
      form.item_excepMinAddConexDirecChecked.value="";
      form.item_excepMinAddInterConexChecked.value="";
   }else{
      /* CAMPO DE EXCEPCIONES - Renta Basica */
      form.item_excepBasicRentDesc[item].value="";
      form.item_excepBasicRentException[item].value="";
      /* CAMPO DE EXCEPCIONES - Renta de Alquiler */
      form.item_excepRentDesc[item].value="";
      form.item_excepRentException[item].value="";
      /* CAMPO DE EXCEPCIONES - Servicios Gratis */
      form.item_excepServiceId[item].value="";
      form.item_excepServiceDiscount[item].value="";
      /* CAMPO DE EXCEPCIONES - Minutos Adicionales */
      form.item_excepMinAddConexDirecChecked[item].value="";
      form.item_excepMinAddInterConexChecked[item].value="";
   }
}

/*inicio corrigiendo items device borrados*/
 function fxIndiceItemDevice(){
   vForm = document.frmdatos;
   var hdnIndice_imei = vForm.hdnIndice_imei;
   var hdnIndice = vForm.hdnIndice;
   var hdnModality = vForm.hdnItemValuetxtItemModality;
   var idDevice = 0;
   var idDeviceEvaluado = 0;
   var specificationId = "<%=strCategoryId%>";
   if(specificationId=="null"){
     specificationId = vForm.cmbSubCategoria.value;
   }
    if(specificationId==2001 || specificationId==2009 || specificationId==2010 || specificationId==2018 || specificationId==2002){
     //bloque para agrupar los items device
     if(hdnIndice_imei!=null){
       if(hdnIndice_imei.length==undefined){
         idDevice = hdnIndice_imei.value;
       }else{
         for(i=0; i<hdnIndice_imei.length; i++) {
           if(idDeviceEvaluado!=hdnIndice_imei[i].value){         
             if(i==0){
               idDevice = hdnIndice_imei[i].value;
             }else{
               idDevice = idDevice+"_"+hdnIndice_imei[i].value;
             }
             idDeviceEvaluado = hdnIndice_imei[i].value;
           }    
         }
       }
     }
     //bloque para actualizar los ids de los items
     if(hdnIndice!=null){
       if(hdnIndice.length==undefined){
         hdnIndice.value = idDevice;
       }else{
         var cont = 0;
         for(i=0; i<hdnIndice.length; i++) {
           if((hdnModality[i].value=="Propio") || (hdnModality[i].value=="Alquiler en Cliente")){
             hdnIndice[i].value = 0;
           }else{
             hdnIndice[i].value = idDevice.split("_")[cont];
             cont++;
           }
         }
       }
     }      
   }
 }
 /*fin corrigiendo items device borrados*/




















