/************************************************************************************************/
/************************* CAMPOS ADICIONALES A LA ORDEN - INICIO *******************************/
/************************************************************************************************/

/* Dado un TABLEID, Permite a�adir un Label y un Campo, si es obligatoria le coloca un asterisco
   La estructura de la tabla tiene 6 columnas, 3 label y 3 campos */

function addCellPairTable(tableID, strLabel, strFieldName, strFieldType, strFieldValue, strOblig) {
   var table = document.all?document.all[tableID]:document.getElementById(tableID);
   var row;
   var cadena = "";
   var idx = 0;
   
   if (table.rows.length == 0){
      row = table.insertRow(-1);
      idx = 0;
   }else{
      row = table.rows(table.rows.length-1);
      idx = row.cells.length;
      if (row.cells.length > 5){
         row = table.insertRow(-1);
         idx = 0;
      }
   }
   
   // Celda - Label
   var cell = row.insertCell(idx);
   cell.className = "CellLabel";
   cell.width = "17%";
   cadena = "";
   if (strOblig == "S"){
      cadena = "&nbsp;<font color=RED>* </font><INPUT type=\"hidden\" name=\"hdn_chk_"+strFieldName+"\" value=\"S\">";
   }else{
      cadena = "&nbsp;&nbsp;&nbsp;";
   }
   cell.innerHTML = cadena + strLabel + "<INPUT type=\"hidden\" name=\"hdn_lbl_"+strFieldName+"\" value=\""+strLabel+"\">";
   
   // Celda - Campo de Ingreso 
   cell = row.insertCell(idx+1);
   cell.className = "CellContent";
   cell.innerHTML = "&nbsp;<INPUT type=\"text\" name=\""+strFieldName+"\" size=\"10\" maxlength=\"10\" value=\""+strFieldValue+"\" onchange=\"this.value=trim(this.value)\">"+
                    "<INPUT type=\"hidden\" name=\"hdn_type_"+strFieldName+"\" value=\""+strFieldType+"\">";
}

/* Dado un TABLEID, completa esta con una celda y cierra la tabla 
   La estructura de la tabla tiene 6 columnas, 3 label y 3 campos */
function tableComplete(tableID){
   var table = document.all?document.all[tableID]:document.getElementById(tableID);
   var row;  
   
   if (table.rows.length == 0){
      return;
   }else{
      row = table.rows(table.rows.length-1);
      idx = row.cells.length;
      if (row.cells.length > 5){
         return;
      }
   }
   var cell = row.insertCell(idx);
   cell.className = "CellContent";
   cell.colSpan = 6-idx;
   cell.width = ((6-idx)*100/6)+"%";
   cell.innerHTML = "&nbsp;";
}


/* Funci�n que valida los campos adicionales a las ordenes.*/
function validateOrdenFieldAdd(tableID){
   var form = document.frmdatos;
   var table = document.all?document.all[tableID]:document.getElementById(tableID);
   var flds = table.getElementsByTagName("INPUT");
   var fldname = "";
   for(i=0;i<flds.length;i++){
      if (flds[i].name.substr(0,8)=="hdn_chk_"){
         fldname = flds[i].name.substr(8,flds[i].name.length);
         if (eval("form."+fldname+".value") == ""){
            alert("Ingrese el campo \""+eval("form.hdn_lbl_"+fldname+".value").toUpperCase()+"\"");
            eval("form."+fldname+".focus()");
            return false;
         }
      }else if (flds[i].name.substr(0,9)=="hdn_type_"){
         fldname = flds[i].name.substr(9,flds[i].name.length);
         if ( flds[i].value == "NUMBER"){
            if (!ContentOnlyNumber(eval("form."+fldname+".value"))){
               alert("El campo \""+eval("form.hdn_lbl_"+fldname+".value").toUpperCase()+"\" debe contener s�lo n�meros");
               eval("form."+fldname+".focus()");
               return false;
            }
         }
      }
   }
   return true;
}

         
function deleteAllItem(tableID){
   var table = document.all?document.all[tableID]:document.getElementById(tableID);
   for (var i=table.rows.length; i>0; i--){
      table.deleteRow(i-1);
   }
}

/************************************************************************************************/
/**************************** CAMPOS ADICIONALES A LA ORDEN - FIN *******************************/
/************************************************************************************************/