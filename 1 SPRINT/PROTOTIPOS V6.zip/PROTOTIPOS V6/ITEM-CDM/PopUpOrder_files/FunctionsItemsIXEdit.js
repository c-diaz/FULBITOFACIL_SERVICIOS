/******** Desarrollo por Lee Rosales ****/

  // Vector de Servicios
  var vLongMaxService = 0;
  var vServicio = new Vector();
  
  // Vector de Servicios por Defecto
  var vServicioPorDefecto = new Vector();
      
   function deleteAllValues(listField){
      for (i=listField.options.length-1; i>=0; i--){
           listField.options[i] = null;
      }
   }
   
   function Servicio(id, name ,nameShort ,exclude) {
      this.id = id;
      this.name = name;
      this.nameDisplay = (exclude=="")?name:name+" - "+exclude;
      this.nameShort = nameShort;
      this.nameShortDisplay = (exclude=="")?nameShort:nameShort+" - "+exclude;
      this.exclude = exclude;
      this.active_new = "N";
      this.modify_new = "N";
   }
   //Proyecto HPPT+ jsalazar 23-11-2010 inicio -->
   function ServicioJS(id, name ,nameShort ,exclude,group) {
      this.id = id;
      this.name = name;
      this.nameDisplay = (exclude=="")?name:name+" - "+exclude;
      this.nameShort = nameShort;
      this.nameShortDisplay = (exclude=="")?nameShort:nameShort+" - "+exclude;
      this.exclude = exclude;
      this.active_new = "N";
      this.modify_new = "N";
      this.group = group;
      //alert("Servicio FunctionsItemsIXEdit.js");
   }
   // fin -->
   function ServicioArr(id, name ,nameShort ,exclude, active_new, modify_new) {
      this.id = id;
      this.name = name;
      this.nameDisplay = (exclude=="")?name:name+" - "+exclude;
      this.nameShort = nameShort;
      this.nameShortDisplay = (exclude=="")?nameShort:nameShort+" - "+exclude;
      this.exclude = exclude;
      this.active_new = active_new;//"N";
      this.modify_new = modify_new;//"N";
   }
   function CargaServiciosPorDefecto(){
      var form = document.frmdatos;
      var wn_size = vServicioPorDefecto.size();
         
         for(j=0; j<wn_size ; j++){
             objServicio = vServicioPorDefecto.elementAt(j);
	           for (i=0;i<form.cmbAvailableServices.options.length;i++){
                  if (objServicio.nameShort == form.cmbAvailableServices.options[i].value) {
                      form.cmbAvailableServices.options[i].selected = true;
                  }
             }
         }      
      addService();
   }
   
   // Funci�n que agrega un servicio a un  producto
   function addService() {
      var form = document.frmdatos;
      var wn_cantServ = vServicio.size();
      var objServicio;
      var exclude_serv;
      /*  variable para separacion de las "x" en el combo "cmbSelectedServices"  */
      var txt_separacion="  ";
      /* tomamos como maximo 10 caracteres (blancos)para almacenar los servicios seleccionados */
      var txt_vacios_2 = "          ";
      //var txt_vacios_2 = "                    ";

      /* Busca los roles que ya se seleccionaron */
      var aRolesSelected = new Array();
      var nameRol = "";
      var nameRol_selec = "";
      var idxARoles = 0;
      var i=0;

      /* Limpiamos el comboBox SelectedServices cuando se va a insertar el primer servicio */
      if (form.cmbSelectedServices.length == 1 && form.cmbSelectedServices.options[0].value == "") {
          deleteAllValues(form.cmbSelectedServices);
      }

      /* Guardamos los Roles de los servicios seleccionados */
      for (i=0;i<form.cmbSelectedServices.options.length;i++){
           nameRol = getRol(form.cmbSelectedServices.options[i].value);
           if (nameRol!="" && !valueExistsInArray(aRolesSelected,nameRol)){
               for(k=0; k<wn_cantServ; k++){
                   objServicio = vServicio.elementAt(k);
                   if (objServicio.nameShort == form.cmbSelectedServices.options[i].value && objServicio.modify_new == "S" ) {
                       aRolesSelected[idxARoles] = nameRol;
                       idxARoles++;
                   }
                }
            };
       };

       /* Valido que no existan servicios excluyentes seleccionados en selectedServices */
       for (i=0; i<form.cmbAvailableServices.options.length; i++){
            if (form.cmbAvailableServices.options[i].selected){
                nameRol = getRol(form.cmbAvailableServices.options[i].value);
                if (nameRol!="" && valueExistsInArray(aRolesSelected,nameRol)){
                    alert("Ya existe un Servicio Excluyente seleccionado para "+ nameRol);
                    return;
                };
             };
       };

       /* Valido que no existan servicios excluyente seleccionados en availableServices */
       for (i=0;i<form.cmbAvailableServices.options.length;i++){
            if (form.cmbAvailableServices.options[i].selected){
                nameRol = getRol(form.cmbAvailableServices.options[i].value);
                
                if (nameRol!="" && valueExistsInArray(aRolesSelected,nameRol)){
                    alert("Se han seleccionado varios Servicios Excluyentes de "+nameRol);
                    return;
                }else if (nameRol!="" ){
                     aRolesSelected[idxARoles] = nameRol;
                     idxARoles++;
                }
             }
       }
       
       /* Pasar los elementos de disponbible a asignado */
       for (i=0;i<form.cmbAvailableServices.options.length;i++){
            if (form.cmbAvailableServices.options[i].selected){
                var txt_texto   =  form.cmbAvailableServices.options[i].text + txt_vacios_2;
                //var cantTexto = txt_texto.substr(0,12)
                //var txt_texto_2 = txt_texto.substr(0,12) + txt_separacion + " " + txt_separacion + "x";
                var txt_texto_2 = txt_texto.substr(0,20) + txt_separacion + " " + txt_separacion + "x";
                addToList(form.cmbSelectedServices, txt_texto_2, form.cmbAvailableServices.options[i].value);
                   for(j=0; j<wn_cantServ; j++){
                       objServicio = vServicio.elementAt(j);
                       if (objServicio.nameShort == form.cmbAvailableServices.options[i].value) {
                           objServicio.modify_new = "S"; 
                       }
                   }
             }
       }

       deleteSelectedValues(form.cmbAvailableServices);
       form.hdnFlagServicio.value = "1";
       bServiceModified = true;
            
       form.item_services.value = GetSelectedServices();
       
       return;
   } /* end _function addService*/

   function deleteSelectedValues(listField){
      var i=0;
      for (i=listField.options.length-1;i>=0;i--){
         if (listField.options[i].selected){
             listField.options[i] = null;
         }
      }
   }

   function getRol( nameShort ){
      var i=0;
      groupName = "";
      wn_cantServ = vServicio.size();
      for(i=0; i<wn_cantServ; i++){
          objServicio = vServicio.elementAt(i);
          if (objServicio.nameShort == nameShort){
              groupName = objServicio.exclude;
              break;
          }
      }      
      return groupName;
   }
   
   function valueExistsInArray(aArreglo,valor,tipo){
      var i=0;
      bReturn = false;
      if (aArreglo!=null){
         if (aArreglo.length>0){					
            for (i=0;i<aArreglo.length;i++){					
               if (aArreglo[i]==valor){
                   bReturn = true;
                   break;  
                }
            }
          }else{
             bReturn = false;
          }
      }
        return bReturn;
    }

   function checkEnterKey(e){
      var CR= 13;
      var NS = (window.Event) ? 1 : 0;
      var keycode = (NS) ? e.which : e.keyCode;
      return (keycode == CR);
   }

   function checkKey(e,num1){
      form = document.frmdatos;
      if (checkEnterKey(e)){
         if (num1==11)      {form.txtTelefono.blur()};
         if (num1==12)      {form.txtSimImei.blur()};
         if (num1==14)      {form.txtNuevoTelefono.blur()};
         if (num1==15)      {form.txtImeiNuevo.blur()};
      };
   }
   
   function AddServicesDefault() {
  
   var aServiceDefault    = new Array();
   var idxAServ  = 0;
  
   var wn_cantServDef = vServicioArren.size();
   for (k=0; k<vServicio.size(); k++){
       objServicio1 = vServicio.elementAt(k);
       aServiceDefault[idxAServ] = objServicio1.nameShort;
       idxAServ++; 
   }
  
     for(j=0; j<wn_cantServDef; j++){
        objServicioArr = vServicioArren.elementAt(j);
        if (objServicioArr.nameShort!="" && !valueExistsInArray(aServiceDefault,objServicioArr.nameShort) ) { 
            vServicio.addElement(new Servicio(objServicioArr.id,objServicioArr.name,objServicioArr.nameShort,objServicioArr.exclude)); 
        }
      }
      
      var wn_cantServ = vServicio.size();
      for(i=0; i<wn_cantServ; i++){
           objServicio = vServicio.elementAt(i);
           for(k=0; k<wn_cantServDef; k++){
              objServicioArr = vServicioArren.elementAt(k);
              if( (objServicio.nameShort==objServicioArr.nameShort) && !valueExistsInArray(aServiceDefault,objServicioArr.nameShort) ){
                 if(parent.mainFrame.frmdatos.hdnServArrCM.value == objServicioArr.nameShort && objServicioArr.modify_new != "S" && objServicioArr.active_new != "S"){
                    objServicio.modify_new = "N";
                    objServicio.active_new = "S";
                 }
                 else{
                    if(objServicioArr.modify_new != "" && objServicioArr.active_new != ""){ 
                       objServicio.modify_new = objServicioArr.modify_new;
                       objServicio.active_new = objServicioArr.active_new;
                    }
                    else{
                      objServicio.modify_new = "S";
                      objServicio.active_new = "N";
                    }                    
                 }
              }
           }
       }    
   }

     
   function GetSelectedServices() {
   var str = "";
   var wn_cantServ = vServicio.size();	
   var flagCM = false;
   
     for(j=0; j<wn_cantServ; j++){
        objServicio = vServicio.elementAt(j);
        
        try{
           if(parent.mainFrame.frmdatos.hdnIdCM.value == objServicio.id && flagCM == true){
              continue;
           }
        }catch(e){}
        
        
        if (objServicio.active_new == "S") {
           str =  str + "|" + objServicio.id + "|" + objServicio.active_new + "|" + objServicio.modify_new;
        };
        else
           if (objServicio.active_new == "N" && objServicio.modify_new == "S") {
              str =  str + "|" + objServicio.id + "|" + objServicio.active_new + "|" + objServicio.modify_new;
           };
        
        try{   
           if(parent.mainFrame.frmdatos.hdnIdCM.value == objServicio.id){
              flagCM = true;
           }
        }catch(e){}
     };	 
    return str;
   }
            
  /*Creado por Lee Rosales
    Solo recibe n�mero
  */
  function AcceptNumber(evt){ 
    var nav4 = window.Event ? true : false;
    var key = nav4 ? evt.which : evt.keyCode; 
    
    return (key <= 13 || (key >= 48 && key <= 57) || key == 44);
  }   



function ChangeItemNewDetailOrder(window_type,vctrOrden) {
   var form = document.frmdatos;
   var producttype;
   var handsetallowed;
   var mainobjecttype;
   var producthandling;
   var rateplanhandling;
   var additionalservice;
   var consignmentallowed;
   var pricetype;
   var servicetype;
   var additionalobjecttype;
   var mainobjectvalidation;
   var additionalobjectvalid;
   var flagaddenda;

   var bUnknwnSiteFlg = null;
   try {
      bUnknwnSiteFlg = form.chkUnkwnSite.checked;
   }catch(e) {
      bUnknwnSiteFlg = false;
   }

   // Si hay Sites, e sobligatorio seleccionar
   if (form.hdnClientSitesFlag.value == "1") {
      if (form.cmbSite.value == ""  && form.cmbSite.length > 1 ) {
         if (!bUnknwnSiteFlg) {
            alert("Debe seleccionar un Site");
            form.cmbSite.focus();
            return;
         }
      }
   }
   
   if (form.cmbDivision.value == ""){
      alert("Debe seleccionar una Division");
      form.cmbDivision.focus();
      return;
   };

   if (form.cmbCategoria.value == ""){
      alert("Debe seleccionar una Categoria");
      form.cmbCategoria.focus();
      return;
   };

   if (form.cmbSubCategoria.value == ""){
      alert("Debe seleccionar una Sub Categoria");
      form.cmbSubCategoria.focus();
      return;
   };

   if (form.cmbSubCategoria.value != "") {
      var subjObj = null;
      
      var urlPage = "?";
      for( d = 0 ; d < vctrOrden.size(); d++ ){
       var objVector = vctrOrden.elementAt(d);
        
        urlPage = urlPage + objVector.objectDesc + "=" + objVector.objectValue + "&";
      }
      
      //alert("urlPage : " + urlPage);
      
      var frameUrl = "PopUpOrder.jsp"+urlPage;

      var winUrl = "htdocs/jpnewdynamicsections/PopUpOrderFrame.jsp?av_url="+escape(frameUrl);
      var popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=450, height=540, left=300, top=30, screenX=50, screenY=100");
   };
}
 
 var wn_item_quantity = 0;
 var item_index = 1;
 
 function sendItemsValues(){
 var countImeisTable = 0;
 var form = document.frmdatos;
 var dif_cantidad_equipos =  parseInt(form.txt_ItemQuantity.value) - parseInt(wn_item_quantity)
 var form_parent = parent.opener.document.frmdatos;
 //var dif_cantidad_equipos = parseInt(form.txt_ItemQuantity.value);
 var table = parent.opener.document.all ? parent.opener.document.all["table_imeis"]:parent.opener.document.getElementById("table_imeis");
 
 countImeisTable = table.rows.length;                
 
   if (dif_cantidad_equipos > 0) {
      
      /* Inicio: Ubicamos la posici�n para insertar el nuevo item de IMEI */
         if (table.rows.length == 2 || table.rows.length == 1){
            item_insert = parseInt("-1");  }
         else {
            
            var item_insert = 0;
            var insert_imei = false;
            
            
            
            if (table.rows.length > 2){
               for (j=0; j<table.rows.length-1; j++){
                   if ( (item_index + 1) == form_parent.hdnIndice_imei[j].value){
                      insert_imei = true; }/* indica que ya se encontro el grupo al que se va a insertar */
                   else{
                      if (insert_imei){
                         break; };
                      }
                   }
               item_insert = j + 1;
              }
           }
         
         
         /* Fin: Busqueda posicion para Insertar item nuevo IMEI*/
         //alert("form.cmb_ItemProducto.options[form.cmb_ItemProducto.selectedIndex].text " + form.cmb_ItemProducto.options[form.cmb_ItemProducto.selectedIndex].text);
         if( countImeisTable > 1 ){
          for(k=1; k <= dif_cantidad_equipos; k++){
            parent.opener.addRowTableImeis("table_imeis",
            form_parent.hdnIndice[item_index].value  + "-" + (parseInt(wn_item_quantity) + k) ,                          // numero
            "",                                                                                 // imei
            "",                                                                                 // bad imei
            form.cmb_ItemProducto.options[form.cmb_ItemProducto.selectedIndex].text,            // nombre del producto
            form.cmb_ItemPlanTarifario.options[form.cmb_ItemPlanTarifario.selectedIndex].text,  // nombre del plan
            "N",
            (item_index+1),
            item_insert
            ) 
            item_insert = item_insert + 1;
          }//Fin del For
         }//Fin del If
         else{
           for(k=1; k <= dif_cantidad_equipos; k++){
            parent.opener.addRowTableImeis("table_imeis",
            form_parent.hdnIndice.value  + "-" + (parseInt(wn_item_quantity) + k) ,                          // numero
            "",                                                                                 // imei
            "",                                                                                 // bad imei
            form.cmb_ItemProducto.options[form.cmb_ItemProducto.selectedIndex].text,            // nombre del producto
            form.cmb_ItemPlanTarifario.options[form.cmb_ItemPlanTarifario.selectedIndex].text,  // nombre del plan
            "N",
            (item_index+1),
            item_insert
            ) 
            item_insert = item_insert + 1;
          }//Fin del For 
         }//Fin del Else
    }  /*  FIN: Carga de Nuevos Items Imeis*/
  } //Fin de la funci�n
  
  function addToList(listField, newText, newValue) {
                  var len = listField.length++; /* Increase the size of list and return the size */
                  listField.options[len].value = newValue;
                  listField.options[len].text = newText;
               }

// Funci�n que elimina un servicio del combo de Servicios Seleccionados
     function EliminaServicio(objThis){
            form = document.frmdatos;
            var txt_value_elimina;
            var txt_elimina_modify_new = "";
            var txt_modify;
            var aRolesSelected = new Array();
            var nameRol= "";
            var idxARoles = 0;
            var objServicio;
            var wn_cantServ;

            if (objThis !=  null){
               txt_value_elimina = objThis.value;}
            else{
               txt_value_elimina = form.cmbSelectedServices.value;}
            wn_cantServ = vServicio.size();

            /*  Inicio: Se valida que no exista un servicio del mismo grupo  */
            for (i=0 ; i<form.cmbSelectedServices.options.length; i++){
               nameRol = getRol(form.cmbSelectedServices.options[i].value);
               if (nameRol!="" && !valueExistsInArray(aRolesSelected,nameRol)){
                  for(k=0; k<wn_cantServ; k++){
                     objServicio = vServicio.elementAt(k);
                     if (objServicio.nameShort == txt_value_elimina ){
                        txt_elimina_modify_new = objServicio.modify_new;
                     };
                     if (objServicio.nameShort == form.cmbSelectedServices.options[i].value && objServicio.modify_new == "S" ) {
                        aRolesSelected[idxARoles] = nameRol;
                        idxARoles++;
                     }
                  }
               };
            };

            if (txt_elimina_modify_new == "N"){
               nameRol = getRol(form.cmbSelectedServices.value);
               if (nameRol!="" && valueExistsInArray(aRolesSelected,nameRol)){
                  alert("Ya existe un Servicio Excluyente seleccionado para "+ nameRol);
                  return;
               };
            };
            /* Fin: Validaci�n de grupo */


            deleteAllValues(form.cmbSelectedServices);
            /* variable para separacion de las "x" en el combo "cmbSelectedServices" */
            var txt_separacion="  ";
            /* tomamos como maximo 10 caracteres (blancos) para almacenar los servicios seleccionados */
            var txt_vacios_2 = "          ";
            for(i=0; i<wn_cantServ; i++){
               objServicio = vServicio.elementAt(i);
               var txt_servicio = objServicio.nameShortDisplay + txt_vacios_2;
               var txt_servicio_2 = txt_servicio.substr(0,12);
               /* Si el Item tiene el servicio actualmente  */
               if (objServicio.active_new == "S"){
                  if (objServicio.nameShort == txt_value_elimina){
                     if (objServicio.modify_new == "S"){ /* Si al Item continua o se le agrega el servicio */
                        objServicio.modify_new = "N";
                        AddNewOption(form.cmbSelectedServices, objServicio.nameShort, txt_servicio_2 + txt_separacion + "x" + txt_separacion + " ");
                     }
                     else{
                        objServicio.modify_new = "S";
                        AddNewOption(form.cmbSelectedServices, objServicio.nameShort, txt_servicio_2 + txt_separacion + "x" + txt_separacion +"x");
                     }
                  }
                  else{
                     /* Si al Item continua o se le agrega el servicio */
                     if (objServicio.modify_new == "S")
                        txt_modify ="x";
                     else
                        txt_modify =" ";
                     AddNewOption(form.cmbSelectedServices, objServicio.nameShort, txt_servicio_2 + txt_separacion + "x" + txt_separacion + txt_modify);
                  }
               }
               else {
                  if (objServicio.active_new == "N" && objServicio.modify_new == "S"){
                     if (objServicio.nameShort == txt_value_elimina){
                        objServicio.modify_new = "N";
                        option1 =  new Option(objServicio.nameShortDisplay,objServicio.nameShort);
                        form.cmbAvailableServices.options[form.cmbAvailableServices.length-1] = option1;
                        form.cmbAvailableServices.options[form.cmbAvailableServices.length] = new Option("                                ");
                     }
                     else{
                        AddNewOption(form.cmbSelectedServices, objServicio.nameShort, txt_servicio_2 + txt_separacion + " " + txt_separacion +"x");
                     }
                  }
               }
            } /* end_for */
            form.hdnFlagServicio.value = "1";
            bServiceModified = true;
         }; /* end_function */



   /* Habilida y Desahabilita bloques */
   function fxOcultarTr(swstatus,obj){
      if (swstatus=="none") swstatus="inline"; else swstatus="none";
          obj.style.display = swstatus;
   }

   //Funci�n generica para realizar acciones con los select de NPTABLE 
   function fxShowObjectNP(nameNpTable,objThis){
      if (nameNpTable=="CONTR_ASOCIATE"){     
          var selection = objThis.options[objThis.selectedIndex].value; 
          document.frmdatos.txt_ItemContractNumber.value="";
          if (selection=="S"){
              fxOcultarTr("yes",idDisplay27);    
              fxOcultarTr("none",idDisplay28);            
            }else{
              fxOcultarTr("none",idDisplay27);            
              fxOcultarTr("yes",idDisplay28);            
            };
          }
      }
  
   
 
