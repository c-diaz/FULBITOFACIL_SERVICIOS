/**
Desarrollador : Lee Rosales 
*/

function fxMakeOrderItem(npobjitemheaderid,  npobjspecgrpid,  npobjitemid,  npobjitemname,  namehtmlheader, namehtmlitem, npcontroltype,  npdefaultvalue, npsourceprogram,  npspecificationgrpid, npdisplay,  npobjreadonly,  npobjitemvalue, npobjitemvaluedesc,npobjitemflagsave,npitemid,npdatatype,npvalidateflg,nplength){
         this.npobjitemheaderid     =   npobjitemheaderid;
         this.npobjspecgrpid        =   npobjspecgrpid;
         this.npobjitemid           =   npobjitemid;
         this.npobjitemname         =   npobjitemname;
         this.namehtmlheader        =   namehtmlheader;
         this.namehtmlitem          =   namehtmlitem;
         this.npcontroltype         =   npcontroltype;
         this.npdefaultvalue        =   npdefaultvalue;
         this.npsourceprogram       =   npsourceprogram;
         this.npspecificationgrpid  =   npspecificationgrpid;
         this.npdisplay             =   npdisplay;
         this.npobjreadonly         =   npobjreadonly; 
         this.npobjitemvalue        =   npobjitemvalue; 
         this.npobjitemvaluedesc    =   npobjitemvaluedesc;
         this.npobjitemflagsave     =   npobjitemflagsave;
         this.npitemid              =   npitemid;
         this.npdatatype            =   npdatatype;
         this.npvalidateflg         =   npvalidateflg;
         this.nplength              =   nplength;
}

function fxMakeOrderHeaderItem(npspecificationgrpid,  npobjitemheaderid,  npobjitemname,  npdisplay, npcreatedby, npcreateddate, npmodifiedby, npmodifieddate, nphtmlname ){
         this.npspecificationgrpid  =   npspecificationgrpid;
         this.npobjitemheaderid     =   npobjitemheaderid;
         this.npobjitemname         =   npobjitemname;
         this.npdisplay             =   npdisplay;
         this.npcreatedby           =   npcreatedby;
         this.npcreateddate         =   npcreateddate;
         this.npmodifiedby          =   npmodifiedby;
         this.npmodifieddate        =   npmodifieddate;
         this.nphtmlname            =   nphtmlname;
}


function fxMakeOrderSection(sectionId,objectType,objectId,evenType,eventHandler,status,nptypeobject,npobjectname,npbusinessobject){
        this.sectionId          =   sectionId;
        this.objectType         =   objectType;
        this.objectId           =   objectId;
        this.evenType           =   evenType;
        this.eventHandler       =   eventHandler;
        this.status             =   status;
        this.nptypeobject       =   nptypeobject;
        this.npobjectname       =   npobjectname;
        this.npbusinessobject   =   npbusinessobject;
}

function fxMakeOrderObejct(objectDesc,objectValue){
        this.objectDesc         =   objectDesc;
        this.objectValue        =   objectValue;
}

function fxMakeItemImei(objImeiId, objImeiSubId, objImeiNum, objImeiItem, objImei, objSim, objProduct, objProductId, objPlan, objBad, objCheck, objModality, objWarrant, objNumTel, objErrorEstOp, objItemDeviceId){ 
        this.objImeiId          =   objImeiId;
        this.objImeiSubId       =   objImeiSubId;
        this.objImeiNum         =   objImeiNum;
        this.objImeiItem        =   objImeiItem;
        this.objImei            =   objImei;
        this.objSim             =   objSim;
        this.objProduct         =   objProduct;
        this.objProductId       =   objProductId;
        this.objPlan            =   objPlan;
        this.objBad             =   objBad;
        this.objCheck           =   objCheck;
        this.objModality        =   objModality;
		    this.objWarrant         =   objWarrant;
        this.objNumTel          =   objNumTel;
        this.objErrorEstOp      =   objErrorEstOp;
        this.objItemDeviceId    =   objItemDeviceId;
}



function fxMakeAssignmentAccount(objBillingId,objBillingName){
      this.objBillingId       =   objBillingId;
      this.objBillingName     =   objBillingName;
      
  }
  
function fxMakeBillingAccount(objEquipmentId,objEquipment,objServBillId,objServId,objServDesc,
                                   objChargeUniqueId,objChargeUnique,objRespUnique,objBillingUnique,
                                   objChargeRecurrentId,objChargeRecurrent,objRespRecurrent,objBillingRecurrent,
                                   objChargeExcesoId,objChargeExceso,objRespExceso,objBillingExceso){
      this.objEquipmentId       =   objEquipmentId;
      this.objEquipment         =   objEquipment;
      this.objServBillId        =   objServBillId;
      this.objServId            =   objServId;
      this.objServDesc          =   objServDesc;
      this.objChargeUniqueId    =   objChargeUniqueId;
      this.objChargeUnique      =   objChargeUnique;
      this.objRespUnique        =   objRespUnique;
      this.objChargeRecurrentId =   objChargeRecurrentId;
      this.objChargeRecurrent   =   objChargeRecurrent;
      this.objRespRecurrent     =   objRespRecurrent;
      this.objBillingRecurrent  =   objBillingRecurrent;
      this.objChargeExcesoId    =   objChargeExcesoId;
      this.objChargeExceso      =   objChargeExceso;
      this.objRespExceso        =   objRespExceso;
      this.objBillingExceso     =   objBillingExceso;
      
}

function Servicio(id, name ,nameShort ,exclude) {
    
        this.id = id;
        this.name = name;
        this.nameDisplay = (exclude=="")?name:name+" - "+exclude;
        this.nameShort = nameShort;
        this.nameShortDisplay = (exclude=="")?nameShort:nameShort+" - "+exclude;
        this.exclude = exclude;
        this.active_new = "N";
        this.modify_new = "N";

}


 function fxMakeBilling(baId,baName,baStatus){
    this.baId         = baId;
    this.baName       = baName;
    this.baStatus     = baStatus;
 }
 
 function fxMakeSite(siteId,siteName,siteRegionName,siteStatus){
    this.siteId         = siteId;
    this.siteName       = siteName;
    this.siteRegionName = siteRegionName;
    this.siteStatus     = siteStatus;
 }

/*******************************************************************/
/***                                                             ***/
/***   Tokenizer.js - JavaScript String Tokenizer Function       ***/
/***                                                             ***/
/***   Author   : Lee Rosales                                    ***/
/***                                                             ***/
/*******************************************************************/

String.prototype.tokenize = tokenize;

function tokenize()
  {
     var input             = "";
     var separator         = " ";
     var trim              = "";
     var ignoreEmptyTokens = true;

     try {
       String(this.toLowerCase());
     }
     catch(e) {
       window.alert("Tokenizer Usage: string myTokens[] = myString.tokenize(string separator, string trim, boolean ignoreEmptyTokens);");
       return;
     }

     if(typeof(this) != "undefined")
       {
          input = String(this);
       }

     if(typeof(tokenize.arguments[0]) != "undefined")
       {
          separator = String(tokenize.arguments[0]);
       }

     if(typeof(tokenize.arguments[1]) != "undefined")
       {
          trim = String(tokenize.arguments[1]);
       }

     if(typeof(tokenize.arguments[2]) != "undefined")
       {
          if(!tokenize.arguments[2])
            ignoreEmptyTokens = false;
       }

     var array = input.split(separator);

     if(trim)
       for(var i=0; i<array.length; i++)
         {
           while(array[i].slice(0, trim.length) == trim)
             array[i] = array[i].slice(trim.length);
           while(array[i].slice(array[i].length-trim.length) == trim)
             array[i] = array[i].slice(0, array[i].length-trim.length);
         }

     var token = new Array();
     if(ignoreEmptyTokens)
       {
          for(var i=0; i<array.length; i++)
            if(array[i] != "")
              token.push(array[i]);
       }
     else
       {
          token = array;
       }

     return token;
  }


/*Creado por Lee Rosales
  Solo recibe n�mero
*/
function AcceptNumber(evt){ 

var nav4 = window.Event ? true : false;

var key = nav4 ? evt.which : evt.keyCode; 

return (key <= 13 || (key >= 48 && key <= 57) || key == 44);

}

function fxChangeItemNewDetailOrder(vctrOrden) {
     var form = document.frmdatos;
     var producttype;
     var handsetallowed;
     var mainobjecttype;
     var producthandling;
     var rateplanhandling;
     var additionalservice;
     var consignmentallowed;
     var pricetype;
     var servicetype;
     var additionalobjecttype;
     var mainobjectvalidation;
     var additionalobjectvalid;
     var flagaddenda;
  
     var bUnknwnSiteFlg = null;
     try {
        bUnknwnSiteFlg = form.chkUnkwnSite.checked;
     }catch(e) {
        bUnknwnSiteFlg = false;
     }
  
     // Si hay Sites, e sobligatorio seleccionar
     if (form.hdnClientSitesFlag.value == "1") {
        if (form.cmbSite.value == ""  && form.cmbSite.length > 1 ) {
           if (!bUnknwnSiteFlg) {
              alert("Debe seleccionar un Site");
              form.cmbSite.focus();
              return;
           }
        }
     }
     	  
	  if (form.cmbDivision.value == ""){
        alert("Debe seleccionar una Divisi�n");
        form.cmbDivision.focus();
        return;
     };	  
  
     if (form.cmbCategoria.value == ""){
        alert("Debe seleccionar una Categoria");
        form.cmbCategoria.focus();
        return;
     };
  
     if (form.cmbSubCategoria.value == ""){
        alert("Debe seleccionar una Sub Categoria");
        form.cmbSubCategoria.focus();
        return;
     };
    
    try{
       if ( (form.cmbLugarAtencion != null) && (form.cmbLugarAtencion.value == "") ){          
          alert("Debe seleccionar un Lugar de Despacho");
          form.cmbLugarAtencion.focus();
          return;
       }else if ( (form.cmbTienda != null) && (form.cmbTienda.value == "") ){          
            alert("Debe seleccionar una tienda");
            form.cmbTienda.focus();
            return;
       }
     }catch(e){}
             
     if (form.cmbSubCategoria.value != "") {
        var subjObj = null;
        var urlPage = "?";
        for( d = 0 ; d < vctrOrden.size(); d++ ){
         var objVector = vctrOrden.elementAt(d);
          urlPage = urlPage + objVector.objectDesc + "=" + objVector.objectValue + "&";
        }
        

       if(document.forms[0].chkVepFlag != null && document.forms[0].cmbVepNumCuotas!= null) {
        urlPage = urlPage + "strnpnumcuotas" + "=" + document.forms[0].cmbVepNumCuotas.value   + "&";
        urlPage = urlPage +  "strflagvep" + "=" + document.forms[0].chkVepFlag.value + "&"
      }

      if (document.forms[0].chkVepFlag !=undefined){
         if (document.forms[0].chkVepFlag.checked == true && document.forms[0].cmbVepNumCuotas.selectedIndex== 0){
            alert("Debe seleccionar el n�mero de cuotas de venta a plazos antes de agregar los �tems");
            return;
         }
      }
        var frameUrl = "PopUpOrder.jsp"+urlPage+"type_window=NEW&objTypeEvent=NEW";
        
        var winUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpOrderFrame.jsp?av_url="+escape(frameUrl);
        //RDELOSREYES - 20/08/2008 - Redimension del Popup - Incidencia #5112
        popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=550, height=600, left=300, top=30, screenX=50, screenY=100");
        //var popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=450, height=540, left=300, top=30, screenX=50, screenY=100");
     }
  }
  
  function closepopupOrderItem()   {
    try{
      
      if(false == popupWin.closed){
         alert("No se puede continuar hasta que se cierre la ventana item de orden.");
         //popupWin.close();
      }
      return popupWin.closed;
    }catch(err){
       return true
    }
  }

   /*Para el PopUp en Edici�n*/
   function fxChangeItemNewDetailOrderEdit(vctrOrden) {
     var form = document.frmdatos;
     var subjObj = null;
     var urlPage = "?";
	 
    try{
      var result=fxValidateActionItem('A');//ACCION ELIMINAR
      if (result>0){
        //alert("La orden ya fue cancelada (Refresque su pantalla). No se puede agregar items");
        return false;
      }
    }
    catch(e){}
     for( d = 0 ; d < vctrOrden.size(); d++ ){
           var objVector = vctrOrden.elementAt(d);
           urlPage = urlPage + objVector.objectDesc + "=" + objVector.objectValue + "&";
     }
     
      if(document.forms[0].chkVepFlag != null && document.forms[0].cmbVepNumCuotas!= null) {
        urlPage = urlPage + "strnpnumcuotas" + "=" + document.forms[0].cmbVepNumCuotas.value   + "&";
        urlPage = urlPage +  "strflagvep" + "=" + document.forms[0].chkVepFlag.value + "&"
      }
        
     if (document.forms[0].chkVepFlag !=undefined){
        if (document.forms[0].chkVepFlag.checked == true && document.forms[0].cmbVepNumCuotas.selectedIndex== 0){
           alert("Debe seleccionar el n�mero de cuotas de venta a plazos antes de agregar los �tems");
           return;
        }
     }
      
     var frameUrl = "PopUpOrder.jsp"+urlPage+"type_window=NEW&objTypeEvent=EDIT";
        
     var winUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpOrderFrame.jsp?av_url="+escape(frameUrl);
     popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=620, height=600, left=300, top=30, screenX=50, screenY=100");
        //var popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=450, height=540, left=300, top=30, screenX=50, screenY=100");
    
   }

/*JavaScript para la secci�n de combos din�micos para las specificaciones de 
  �rdenes*/

	var Vdivision 			= new Vector();			   
   var Vcategory        = new Vector();
   var VcategorySubCategory     = new Vector();
   var VsubjectTypeSpec = new Vector();
	
   function makeDivision(division,divisionId) {
            this.division        = division;
            this.divisionId      = divisionId;
   }	

   function makeCategoryDivision(category,divisionId){
            this.category        = category;
            this.divisionId      = divisionId;
   }

   function makeCategorySubCategoryDivision(category,subcategory,specificationId,divisionId) {
            this.category        = category;
            this.subcategory     = subcategory;
            this.specificationId = specificationId;
            this.divisionId      = divisionId;
   }

	//en esta funci�n se llena el vector VsubjectTypeSpec
	function makeSpecificationCategorySubCategoryDivision(divisionId,division,category,specificationId,subcategory) {
		this.divisionId		= divisionId
		this.division			= division
		this.category        = category;
		this.specificationId = specificationId;
		this.subcategory     = subcategory;
   }

   function fx_fillElementsVector(){
      
      for(i=0;i<VsubjectTypeSpec.size();i++){
         obj_spec = null;
         obj_spec = VsubjectTypeSpec.elementAt(i);
			
         if (!fx_existsElementVdivision(obj_spec.division))
             fx_addElementVdivision(obj_spec.division,obj_spec.divisionId);

         if (!fx_existsElementVcategoryDivision(obj_spec.category,obj_spec.divisionId))
             fx_addElementVcategory(obj_spec.category,obj_spec.divisionId);
             
         if (!fx_existsElementVcategorySubCategoryDivision(obj_spec.category,obj_spec.subcategory,obj_spec.divisionId))
             fx_addElementVcategorySubCategoryDivision(obj_spec.category,obj_spec.subcategory,obj_spec.specificationId,obj_spec.divisionId);
     }
   }

   function fx_addElementVdivision(v_division,v_divisionId){
      Vdivision.addElement(new makeDivision(v_division,v_divisionId));
   }

   function fx_addElementVcategory(v_category,v_divisionId){
     Vcategory.addElement(new makeCategoryDivision(v_category,v_divisionId));
   }
   
   function fx_addElementVcategorySubCategoryDivision(v_category,v_subcategory,v_specificationId,v_divisionId){      
      VcategorySubCategory.addElement(new makeCategorySubCategoryDivision(v_category,v_subcategory,v_specificationId,v_divisionId));
   }	
	
   function fx_existsElementVdivision(v_division){
      var l = 0;
      
      for(l=0;l<Vdivision.size();l++){
          obj_vDivision = null;
          obj_vDivision = Vdivision.elementAt(l);
          if (obj_vDivision.division == v_division){
              return true;
          }
      }
      return false;
   }	

   function fx_existsElementVcategoryDivision(v_category,v_divisionId){
      var j = 0;
      
      for(j=0;j<Vcategory.size();j++){
           obj_vCategory = null;
           obj_vCategory = Vcategory.elementAt(j);
           if ( (obj_vCategory.category == v_category) && (obj_vCategory.divisionId == v_divisionId) ){
               return true;
           }
      }
      return false;
   }
   
   function fx_existsElementVcategorySubCategoryDivision(v_category,v_subcategory,v_divisionId){
      var k = 0;
      
      for(k=0;k<VcategorySubCategory.size();k++){
           obj_vSubjectType = null;
           obj_vSubjectType = VcategorySubCategory.elementAt(k);
           if ((obj_vSubjectType.category == v_category) && (obj_vSubjectType.subcategory == v_subcategory) && (obj_vSubjectType.divisionId == v_divisionId)){
                
                return true;
           }
      }
      return false;
   }
	   
   //Functions para cargar data en los Combos

   function fx_fillDivision(){
      DeleteSelectOptions(document.frmdatos.cmbDivision);
        for(i=0;i<Vdivision.size();i++){
            obj_vDivision = null;
            obj_vDivision = Vdivision.elementAt(i);
            AddNewOption(document.frmdatos.cmbDivision,obj_vDivision.divisionId,obj_vDivision.division);
        }
   }

   function fx_fillCategory(v_divisonId){      
	
		DeleteSelectOptions(document.frmdatos.cmbCategoria);
      DeleteSelectOptions(document.frmdatos.cmbSubCategoria);      
		for(i=0;i<Vcategory.size();i++){              
			obj_vSubject = null;
			obj_vSubject = Vcategory.elementAt(i);
			if( obj_vSubject.divisionId == v_divisonId )
				AddNewOption(document.frmdatos.cmbCategoria,obj_vSubject.category,obj_vSubject.category);
		}
   }

   function fx_fillSubCategory(category_selected){
   
      DeleteSelectOptions(document.frmdatos.cmbSubCategoria);
      
      var obj_divisionid =  document.frmdatos.cmbDivision.value;
      for(i=0;i<VcategorySubCategory.size();i++){
          obj_vSubjectType = null;
          obj_vSubjectType = VcategorySubCategory.elementAt(i);
          v_subject       = obj_vSubjectType.category;
          v_type          = obj_vSubjectType.subcategory;
          v_specification = obj_vSubjectType.specificationId;
          v_division      = obj_vSubjectType.divisionId;
          
          if (v_subject == category_selected && v_division == obj_divisionid){
              AddNewOption(document.frmdatos.cmbSubCategoria,v_specification,v_type);
          }
      }
   }	
      
   //Invoca al PopUp para la creaci�n de un Item
   function fxAddRowOrderItemsGlobal(vctItemOrder){
    fxaddElementsItemsMain(vctItemOrder);
    form = parent.mainFrame.document.frmdatos;
    var index_arg = 1;
    var elemText = "";
    var cantElement;
    var valFlag = false;
    var valFlagNothing = false;
    var valuevisible = "";
    var descvisible = "";
    var typeControl = "";
    var cell;
    var contentHidden = "";
    var elementCurrent = vctItemsMainFrameOrder.size();
    
    cantElement = vctItemOrder.size();
    
        if (cantElement > 1) {/* los argumentos pasados.. a partir del segundo. */
          
          var row   = items_table.insertRow(-1);
          
          elemText =  "";
          
          var new_grupo = parseInt(form.hdn_item_imei_grupo.value) + parseInt(1);
          form.hdn_item_imei_grupo.value = new_grupo;
                
          /*Agrego la primera l�nea*/
          var cellPrinc = row.insertCell(index_arg - 1);
          elemText      = "<div id=\'contTable\' align='center' class='CellContent' >"+
                          "<input type=\'radio\' name=\'item_chek\' onclick=\'javascript:fxCargaServiciosItemItem(fxGetRowIndex(this));\'>"+
                          "<a href=\'javascript:;\' onclick=\'javascript:fxChangeItemEditDetailOrderNew(fxGetRowIndex(this),parent.mainFrame.vctItemsMainFrameOrder,parent.mainFrame.vctParametersOrder);\' ALT=\'Editar Item\'><font color=\'brown\' size=\'2\' face=\'Arial\' ><b>"+ form.hdn_item_imei_grupo.value +"</b></font></a> "+
                          "<a href=\'javascript:;\' onclick=\'javascript:fxAssignmentBillingAcount(fxGetRowIndex(this),parent.mainFrame.vctItemsMainFrameOrder,parent.mainFrame.vctParametersOrder);\' ALT=\'Editar Item\'>Billing</a> "+
                          "<input type=\'hidden\' name='hdnIndice' value="+ document.frmdatos.hdn_item_imei_grupo.value +" >" +
                          "<input type=\'hidden\' name='hdnItemId' >" +
                          "</div>";
                         
          cellPrinc.innerHTML = elemText;
          
          index_arg++;
          
          elemText = "";
         
          for( i = 0; i < vctItemHeaderOrder.size(); i++ ){

            var objItemHeader = vctItemHeaderOrder.elementAt(i);
            var valFlag = false;
            //alert("i : " + i + " -> " + objItemHeader.npobjitemheaderid + " -> " + objItemHeader.nphtmlname );
            
            //Siempre mostrar Text y si coinciden asignar el Valor
              for( j = 0; j < vctItemOrder.size(); j++ ){

              var objItem = vctItemOrder.elementAt(j);
              
              //alert("[i][" + i + "][j]["+j+"] -> ( objItemHeader " + objItemHeader.npobjitemheaderid + " == objItem " + objItem.npobjitemheaderid + " ) -> " + objItem.nphtmlname );
              
                if ( objItemHeader.npobjitemheaderid == objItem.npobjitemheaderid ) {
                
                    valuevisible = " value='"+ objItem.npobjitemvalue + "' ";
                    descvisible  = " value='"+ objItem.npobjitemvaluedesc + "' ";
                    
                    if ( objItemHeader.npdisplay == "N" ) {
                        contentHidden += "<input type='hidden' name='hdnItemHeaderId' value='"+objItemHeader.npobjitemheaderid+"' >";
                        contentHidden += "<input type='hidden' name='hdnItemValue"+trim(objItemHeader.nphtmlname)+"' "+valuevisible+" >";
                        contentHidden += "<input type='hidden' name='"+ trim(objItemHeader.nphtmlname) +"' " + descvisible + " > ";
                        //alert("contentHidden : " + contentHidden );
                    }else{
                        //alert("HTML : " +objItemHeader.nphtmlname + " index_arg " + index_arg)
                        cell = row.insertCell(index_arg - 1);
                        elemText += "<div id='"+ objItemHeader.nphtmlname +"'  align='center' class='CellContent' > ";
                        elemText += "<input type='hidden' name='hdnItemHeaderId' value='"+objItemHeader.npobjitemheaderid+"' >";
                        elemText += "<input type='hidden' name='hdnItemValue"+trim(objItemHeader.nphtmlname)+"' "+valuevisible+" >";
                        elemText += "<input type='text'   name='"+ trim(objItemHeader.nphtmlname) +"' ";
                        elemText += descvisible;
                        elemText += " size='12' style='text-align:right' readOnly>"+
                                    "</div>";
                        //alert("elemText : " + elemText );
                        cell.innerHTML = elemText;
                        elemText =  "";
                        index_arg++;
                    }
                    valFlag = true;
                    break;
                   
                }//Fin del If
               
             }//Fin del For
             if(!valFlag){
               //alert("[i][" + i + "] -> objItemHeader " + objItemHeader.npobjitemheaderid  + " --> " + objItemHeader.nphtmlname);  
               contentHidden += "<input type='hidden' name='hdnItemHeaderId' value='"+objItemHeader.npobjitemheaderid+"' >";
               contentHidden += "<input type='hidden' name='hdnItemValue"+trim(objItemHeader.nphtmlname)+"' "+valuevisible+" >";
               contentHidden += "<input type='hidden' name='"+ trim(objItemHeader.nphtmlname) +"' " + descvisible + " > ";         
               }   
             
          }//Fin del For
            
            var cellDelete = row.insertCell(index_arg-1);

            /* Boton de Borrar Item */
            elemText =                           "<input type='hidden' name='item_adde_period' value=''>" +
                                                 "<input type='hidden' name='item_adde_type' value=''>" +
                                                 "<input type='hidden' name='item_own_equip_new' value=''>" +
                                                 "<input type='hidden' name='hdnnpPromoHeaderId' value=''>" +
                                                 "<input type='hidden' name='hdnnpPromoDetailId' value=''>" +
                                                 "<input type='hidden' name='hdnnpPromoHeaderName' value=''>" +
                                                 "<input type='hidden' name='hdnnpOracleCode' value=''>" +
                                                 "<input type='hidden' name='hdnnpRealImei' value=''>" +
                                                 
                                                 "<input type='hidden' name='item_performance_flag' value='n'>" +
                                                 "<input type='hidden' name='item_perform_flag_serv' value='n'>" +
                                                 "<input type='hidden' name='hdnmodality' value=''>" +
                                                 "<input type='hidden' name='hdnreplacementmode' value=''>" +
                                                 "<input type='hidden' name='hdnnewmodality' value=''>" +
                                                 "<input type='hidden' name='item_excepBasicRentDesc'>" +
                                                 "<input type='hidden' name='item_excepBasicRentException'>" +
                                                
                                                 "<input type='hidden' name='item_excepRentDesc'>" +
                                                 "<input type='hidden' name='item_excepRentException'>" +
                                                
                                                 "<input type='hidden' name='item_excepServiceId'>" +
                                                 "<input type='hidden' name='item_excepServiceDiscount'>" +
                                                 
                                                 //"<input type='hidden' name='item_billingAccount'>" +
                                                
                                                 "<input type='hidden' name='item_excepMinAddConexDirecChecked'>" +
                                                 "<input type='hidden' name='item_excepMinAddInterConexChecked'>" +
                                                 
            
                        "<div id='eliminar' align='center' class='CellContent' >" +
                        "<a href='javascript:fVoid()' onclick='javascript:fxDeleteItemNew(this,this.parentNode.parentNode.parentNode.rowIndex,(" + (form.hdn_item_imei_grupo.value) + "));'  ><img src='websales/images/Eliminar.gif' border='no' ALT='Borrar Item'></a>"+
                        "</div>";
                        
            cellDelete.innerHTML = elemText+contentHidden;
            
       }//Fin del If CantElements
       
        wn_items = (items_table.rows.length -1); // numero de items 
         
          if ( wn_items > 1 ){
              wb_existItem =true;
          }
    
    fxLoadImeis(form.hdn_item_imei_grupo.value);
  
  }
  
  //Invoca al PopUp para la edici�n de un Item
  function fxAddRowOrderItemsGlobalEdit(vctItemOrder){
    fxaddElementsItemsMain(vctItemOrder);
    form = parent.mainFrame.document.frmdatos;
    var index_arg = 1;
    var elemText = "";
    var cantElement;
    
    var valuevisible = "";
    var descvisible = "";
    var typeControl = "";
    var cell;
    
    var contentHidden = "";
    
    cantElement = vctItemOrder.size();
    
        if (cantElement > 1) {/* los argumentos pasados.. a partir del segundo. */
          
          var row   = items_table.insertRow(-1);
          
          elemText =  "";
          var new_grupo = parseInt(form.hdn_item_imei_grupo.value) + parseInt(1);
          form.hdn_item_imei_grupo.value = new_grupo;
          
          /*Agrego la primera l�nea*/
          var cellPrinc = row.insertCell(index_arg - 1);
          elemText      = "<div id=\'contTable\' align='center' class='CellContent' >"+
                          "<input type=\'radio\' name=\'item_chek\' onclick=\'javascript:fxCargaServiciosItemItem(fxGetRowIndex(this));\'>"+
                          "<a href=\'javascript:;\' onclick=\'javascript:fxChangeItemEditDetailOrder(fxGetRowIndex(this),parent.mainFrame.vctItemsMainFrameOrder,parent.mainFrame.vctParametersOrder);\' ALT=\'Editar Item\'><font color=\'brown\' size=\'2\' face=\'Arial\' ><b>"+ (items_table.rows.length-1) +"</b></font></a> "+
                          "<a href=\'javascript:;\' onclick=\'javascript:fxAssignmentBillingAcount(fxGetRowIndex(this),parent.mainFrame.vctItemsMainFrameOrder,parent.mainFrame.vctParametersOrder);\' ALT=\'Editar Item\'>Billing</a> "+
                          "<input type=\'hidden\' name='hdnIndice' value="+ document.frmdatos.hdn_item_imei_grupo.value +" >" +
                          "<input type=\'hidden\' name='hdnFlagSave' value='"+ vctItemOrder.elementAt(0).npobjitemflagsave +"' >" +
                          "<input type=\'hidden\' name='hdnItemId' value='"+ vctItemOrder.elementAt(0).npitemid +"' >" +
                          "</div>";
          //alert("Agregando un Item : " + vctItemOrder.elementAt(0).npitemid);          
          cellPrinc.innerHTML = elemText;
          
          index_arg++;
          
          elemText = "";
          
          for( i = 0; i < vctItemHeaderOrder.size(); i++ ){

            var objItemHeader = vctItemHeaderOrder.elementAt(i);
            var valFlag = false;
            //Siempre mostrar Text y si coinciden asignar el Valor
              for( j = 0; j < vctItemOrder.size(); j++ ){

              var objItem = vctItemOrder.elementAt(j);
              
              //alert("[i][" + i + "][j]["+j+"] -> ( objItemHeader " + objItemHeader.npobjitemheaderid + " == objItem " + objItem.npobjitemheaderid + " ) -> " + objItem.nphtmlname );
              
              
                if ( objItemHeader.npobjitemheaderid == objItem.npobjitemheaderid ) {
                
                    valuevisible = " value='"+ objItem.npobjitemvalue + "' ";
                    descvisible  = " value='"+ objItem.npobjitemvaluedesc + "' ";
                    
                    if ( objItemHeader.npdisplay == "N" ) {
                        contentHidden += "<input type='hidden' name='hdnItemHeaderId' value='"+objItemHeader.npobjitemheaderid+"' >";
                        contentHidden += "<input type='hidden' name='hdnItemValue"+trim(objItemHeader.nphtmlname)+"' "+valuevisible+" >";
                        contentHidden += "<input type='hidden' name='"+ trim(objItemHeader.nphtmlname) +"' " + descvisible + " > ";
                    }else{
                        //alert("HTML : " +objItemHeader.nphtmlname + " index_arg " + index_arg)
                        cell = row.insertCell(index_arg - 1);
                        elemText += "<div id='"+ objItemHeader.nphtmlname +"'  align='center' class='CellContent' > ";
                        elemText += "<input type='hidden' name='hdnItemHeaderId' value='"+objItemHeader.npobjitemheaderid+"' >";
                        elemText += "<input type='hidden' name='hdnItemValue"+trim(objItemHeader.nphtmlname)+"' "+valuevisible+" >";
                        elemText += "<input type='text'   name='"+ trim(objItemHeader.nphtmlname) +"' ";
                        elemText += descvisible;
                        elemText += " size='12' style='text-align:right' readOnly>"+
                                    "</div>";
                        cell.innerHTML = elemText;
                        elemText =  "";
                        index_arg++;
                    }
                    valFlag = true;
                    break;
                   
                }//Fin del If
               
             }//Fin del For
           if(!valFlag){
             //alert("[i][" + i + "] -> objItemHeader " + objItemHeader.npobjitemheaderid  + " --> " + objItemHeader.nphtmlname);  
             contentHidden += "<input type='hidden' name='hdnItemHeaderId' value='"+objItemHeader.npobjitemheaderid+"' >";
             contentHidden += "<input type='hidden' name='hdnItemValue"+trim(objItemHeader.nphtmlname)+"' "+valuevisible+" >";
             contentHidden += "<input type='hidden' name='"+ trim(objItemHeader.nphtmlname) +"' " + descvisible + " > ";         
           }
           
          }//Fin del For
            
            var cellDelete = row.insertCell(index_arg-1);

            /* Boton de Borrar Item */
            elemText =                           "<input type='hidden' name='item_adde_period' value=''>" +
                                                 "<input type='hidden' name='item_adde_type' value=''>" +
                                                 "<input type='hidden' name='item_own_equip_new' value=''>" +
                                                 "<input type='hidden' name='hdnnpPromoHeaderId' value=''>" +
                                                 "<input type='hidden' name='hdnnpPromoDetailId' value=''>" +
                                                 "<input type='hidden' name='hdnnpPromoHeaderName' value=''>" +
                                                 "<input type='hidden' name='hdnnpOracleCode' value=''>" +
                                                 "<input type='hidden' name='hdnnpRealImei' value=''>" +
                                                 
                                                 "<input type='hidden' name='item_performance_flag' value='n'>" +
                                                 "<input type='hidden' name='item_perform_flag_serv' value='n'>" +
                                                 "<input type='hidden' name='hdnmodality' value=''>" +
                                                 "<input type='hidden' name='hdnreplacementmode' value=''>" +
                                                 "<input type='hidden' name='hdnnewmodality' value=''>" +
                                                 "<input type='hidden' name='item_excepBasicRentDesc'>" +
                                                 "<input type='hidden' name='item_excepBasicRentException'>" +
                                                
                                                 "<input type='hidden' name='item_excepRentDesc'>" +
                                                 "<input type='hidden' name='item_excepRentException'>" +
                                                
                                                 "<input type='hidden' name='item_excepServiceId'>" +
                                                 "<input type='hidden' name='item_excepServiceDiscount'>" +
                                                 
                                                 //"<input type='hidden' name='item_billingAccount'>" +
                                                
                                                 "<input type='hidden' name='item_excepMinAddConexDirecChecked'>" +
                                                 "<input type='hidden' name='item_excepMinAddInterConexChecked'>" +
                                                 
            
                        "<div id='eliminar' align='center' class='CellContent' >" +
                        "<a href='javascript:fVoid()' onclick='javascript:fxDeleteItemEdit(this,this.parentNode.parentNode.parentNode.rowIndex,(" + (form.hdn_item_imei_grupo.value) + "));'  ><img src='websales/images/Eliminar.gif' border='no' ALT='Borrar Item'></a>"+
                        "</div>";
                        
            cellDelete.innerHTML = elemText+contentHidden;
            
       }//Fin del If CantElements
       
        wn_items = (items_table.rows.length -1); // numero de items 
        //alert("Valor wn_items : " + wn_items);  
          if ( wn_items > 1 ){
              wb_existItem =true;
          }
        
    if( vflagEnabled )
    fxLoadImeis(form.hdn_item_imei_grupo.value);
  
  }
  
  function fxCargaServiciosItemItem(oindexRow){
   var servicios_item_send = "";
   form = document.frmdatos;
   /* Guardamos el numero del Item que se visualiza sus servicios */
   try{
     form.hdnItemSelectService.value =  oindexRow;
     servicios_item = oindexRow - 1;
     if (servicios_item == 0)
        if (form.item_services[servicios_item] == null)
           servicios_item_send = form.item_services.value;
        else
           servicios_item_send = form.item_services[servicios_item].value;
     else
        servicios_item_send = form.item_services[servicios_item].value;
     
     var a=appContext+"/serviceservlet?myaction=loadServiceItems&servicios_item="+servicios_item_send;
     form.action = a;
     
     form.submit();
   }catch(e){
     alert("Para esta categor�a no se aplican Servicios Adicionales");
   }
   
  }
  
  function fxEditRowOrderItemsGlobal(vctItemOrder,itemEdit_Index){
  
  form = document.frmdatos;
  
      try{
        form.item_services.value = GetSelectedServices();
      }catch(e){}
      
      var objvctItemHeaderOrder = vctItemHeaderOrder;
      var item_index = itemEdit_Index;
      
      
      for( i = 0; i < objvctItemHeaderOrder.size(); i++ ){
            
            var objItemHeader = objvctItemHeaderOrder.elementAt(i);
          
              for( x = 0; x < vctItemOrder.size(); x++ ){
                  
                  var objItem = vctItemOrder.elementAt(x);
              
                  if ( objItemHeader.npobjitemheaderid == objItem.npobjitemheaderid ) {
                    
                    var nameHTMLInput = vctItemOrder.elementAt(x).namehtmlitem;
                    
                    if( items_table.rows.length == 2 ){
                      var strConcatValue = "form.hdnItemValue"+trim(objItemHeader.nphtmlname)+".value = '" + objItem.npobjitemvalue + "'";
                      var strConcatDescr = "form."+trim(objItemHeader.nphtmlname)+".value = '" + objItem.npobjitemvaluedesc + "'";
                    }else{
                      var strConcatValue = "form.hdnItemValue"+trim(objItemHeader.nphtmlname)+"["+item_index+"].value = '" + objItem.npobjitemvalue + "'";
                      var strConcatDescr = "form."+trim(objItemHeader.nphtmlname)+"["+item_index+"].value = '" + objItem.npobjitemvaluedesc + "'";
                    }
                    
                    eval(strConcatValue);
                    eval(strConcatDescr);
                    
                    break;
                    
                 }
                    
              }
        }
   
  }
  
  
  
  //Funci�n que invoca a la ventana de Editar el PopUp en modo Creaci�n
  function fxChangeItemEditDetailOrderNew(item_index,vctItemsMainFrameOrder,vctrAuxOrden) {
   var vctItemsEdit = new Vector();
   var vctItemsEditAux = new Vector();
   var form = document.frmdatos;
   var num_rows = getNumRows("items_table");
   var vctAuxRead = new Vector();
   
    try{    
      if ( (form.cmbLugarAtencion != null) && (form.cmbLugarAtencion.value == "") ){
         alert("Debe seleccionar un Lugar de Despacho");
         form.cmbLugarAtencion.focus();
         return;
      }else if ( (form.cmbTienda != null) && (form.cmbTienda.value == "") )
          if (form.cmbLugarAtencion.value == ""){
            alert("Debe seleccionar un Lugar de Despacho");
            form.cmbTienda.focus();
            return;
      }
   }catch(e){}
  
   vctAuxRead = vctItemsMainFrameOrder.elementAt(item_index-1);
  
   var strUrlItemHeaderId   = "";
   var strUrlItemDesc       = "";
   var strUrlItemValue      = "";
   
     for( i = 0 ; i < vctAuxRead.size();  i ++ ) {
       var objAuxRead = vctAuxRead.elementAt(i);
       
       /*strUrlItemHeaderId += "paramNpobjitemheaderid="+objAuxRead.npobjitemheaderid+"&";
       strUrlItemValue    += "paramNpobjitemvalue="+objAuxRead.npobjitemvalue+"&";
       strUrlItemDesc     += "paramNpobjitemdesc="+objAuxRead.npobjitemvaluedesc+"&";*/
       strUrlItemHeaderId += "a="+replace(objAuxRead.npobjitemheaderid,"'","")+"&";
       //strUrlItemHeaderId += "b='"+replace(objAuxRead.npobjitemvalue,"'","")+"'&";
       strUrlItemHeaderId += "b="+replace(replace(objAuxRead.npobjitemvalue,"'",""),"%","99999999")+"&";              
     }
  
  
      var urlPage = "&";
      for( d = 0 ; d < vctrAuxOrden.size(); d++ ){
       var objVector = vctrAuxOrden.elementAt(d);
        
        urlPage = urlPage + objVector.objectDesc + "=" + objVector.objectValue + "&";
      }
      
       if(document.forms[0].chkVepFlag != null && document.forms[0].cmbVepNumCuotas!= null) {
        urlPage = urlPage + "strnpnumcuotas" + "=" + document.forms[0].cmbVepNumCuotas.value   + "&";
        urlPage = urlPage +  "strflagvep" + "=" + document.forms[0].chkVepFlag.value + "&"
      }
     
      if (document.forms[0].chkVepFlag !=undefined){
         if (document.forms[0].chkVepFlag.checked == true && document.forms[0].cmbVepNumCuotas.selectedIndex== 0){
            alert("Debe seleccionar el n�mero de cuotas de venta a plazos antes de agregar los �tems");
            return;
         }
      }     
      //alert("Valor del Item : " + form.hdnIndice[item_index-1].value );
      var frameUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpOrder.jsp?type_window=EDIT&objTypeEvent=NEW"+urlPage+strUrlItemHeaderId+"&item_index="+(item_index-1);
      //alert(frameUrl);
      var winUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpOrderFrame.jsp?av_url="+escape(frameUrl);
      popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=620, height=600, left=300, top=30, screenX=50, screenY=100");
  }
  
  function replace(texto,s1,s2){
    return texto.split(s1).join(s2);
  }
  
  function fxChangeItemEditDetailOrder(item_index,vctItemsMainFrameOrder,vctrAuxOrden) {
   var vctItemsEdit = new Vector();
   var vctItemsEditAux = new Vector();
   var form = document.frmdatos;
   var num_rows = getNumRows("items_table");
   var vctAuxRead = new Vector();
  
   vctAuxRead = vctItemsMainFrameOrder.elementAt(item_index-1);
   
   //alert("vctAuxRead : " + vctAuxRead.size())
  
   var strUrlItemHeaderId   = "";
   var strUrlItemDesc       = "";
   var strUrlItemValue      = "";
   
     for( i = 0 ; i < vctAuxRead.size();  i ++ ) {
       var objAuxRead = vctAuxRead.elementAt(i);
       
       //strUrlItemHeaderId += "paramNpobjitemheaderid="+objAuxRead.npobjitemheaderid+"&";
       //strUrlItemValue    += "paramNpobjitemvalue="+objAuxRead.npobjitemvalue+"&";
       //strUrlItemDesc     += "paramNpobjitemdesc="+objAuxRead.npobjitemvaluedesc+"&";
       
       strUrlItemHeaderId += "a="+replace(objAuxRead.npobjitemheaderid,"'","")+"&";
       //strUrlItemHeaderId += "b='"+replace(objAuxRead.npobjitemvalue,"'","")+"'&";
       strUrlItemHeaderId += "b="+replace(replace(objAuxRead.npobjitemvalue,"'",""),"%","99999999")+"&";              
       //strUrlItemHeaderId += "c="+replace(objAuxRead.npobjitemvaluedesc,"'","")+"&";
     }
     
     //alert("strUrlItemHeaderId : " + strUrlItemHeaderId)
     
   var urlPage = "&";
      for( d = 0 ; d < vctrAuxOrden.size(); d++ ){
       var objVector = vctrAuxOrden.elementAt(d);
        
        urlPage = urlPage + objVector.objectDesc + "=" + objVector.objectValue + "&";
      }
      
      var itemId = 0;
      if( num_rows == 1 ) itemId = form.hdnItemId.value;
      else  itemId = form.hdnItemId[item_index-1].value;
      
      
       if(document.forms[0].chkVepFlag != null && document.forms[0].cmbVepNumCuotas!= null) {
        urlPage = urlPage + "strnpnumcuotas" + "=" + document.forms[0].cmbVepNumCuotas.value   + "&";
        urlPage = urlPage +  "strflagvep" + "=" + document.forms[0].chkVepFlag.value + "&"
      }
      
      
      var frameUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpOrder.jsp?type_window=EDIT&objTypeEvent=EDIT&strItemId="+itemId+urlPage+strUrlItemHeaderId+"&item_index="+(item_index-1);
      
      var winUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpOrderFrame.jsp?av_url="+escape(frameUrl);
      popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=620, height=600, left=300, top=30, screenX=50, screenY=100");
  }
  
  function fxAssignmentBillingAcount(rowIndex,vctAuxItemsMain,vctAuxParameters){
   var servicios_item_send = "";
   var equipoDesc = "";
   var equipoId   = "";
   form = document.frmdatos;
   /* Guardamos el numero del Item que se visualiza sus servicios */
   try{
      form.hdnItemSelectService.value =  rowIndex;
      servicios_item = rowIndex - 1;
      if (servicios_item == 0)
         if (form.item_services[servicios_item] == null)
            servicios_item_send = form.item_services.value;
         else
            servicios_item_send = form.item_services[servicios_item].value;
      else
         servicios_item_send = form.item_services[servicios_item].value;
      
      var a=appContext+"/orderservlet?myaction=loadAssignmentBillingAccount&servicios_item="+servicios_item_send;
      a = a + "&txtCompanyId="+form.txtCompanyId.value+"&rowIndex="+rowIndex;
      
      var responsablePagoValue = form.cmbResponsablePago.value;
      var responsablePagoDesc  = form.cmbResponsablePago.options[form.cmbResponsablePago.selectedIndex].text;
      
      a = a + "&responsablePagoValue="+responsablePagoValue;
      a = a + "&responsablePagoDesc="+responsablePagoDesc;
      
      if( vctItemsMainFrameOrder.size() == 1 ){
         a             = a + "&item_billingAccount="+form.item_billingAccount.value;
         equipoDesc    = form.txtItemProduct.value;
         equipoId      = form.hdnItemValuetxtItemProduct.value;
         a             = a + "&equipoDesc="+equipoDesc+"&equipoId="+equipoId;
      }else{
         a = a + "&item_billingAccount="+form.item_billingAccount[rowIndex - 1].value;
         equipoDesc    = form.txtItemProduct[rowIndex - 1].value;
         equipoId      = form.hdnItemValuetxtItemProduct[rowIndex - 1].value;
         a             = a + "&equipoDesc="+equipoDesc+"&equipoId="+equipoId;
      }
      
      var winUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpOrderFrame.jsp?av_url="+escape(a);
      popupWin = window.open(winUrl, "Orden_Item_Assignment","status=yes, location=0, width=730, height=450, left=300, top=30, screenX=50, screenY=100");
    }catch(e){
     alert("Para esta categor�a no se requiere configurar Billing Account");
    }      
  }
  
  function fxTransferVectorItems(vctItemOrderMain,aux_index){
  
  var vctItemsAuxOrder = new Vector();  
    
    var strcadena = "";
    
    for( x = 0; x < vctItemOrderMain.size(); x++ ){
        
        var objMake = new fxMakeOrderItem(
        "'"+vctItemOrderMain.elementAt(x).npobjitemheaderid+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjspecgrpid+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjitemid+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjitemname+"'",
        "'"+vctItemOrderMain.elementAt(x).namehtmlheader+"'",
        "'"+vctItemOrderMain.elementAt(x).namehtmlitem+"'",
        "'"+vctItemOrderMain.elementAt(x).npcontroltype+"'",
        "'"+vctItemOrderMain.elementAt(x).npdefaultvalue+"'",
        "'"+vctItemOrderMain.elementAt(x).npsourceprogram+"'",
        "'"+vctItemOrderMain.elementAt(x).npspecificationgrpid+"'",
        "'"+vctItemOrderMain.elementAt(x).npdisplay+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjreadonly+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjitemvalue+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjitemvaluedesc+"'"
        );
        vctItemsAuxOrder.addElement(objMake);
        
    } 
    vctItemsMainFrameOrder.setElementAt(vctItemsAuxOrder,aux_index);
  }
  
  /*Deprecated  
  function fxLoadImeis(varItemImeiGroup){
  cItemsMain  = items_table.rows.length;
  try{
  //alert(cItemsMain);
  form = document.frmdatos;
 
  var cantItemsCurrent = 0;
  
  if( cItemsMain == 2 )
      cantItemsCurrent = form.txtItemQuantity.value;
  else{
      cantItemsCurrent = form.txtItemQuantity[(cItemsMain-2)].value;
  }
  
  for(j=0; j < cantItemsCurrent; j++){
  //alert("j : " + j + " < cantItemsCurrent " + cantItemsCurrent );
     var vctItemsImei       = new Vector();
     if( cItemsMain == 2 ) 
        vctItemsImei.addElement(new fxMakeItemImei(varItemImeiGroup,(j+1),varItemImeiGroup + "-" + (j+1) ,"","","",form.txtItemProduct.value,form.txtItemRatePlan.value,"","N","") );
     else
        vctItemsImei.addElement(new fxMakeItemImei(varItemImeiGroup,(j+1),varItemImeiGroup + "-" + (j+1) ,"","","",form.txtItemProduct[(cItemsMain-2)].value,form.txtItemRatePlan[(cItemsMain-2)].value,"","N","") );
     
     fxAddRowTableImeis( "table_imeis",vctItemsImei.elementAt(0),9);
  }
  
  vctItemsMainImei.addElement(vctItemsImei);
  }catch(e){}
          
  }
  */
  function fxaddElementsItemsMain(vctItemOrderMain){
    var vctItemsAuxOrder = new Vector();  
    
    var strcadena = "";
   
    for( x = 0; x < vctItemOrderMain.size(); x++ ){
 
        var objMake = new fxMakeOrderItem(
        "'"+vctItemOrderMain.elementAt(x).npobjitemheaderid+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjspecgrpid+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjitemid+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjitemname+"'",
        "'"+vctItemOrderMain.elementAt(x).namehtmlheader+"'",
        "'"+vctItemOrderMain.elementAt(x).namehtmlitem+"'",
        "'"+vctItemOrderMain.elementAt(x).npcontroltype+"'",
        "'"+vctItemOrderMain.elementAt(x).npdefaultvalue+"'",
        "'"+vctItemOrderMain.elementAt(x).npsourceprogram+"'",
        "'"+vctItemOrderMain.elementAt(x).npspecificationgrpid+"'",
        "'"+vctItemOrderMain.elementAt(x).npdisplay+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjreadonly+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjitemvalue+"'",
        "'"+vctItemOrderMain.elementAt(x).npobjitemvaluedesc+"'"
        );
        
        vctItemsAuxOrder.addElement(objMake);
       
    }
  
    vctItemsMainFrameOrder.addElement(vctItemsAuxOrder);
    
    

  }
  
  function getNumRows(tableID){
     var table = document.all ? document.all[tableID]:document.getElementById(tableID);
     return (table.rows.length-1) ; /* restandole la cabecera de detalle */
  }

   var vAreaCode = new Vector();   
   
 function fxChangeSalesMan(objThis,iUserId,iAppId){
   form = document.frmdatos;
   var txtCustomerId    = form.txtCompanyId.value;
   var txtSite          = form.cmbResponsablePago.value;
   var txtVendedorId    = objThis.options[objThis.selectedIndex].value; 
   var txtVendedor      = objThis.options[objThis.selectedIndex].text;   

   if (txtVendedorId != ""){
      form.txtPropuesta.value='';//CBARZOLA
      url= appContext+"/orderservlet?an_vendedorid="+txtVendedorId+"&myaction=getDealerNameBySalesman";
      url = url +"&an_CompanyId="+txtCustomerId+"&an_SiteId="+txtSite+"&av_Vendedor="+txtVendedor+"&iUserId="+iUserId+"&iAppId="+iAppId;      
      parent.bottomFrame.location.replace(url);
   }
  }
  
  
function fxDeleteItemImeis(item_row){
   //alert("Entramos : " +item_row )
   var form = document.frmdatos;
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   var num_items = table.rows.length - 1;
   var cantidad_prod = 0;
   var borro_item_imei = false;
   var long_new_table; /* obtenemos la longuitud de la nueva tabla, despues de borrar los items */
   /* Inicio: Borrado de los items_imeis correspondientes a los items_pedido */
   if (table.rows.length  == 2){
      if (form.hdnIndice_imei.value == undefined){
         if (form.hdnIndice_imei[0].value == item_row){
            table.deleteRow(1); };
      }
      else{
         if (form.hdnIndice_imei.value == item_row){
            table.deleteRow(1); };
      };
   };
   else{
      if (table.rows.length > 2){
         for (k=(num_items-1); k >= 0; k--){
            if (k>0){
               if (form.hdnIndice_imei[k].value == item_row){
                  table.deleteRow(k+1); }
            };
            else{
               if (k==0){
                  if ( form.hdnIndice_imei.value == item_row )
                     table.deleteRow(1);
                  else
                     if ( form.hdnIndice_imei[0].value == item_row )
                        table.deleteRow(1);
               };
            };
         };
      };
   }; /* Fin */
   long_new_table = table.rows.length;
   /* Actualizamos los hidden que guardan el n�mero de item_pedido correspondiente */
   if (long_new_table == 2 ){
      if (num_items > 1){
         if (form.hdnIndice_imei[0].value > (item_row)){
            form.hdnIndice_imei[0].value = parseInt(form.hdnIndice_imei[0].value) - 1;}
      }
      else{
         if (num_items == 1){
            if (form.hdnIndice_imei.value == undefined){
               if (form.hdnIndice_imei[0].value > (item_row)){
                  form.hdnIndice_imei[0].value = parseInt(form.hdnIndice_imei[0].value) - 1;}
            }
            else{
               if (form.hdnIndice_imei.value > (item_row)){
                  form.hdnIndice_imei.value = parseInt(form.hdnIndice_imei.value) - 1;}
            }
         }
      }
   }
   else{
      if (long_new_table > 2){
         for (k=0; k <(long_new_table - 1); k++){
            if (form.hdnIndice_imei[k].value > (item_row)){
               form.hdnIndice_imei[k].value = parseInt(form.hdnIndice_imei[k].value) - 1;}
         };
      };
   };

   /*  Seleccionamos el primer item_imei que se encuentra vacio para continuar registrando imeis   */
   if (long_new_table == 2){
      form.item_imei_radio.checked = true;
      form.hdn_item_imei_selecc.value = 0; }
   else {
      if (long_new_table > 2){
         for (m=0; m<(long_new_table - 1); m++){
            if (form.item_imei_imei[m].value==""){
               form.item_imei_radio[m].checked = true;
               form.hdn_item_imei_selecc.value = m;
               return false;  }
         };
      };
   };
}

function fxImeiBorraNew(){
   var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
   if (table.rows.length < 2){
      alert("No se puede realizar la acci�n");
      return; };

   if (table.rows.length > 2){
      if (form.item_imei_imei[form.hdn_item_imei_selecc.value].value =="" && form.item_imei_sim[form.hdn_item_imei_selecc.value].value ==""){
         alert("No se puede realizar la acci�n, SIM/IMEI vacio");
         return; }
   };

   if (table.rows.length == 2){
      if (form.item_imei_imei.value =="" && form.item_imei_sim.value ==""  ){
            alert("No se puede realizar la acci�n, SIM/IMEI vacio");
            return false;
      };
   };

   if (confirm("Desea borrar el SIM/IMEI de este item?")){
      if (form.hdn_item_imei_selecc.value == ""){
         alert("Seleccione un item");}
      else{
          try{
            parent.mainFrame.document.frmdatos.hdnChangedOrder.value="S";
         }catch(e){;}
         if (table.rows.length > 2){
            form.item_imei_imei[form.hdn_item_imei_selecc.value].value = "";
            form.item_imei_sim[form.hdn_item_imei_selecc.value].value = "";
            form.item_imei_check[form.hdn_item_imei_selecc.value].value = "N"; 
         }
         else{
            form.item_imei_imei.value = "";
            form.item_imei_sim.value = "";
            form.item_imei_check.value = "N"; 
         }
      }
   }
};