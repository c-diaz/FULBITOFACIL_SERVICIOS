/*
 * Funciones que se encargan de la validaci�n de servicio roaming recurrente.
 * MMONTOYA 09/09/2015
 */

// Invocado desde PopUpOrder.jsp.
function validateSelectedRecurrentRoamingService(specificationId, orderId) {
    if (specificationId != SPEC_ACTIVAR_PAQUETES_ROAMING) {
        return true;
    }

    // Inicio Obtiene el bagType y el validity
    var bagType = null;
    var validity = null;

    for (i = 0; i < vServicio.size(); i++){
        var objServicio = vServicio.elementAt(i);

        if (objServicio.id == form.cmbItemServiceROA.value) {
            bagType = objServicio.bagType;
            validity = objServicio.validity;
            break;
        }
    }
    // Fin Obtiene el bagType.

    var phone = form.txt_ItemPhone.value;
    var processDate = parent.opener.document.frmdatos.txtFechaProceso.value;
    return validateRecurrentRoamingService(bagType, phone, processDate, validity, orderId);
}

// Invocado desde JP_ORDER_NEW_END_showpage.jsp y JP_ORDER_EDIT_STAR.jsp
function validateAllRecurrentRoamingService(specificationId, orderId) {
    if (specificationId != SPEC_ACTIVAR_PAQUETES_ROAMING) {
        return true;
    }

    var processDate = form.txtFechaProceso.value;
    if (!validateProcessDate(specificationId)) {
        return;
    }

    var table = document.getElementById("items_table");
    var txtItemServBagType = $('[name="hdnItemValuetxtItemServBagType"]');
    var txtItemPhone = $('[name="hdnItemValuetxtItemPhone"]');
    var txtItemServValidActivationDate = $('[name="hdnItemValuetxtItemServValidActivationDate"]');
    var txtItemServValidity = $('[name="hdnItemValuetxtItemServValidity"]');

    for (var i = 1; i < table.rows.length; i++) {
        var index = i - 1; // El array de controles no coincide con el de filas debido al header.
        var bagType = txtItemServBagType[index].value;
        var phone = txtItemPhone[index].value;
        var activationDate = txtItemServValidActivationDate[index].value;
        var validity = txtItemServValidity[index].value;

        // Si se modific� la fecha de proceso, se vuelve a validar.
        if (processDate != activationDate) {
            if (!validateRecurrentRoamingService(bagType, phone, processDate, validity, orderId)) {
                return false;
            }

            // Pas� la validaci�n, se guarda el nuevo valor de la fecha de activaci�n.
            txtItemServValidActivationDate[index].value = processDate;
        }
    }

    return true;
}

function validateRecurrentRoamingService(bagType, phone, processDate, validity, orderId) {
    if (bagType == TIPO_BOLSA_RECURRENTE) {
        var message = null;

        $.ajax({
            url: CONTEXT_PATH + "/itemServlet",
            data: "strPhone=" + phone + "&strProcessDate=" + processDate + "&strValidity=" + validity + "&strOrderId=" + orderId + "&hdnMethod=validateRecurrentRoamingService",
            async: false,
            type: "POST",
            success:function(data) {
                message = data;
            }
        });

        if (message != null && message != "") {
            alert(message);
            return false;
        }
    }

    return true
}

/*
 * Funciones que se encargan de la validaci�n de la fecha de activaci�n.
 * MMONTOYA 06/10/2015
 */

// Invocado desde NewOnDisplaySectionItems.jsp y EditOnDisplaySectionItems.jsp
 function validateProcessDate(specificationId) {
    if (specificationId != SPEC_ACTIVAR_PAQUETES_ROAMING) {
        return true;
    }

    if (form.txtFechaProceso.value == "" || form.txtFechaProceso.value == null) {
        alert("No ha ingresado la fecha de activaci�n");
        form.txtFechaProceso.focus();
        return false;
    } else {
        // Valida que la fecha de proceso sea mayor que la fecha actual.
        var params = form.txtFechaProceso.value.split("/");
        var day = params[0];
        var month = params[1];
        var year = params[2];
        var processDate = new Date();
        processDate.setFullYear(year, month - 1, day);
        var today = new Date();

        // La fecha de activaci�n programada debe ser mayor al d�a de registro de la orden.
        if (!(processDate > today)) {
            alert("La fecha de activaci�n debe ser posterior a la actual");
            form.txtFechaProceso.focus();
            return false;
        }
    }

    return true;
 }

