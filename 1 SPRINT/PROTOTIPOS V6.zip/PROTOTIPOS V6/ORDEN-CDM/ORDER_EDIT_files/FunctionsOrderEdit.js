/*
   Developer :    Robert Moreno 
*/


      function fGetRejectItem(index){
         return gpRejectArr[index];
      }
      function fLoadRejectArr(ObjectReject){
         gpRejectArr[gIndexReject]=new fCloneObject(ObjectReject);
         gIndexReject++;
      }
      function fCloneObject(ObjectReject){
         for (var i in ObjectReject){
            this[i] = ObjectReject[i];
         }
      }
      function fSetRejectArr(){
         gpRejectArr  =null;
         gpRejectArr  =new Array();
         gIndexReject=0;
      }
      function CreateReject(nporderrejectid,nppedidoid,npreason,npdescription,npstatus,npcreatedby,npdatecreated,npmodifiedby,mpmodifydate,npinbox){
         this.nporderrejectid =nporderrejectid;
         this.nppedidoid      =nppedidoid;
         this.npreason        =npreason;
         this.npdescription   =npdescription;
         this.npstatus        =npstatus;
         this.npcreatedby     =npcreatedby;
         this.npdatecreated   =npdatecreated;
         this.npmodifiedby    =npmodifiedby;
         this.mpmodifydate    =mpmodifydate;
         this.npinbox         =npinbox;
         this.isModified      ="false";
      }

      function fSetRejects(){
         var Form = document.frmdatos;
         var Rejects="";
         Form.hdnRejects.value="";
         for(var i=0;i<gpRejectArr.length;i++){
            Rejects+=gpRejectArr[i].nporderrejectid + "|";
            Rejects+=gpRejectArr[i].nppedidoid + "|";
            Rejects+=gpRejectArr[i].npreason + "|";
            Rejects+=gpRejectArr[i].npdescription + "|";
            Rejects+=gpRejectArr[i].npstatus + "|";
            Rejects+=gpRejectArr[i].npcreatedby + "|";
            Rejects+=gpRejectArr[i].npdatecreated + "|";
            Rejects+=gpRejectArr[i].npmodifiedby + "|";
            Rejects+=gpRejectArr[i].mpmodifydate + "|";
            Rejects+=gpRejectArr[i].npinbox+ "|";
            Rejects+=gpRejectArr[i].isModified+ "|";
         }
         Form.hdnRejects.value=Rejects;

      }

      function fGetPendDescriptionRejects(){
         var Rejects="";
         for(var i=0;i<gpRejectArr.length;i++){
            if (gpRejectArr[i].npstatus=="N"){
                  Rejects+=gpRejectArr[i].npreason + ", ";
            }
         }
         Rejects=Rejects.substring(0,Rejects.length - 2);
         return Rejects;
      }

      function fGetSubsDescriptionRejects(){
         var Rejects="";
         for(var i=0;i<gpRejectArr.length;i++){
            if (gpRejectArr[i].npstatus=="S"){
               Rejects+=gpRejectArr[i].npreason + ", ";
            }
         }
         Rejects=Rejects.substring(0,Rejects.length - 2);
         return Rejects;
      }

      function fReloadRejects(){
         var table = document.all?document.all["tableRejects"]:document.getElementById("tableRejects");
         var tbody = table.getElementsByTagName("tbody")[0]; //ingreso al cuerpo de la tabla.
         var longitud=tbody.childNodes.length;
         var CellSubs,CellPend, RejectsSubs,RejectsPend;
         if (tbody.hasChildNodes()){
            RejectsSubs =  fGetSubsDescriptionRejects();
            RejectsPend =  fGetPendDescriptionRejects();
            CellSubs    =  tbody.childNodes.item(1).childNodes.item(1);
            CellPend    =  tbody.childNodes.item(1).childNodes.item(0);
            CellPend.innerHTML   =  RejectsPend;
            CellSubs.innerHTML   =  RejectsSubs;
         }
      }


      function editReject(){
         var Form = document.frmdatos;
         if (Form.cmbLugarAtencion.options[Form.cmbLugarAtencion.selectedIndex].text!="" && Form.cmbLugarAtencion.selectedIndex !=-1){
            var frameUrl = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT02_PL_PKG.PL_ORDER_REJECT_EDIT"
                           +"?hdnOrderId="+     escape(g_orderid)
                           +"&txtEstadoOrden="+  escape(Form.txtEstadoOrden.value)
                           +"&WorkFlowType="+    escape(Form.hdnWorkflowType.value)
                           +"&specialtyid="+     Form.hdnSubCategoria.value
            var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
            var popupWin = window.open(winUrl, "Orden_Rechazos","status=yes, location=0, width=800, height=500, left=50, top=100, screenX=50, screenY=100");
         }else{
            alert("Seleccione el Lugar de Atenci�n");
            Form.cmbLugarAtencion.focus();
            return;
         }
      }
      /*edita una promocion*/
      function fEditPromotion(idPromoHeader,PromoHeaderName){
         var form = document.frmdatos;
         var item_adde_period, item_adde_type;
         if (getNumRows("table_items")>1){
            item_adde_period  =form.item_adde_period[arguments[2]].value;
            item_adde_type    =form.item_adde_type[arguments[2]].value;
         }else{
            item_adde_period  =form.item_adde_period.value;
            item_adde_type    =form.item_adde_type.value;
         }
         var frameUrl = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT02_PL_PKG.PL_ORDER_PROMOTION_EDIT"
                        +"?item_index=0"
                        +"&item_code=0"
                        +"&item_product_id="
                        +"&item_product_dsc="
                        +"&item_prod_line_id="
                        +"&item_plan_id="
                        +"&item_plan_dsc="
                        +"&item_quantity="
                        +"&txtnpTelefono="
                        +"&hdnnpTelefonoNuevo="
                        +"&item_imei="
                        +"&hdnnpImeiNuevo="
                        +"&item_product_price="
                        +"&item_except_prodprice="
                        +"&item_total="
                        +"&item_adde_period="            + item_adde_period
                        +"&item_adde_type="              + item_adde_type
                        +"&item_own_equip="
                        +"&hdnnpPromoHeaderId="          + idPromoHeader
                        +"&hdnnpPromoHeaderName="        + PromoHeaderName
                        +"&hdnnpPromoDetailId="
                        +"&hdnnpOracleCode="
                        +"&hdnnpRealImei="
                        +"&item_services="
                        +"&product_type="                + escape(form.hdnProductType.value)
                        +"&specialtyid="                 + escape(form.hdnSubCategoria.value)
                        +"&customer_id_bscs="            + escape(form.hdnCodBSCS.value)
                        +"&handset_allowed="             + escape(form.hdnHandSetAllowed.value)
                        +"&main_object_type="            + escape(form.hdnMainObjectType.value)
                        +"&product_handling="            + escape(form.hdnProductHandling.value)
                        +"&rate_plan_handling="          + escape(form.hdnRatePlanHandling.value)
                        +"&additional_service_allowed="  + escape(form.hdnAdditionalServiceAllowed.value)
                        +"&consignment_allowed="         + escape(form.hdnConsignmentAllowed.value)
                        +"&price_type="                  + escape(form.hdnPriceType.value)
                        +"&service_type="                + escape(form.hdnServiceType.value)
                        +"&tipo_compa�ia="               + escape(form.txtTipoCompania.value)
                        +"&additional_object_type="      + escape(form.hdnAdditionalObjectType.value)
                        +"&main_object_validate="        + escape(form.hdnMainObjectValidate.value)
                        +"&additional_object_valid="     + escape(form.hdnAdditionalObjectValid.value)
                        +"&prod_release_id_orig="
                        +"&prod_release_name_orig="
                        +"&plan_orig="
                        +"&plan_id_orig=";
         var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
         var popupWin = window.open(winUrl, "detalle","status=yes, location=0, width=450, height=500, left=50, top=100, screenX=50, screenY=100");
      }


      function fAddPromotion(){
         var form = document.frmdatos;
         var frameUrl = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT02_PL_PKG.PL_ORDER_PROMOTION_EDIT"
                        +"?item_index=0"
                        +"&item_code=-1"
                        +"&item_product_id="
                        +"&item_product_dsc="
                        +"&item_prod_line_id="
                        +"&item_plan_id="
                        +"&item_plan_dsc="
                        +"&item_quantity="
                        +"&txtnpTelefono="
                        +"&hdnnpTelefonoNuevo="
                        +"&item_imei="
                        +"&hdnnpImeiNuevo="
                        +"&item_product_price="
                        +"&item_except_prodprice="
                        +"&item_total="
                        +"&item_adde_period="
                        +"&item_adde_type="
                        +"&item_own_equip="
                        +"&hdnnpPromoHeaderId="
                        +"&hdnnpPromoHeaderName="
                        +"&hdnnpPromoDetailId="
                        +"&hdnnpOracleCode="
                        +"&hdnnpRealImei="
                        +"&item_services="
                        +"&product_type="                + escape(form.hdnProductType.value)
                        +"&specialtyid="                 + escape(form.hdnSubCategoria.value)
                        +"&customer_id_bscs="            + escape(form.hdnCodBSCS.value)
                        +"&handset_allowed="             + escape(form.hdnHandSetAllowed.value)
                        +"&main_object_type="            + escape(form.hdnMainObjectType.value)
                        +"&product_handling="            + escape(form.hdnProductHandling.value)
                        +"&rate_plan_handling="          + escape(form.hdnRatePlanHandling.value)
                        +"&additional_service_allowed="  + escape(form.hdnAdditionalServiceAllowed.value)
                        +"&consignment_allowed="         + escape(form.hdnConsignmentAllowed.value)
                        +"&price_type="                  + escape(form.hdnPriceType.value)
                        +"&service_type="                + escape(form.hdnServiceType.value)
                        +"&tipo_compa�ia="               + escape(form.txtTipoCompania.value)
                        +"&additional_object_type="      + escape(form.hdnAdditionalObjectType.value)
                        +"&main_object_validate="        + escape(form.hdnMainObjectValidate.value)
                        +"&additional_object_valid="     + escape(form.hdnAdditionalObjectValid.value)
                        +"&prod_release_id_orig="
                        +"&prod_release_name_orig="
                        +"&plan_orig="
                        +"&plan_id_orig=";
         var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
         var popupWin = window.open(winUrl, "detalle","status=yes, location=0, width=450, height=500, left=50, top=100, screenX=50, screenY=100");
      }

      function enabledDelete(){
         deleteItemEnabled = true;
      };

      function clearFields() {
         var form = document.frmdatos;
         for (i=0; i < wn_items; i++) {
            clearItemFields(i);
         }
      }

      /* no hace nada*/
      function fVoid(){
      }

      function ItemBorrado(item_id){
         this.item_id = item_id;
      }

      var vItemsBorrado = new Vector();

      function deleteAllValues(listField){
         for (i=listField.options.length-1; i>=0; i--){
            listField.options[i] = null;
         };
         /* si lo que borramos es el comoBox de Servicios */
         if (listField.name == "cmbSelectedServices"){
            oOption = parent.mainFrame.document.createElement("option");
            oOption.value  = "";
            oOption.text   = "                  ";
            listField.add(oOption);
         };
      }

      /* Elimina un item de la Tabla */
      function deleteItem(CellObject,item_id){
         if (wn_flag_borrar_item != 1){
            alert("No tiene privilegios para borrar el Item"); return;
         }
         if (document.frmdatos.txtNumeroGuia.value != ""){
            alert("La gu�a ya fue generada. No puede eliminar un item.");
            return;
         }

         if (document.frmdatos.hdnAutorizSalesRq.value=="3"){
            alert("Esta orden contiene Item(s) con Excepci�n que fueron Aprobados, es por ello que no se puede eliminar ning�n Item");
            return;
         }

         var item_pedido_numero     = CellObject.parentNode.parentNode.parentNode.rowIndex;
         var item_promo_header_id   = CellObject.parentNode.parentNode.childNodes.item(3).getAttribute("value");
/*
         if (item_promo_header_id!="" && item_promo_header_id>0){
            if (confirm("El Item seleccionado pertenece a una Promoci�n, desea eliminarla?")){
               var table = document.all ? document.all["table_items"]:document.getElementById("table_items");
               var tbody = table.getElementsByTagName("tbody")[0]; // ingreso al cuerpo de la tabla.
               var rows =  tbody.childNodes;
               var nrows = tbody.childNodes.length;
               var item_promo_header_id_act, item_id_act, rowItem;
               for(var i=nrows-1;i>0;i--){
                  item_promo_header_id_act=rows.item(i).childNodes.item(12).childNodes.item(3).getAttribute("value");
                  if (item_promo_header_id_act==item_promo_header_id){// eliminar la fila
                     item_pedido_numero=rows.item(i).rowIndex;
                     rowItem=rows.item(i);
                     item_id_act=rows.item(i).childNodes.item(1).childNodes.item(1).getAttribute("value");
                     table.deleteRow(i);
                     if (item_id_act>0)
                        vItemsBorrado.addElement(new ItemBorrado(item_id_act));
                     wn_items=tbody.childNodes.length -1;
                     DeleteItemImeis(item_pedido_numero);
                  }
               }
               wn_items=tbody.childNodes.length -1;
               wb_existItem=(wn_items>=1)?false:wb_existItem;
               wb_existItem=(wn_items>2)?true:false;
               fSetNroItemOrder(wn_items);
               CalculateTotalSalesPrice();
            }
         }else{
*/
            if (confirm("Desea eliminar el item?")){
               if (deleteItemEnabled){
                  var table = document.all ? document.all["table_items"]:document.getElementById("table_items");
                  wb_existItem=(wn_items>=1)?false:wb_existItem;
                  wb_existItem=(wn_items>2)?true:false;
                  DeleteItemImeis(item_pedido_numero);
                  table.deleteRow(CellObject.parentNode.parentNode.parentNode.rowIndex);
                  wn_items=(table.rows.length-1);
                  if (item_id > 0) {
                     vItemsBorrado.addElement(new ItemBorrado(item_id));
                  };
                  fSetNroItemOrder(wn_items);
                  CalculateTotalSalesPrice();
                  if (parseInt(document.frmdatos.hdnItemSelectService.value) == parseInt(item_pedido_numero) ){
                     deleteAllValues(document.frmdatos.cmbSelectedServices);
                  };
               }else {
                  alert("No puede eliminar, cierre antes la ventana de edici�n de Items");
               };
               return false;
            }
         /*} */
      }


      function DeleteItemImeis(item_row){
         var form = document.frmdatos;
         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
         var num_items = table.rows.length - 1;
         var cantidad_prod = 0;
         var long_new_table; /* obtenemos la longuitud de la nueva tabla, despues de borrar los items */
         /*  Inicio: Borrado de los items_imeis correspondientes a los items_pedido */

         if ( table.rows.length  == 2){
            if (form.hdnIndice_imei.value == undefined){
               if (form.hdnIndice_imei[0].value == item_row){
                  table.deleteRow(1); };
            }
            else{
               if (form.hdnIndice_imei.value == item_row){
                  table.deleteRow(1); };
            };
         };
         else{
            if ( table.rows.length > 2){
               for (k=(num_items-1); k >= 0; k--){
                  if (form.hdnIndice_imei[k].value == item_row){
                     table.deleteRow(k+1);
                     cantidad_prod = cantidad_prod + 1; }
               };
            };
         }; /* Fin */
         item_index_imei = item_index_imei - (cantidad_prod - 1);
         long_new_table = table.rows.length;
         /* Actualizamos los hidden que guardan el n�mero de item_pedido correspondiente  */
         if (long_new_table == 2 ){
            if (num_items > 1){
               if (form.hdnIndice_imei[0].value > (item_row)){
                  form.hdnIndice_imei[0].value = parseInt(form.hdnIndice_imei[0].value) - 1;}
            }
            else{
               if (num_items == 1){
                  if (form.hdnIndice_imei.value == undefined){
                     if (form.hdnIndice_imei[0].value > (item_row)){
                        form.hdnIndice_imei[0].value = parseInt(form.hdnIndice_imei[0].value) - 1;}
                   }
                   else{
                     if (form.hdnIndice_imei.value > (item_row)){
                        form.hdnIndice_imei.value = parseInt(form.hdnIndice_imei.value) - 1;}
                   }
               }
            }
         }
         else{
            if (long_new_table > 2){
               for (k=0; k <(long_new_table - 1); k++){
                  if (form.hdnIndice_imei[k].value > (item_row)){
                     form.hdnIndice_imei[k].value = parseInt(form.hdnIndice_imei[k].value) - 1;}
               };
            };
         };

         /*  Seleccionamos el primer item_imei que se encuentra vacio para continuar registrando imeis   */
         if (long_new_table == 2){
            form.item_imei_radio.checked = true;
            form.hdn_item_imei_selecc.value = 0; }
         else {
            if (long_new_table > 2){
               for (m=0; m<(long_new_table - 1); m++){
                  if (form.item_imei_imei[m].value==""){
                     form.item_imei_radio[m].checked = true;
                     form.hdn_item_imei_selecc.value = m;
                     return false;  }
               };
            };
         };
      }

            /* Para setear el numero de item del detalle del Pedido, despues de haber eliminado un item */
      function fSetNroItemOrder(num_items){
         var table = document.all ? document.all["table_items"]:document.getElementById("table_items");
         var tbody =table.childNodes.item(0);//tbody
         var rows=tbody.childNodes;
         var row;
         if (num_items == 0){
            return; }
         else{
            if (num_items > 0){
               for(var i=1;i<=num_items;i++){
                  row=rows.item(i);
                  element = row.getElementsByTagName("a");
                  element.item(0).setAttribute("href","javascript:ChangeItemDetail("+(i-1).toString()+");");
               }
            }
         }
      }

      function round(number,X) {
         X = (!X ? 2 : X);
         return Math.round(number*Math.pow(10,X))/Math.pow(10,X);
      };

      /* Funciones que calculan los datos ingresados */
      function CalculateTotalByItem(item_number) {
         var form = document.frmdatos;
         if (getNumRows("table_items")>1) {
            var price = form.item_product_price[item_number].value;
            var exc_price = form.item_except_prodprice[item_number].value;
            price = (exc_price!="")?exc_price:price;
            var pos_coma  = price.indexOf(",",0);
            var pos_final = price.length;
            var price_new = price.substring(0,pos_coma) + price.substring(pos_coma+1,pos_final);
            var total = parseFloat(form.item_quantity[item_number].value)*parseFloat(price_new);
            if ( total >= 0 ) {
               form.item_total[item_number].value = CompletarNumeroDec(""+total);
            }else {
               form.item_total[item_number].value = "";
            }
         }
         else{
           var price = form.item_product_price.value;
           var exc_price = form.item_except_prodprice.value;
           price = (exc_price!="")?exc_price:price;
           var pos_coma  = price.indexOf(",",0);
           var pos_final = price.length;
           var price_new = price.substring(0,pos_coma) + price.substring(pos_coma+1,pos_final);
           var total = parseFloat(form.item_quantity.value)*parseFloat(price_new);
           if ( total >= 0 ) {
              form.item_total.value = CompletarNumeroDec(""+total)
           }else {
              form.item_total.value = "";
           }
         }
      }

      function CalculateTotalSalesPrice() {
         var form = document.frmdatos;
         var nrows = getNumRows("table_items");
         var total = 0;
         if (nrows > 1) {
            for (i=0; i < wn_items; i++) {
               valor = form.item_total[i].value;
               if (valor!="") {
                  total = total + eval(valor) ; }
            }
         }
         if (nrows == 1){
            if (!wb_existItem) {
               valor = form.item_total.value;
               if (typeof(form.item_total.value) == "undefined"){
                  valor = form.item_total[0].value; }
            }else{
               valor = form.item_total[0].value;  }

            if (valor!="") {
               total = total + eval(valor) ; }
        }
        form.txtTotalSalesPrice.value = ( total != 0 )?CompletarNumeroDec(""+round(eval(total),2)):"0";
        form.txtImporteFactura.value = ( total != 0 )?CompletarNumeroDec(""+round(eval(total),2)):"0";
        var ImpFactura        =  form.txtImporteFactura.value;
        var TotalPaymentOrig  =  form.hdnTotalPaymentOrig.value;
        var PagoDisponible    =  form.hdnPagoDisponible.value;
        var TotalPayment, SaldoPayment;
        /* Debo actualizar el Total pagado, ya que se ha modificado el importe de la Factura. */
        TotalPayment          = (Math.min(parseFloat((ImpFactura==""?"0":ImpFactura)),parseFloat((TotalPaymentOrig=="")?"0":TotalPaymentOrig) + parseFloat((PagoDisponible=="")?"0":PagoDisponible))).toString();
        if (parseFloat(TotalPaymentOrig) > 0 && parseFloat(TotalPaymentOrig) > parseFloat(ImpFactura)){
            form.txtnpTotalPayment.value  = ( TotalPaymentOrig!= 0 )?CompletarNumeroDec(""+round(eval(TotalPaymentOrig),2)):"0"; //TotalPaymentOrig;
        }
        else{
            form.txtnpTotalPayment.value   = ( TotalPayment != 0 )?CompletarNumeroDec(""+round(eval(TotalPayment),2)):"0";
        }
        /*Actualizamos el Saldo.*/
        SaldoPayment          =  ImpFactura - form.txtnpTotalPayment.value;
        form.txtSaldo.value =  ( SaldoPayment != 0 )?CompletarNumeroDec(""+round(eval(SaldoPayment),2)):"0";
      }

      function clearItemFields(item_index) {
         var form = document.frmdatos;
         if (getNumRows("table_items")>1){
            form.item_code[item_index].value                 = "-1";
            form.item_product_id[item_index].value           = "";
            form.item_product_dsc[item_index].value          = "";
            form.item_prod_line_id[item_index].value         = "";
            form.item_plan_id[item_index].value              = "";
            form.item_plan_dsc[item_index].value             = "";
            form.item_quantity[item_index].value             = "";
            form.txtnpTelefono[item_index].value             = "";
            form.hdnnpTelefonoNuevo[item_index].value        = "";
            form.item_imei[item_index].value                 = "";
            form.hdnnpImeiNuevo[item_index].value            = "";
            form.item_product_price[item_index].value        = "";
            form.item_except_prodprice[item_index].value     = "";
            form.item_total[item_index].value                = "";
            form.item_adde_period[item_index].value          = "";
            form.item_adde_type[item_index].value            = "";
            form.item_own_equip[item_index].value            = "";
            form.hdnnpPromoHeaderId[item_index].value        = "";
            form.hdnnpPromoDetailId[item_index].value        = "";
            form.hdnnpOracleCode[item_index].value           = "";
            form.hdnnpRealImei[item_index].value             = "";
            form.item_services[item_index].value             = "";
         }
         else{
            form.item_code.value              = "-1";
            form.item_product_id.value        = "";
            form.item_product_dsc.value       = "";
            form.item_prod_line_id.value      = "";
            form.item_plan_id.value           = "";
            form.item_plan_dsc.value          = "";
            form.item_quantity.value          = "";
            form.txtnpTelefono.value          = "";
            form.hdnnpTelefonoNuevo.value     = "";
            form.item_imei.value              = "";
            form.hdnnpImeiNuevo.value         = "";
            form.item_product_price.value     = "";
            form.item_except_prodprice.value  = "";
            form.item_total.value             = "";
            form.item_adde_period.value       = "";
            form.item_adde_type.value         = "";
            form.item_own_equip.value         = "";
            form.hdnnpPromoHeaderId.value     = "";
            form.hdnnpPromoDetailId.value     = "";
            form.hdnnpOracleCode.value        = "";
            form.hdnnpRealImei.value          = "";
            form.item_services.value          = "";
         }
      }

      function CargaServiciosItem(oindexRow){
         form = document.frmdatos;
         /* Guardamos el numero del Item que se visualiza sus servicios */
         form.hdnItemSelectService.value =  oindexRow;
         servicios_item = oindexRow - 1;
         if (servicios_item == 0){
            if (form.item_services[servicios_item] == null){
               servicios_item = form.item_services.value;}
            else{
               servicios_item = form.item_services[servicios_item].value;}
         }
         else{
            servicios_item = form.item_services[servicios_item].value;}

         var a="/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT_PL_PKG.PL_LOAD_SERVICES_BY_ITEM?AV_SERVICES_ITEM="+servicios_item;
         parent.bottomFrame.location.replace(a);
      }


      function getNumRows(tableID){
         var table = document.all ? document.all[tableID]:document.getElementById(tableID);
         return (table.rows.length-1) ; /* restandole la cabecera de detalle */
      }

      function SelectIndicadores(objThis) {
         form = document.frmdatos;
         var subjObj = null;
         if (objThis.value == ""){
            form.hdnSign.value = "";
            return;
         };

         for (i=1; i < IndicadoresArr.length ; i++) {
               subjObj = IndicadoresArr[i];
               if (subjObj.status == objThis.value) {
                  form.hdnRejection.value= subjObj.rejection;
                  form.hdnSign.value= subjObj.sign;
               };
         };

      };

      function SelectSigEstado(objThis){
         form = document.frmdatos;
         var subjObj = null;
         var txt_workflow;
         var txt_vtype;
         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");


         if (table.rows.length > 2){
            for(i=0 ; i< (table.rows.length - 1) ; i++){
               if (form.item_imei_imei[i].value != ""){
                  alert("No puede cambiar el lugar de despacho si ya escane� alg�n SIM/IMEI");
                  form.cmbLugarAtencion.value = form.hdnLugarDespacho.value;
                  return; };
            };
         };
         else{
            if (table.rows.length == 2){
               if (form.item_imei_imei.value != ""){
                  alert("No puede cambiar el lugar de despacho si ya escane� alg�n SIM/IMEI");
                  form.cmbLugarAtencion.value = form.hdnLugarDespacho.value;
                  return; };
            }
         };

         for (i=1; i < workflowArr.length ; i++) {
            subjObj = workflowArr[i];
            if (subjObj.atentionid == objThis.value) {
               txt_workflow = subjObj.workflow;
               txt_vtype    = subjObj.vtype;
            };
         };
   

         if (form.hdnTotalPaymentOrig.value > 0 && form.hdnLugarDespachoTypeOrig.value == "Fisica" && txt_vtype == "Fisica"){
            alert("Ya existe un pago asociado al lugar de despacho actual y por lo tanto no puede ser cambiado por otra tienda");
            form.cmbLugarAtencion.value = form.hdnLugarDespacho.value;
            return;
         };


         if (form.hdnTotalPaymentOrig.value > 0 && form.hdnLugarDespachoTypeOrig.value == "Fisica" && txt_vtype == "Fulfillment"){
            alert("Ya existe un pago asociado al lugar de despacho actual y por lo tanto al grabar la orden dicho pago se marcar� para ser transferido");
       form.cmbLugarAtencion.value = form.hdnLugarDespacho.value;
       return;
         };

         if (form.hdnTotalPaymentOrig.value > 0 && form.hdnLugarDespachoTypeOrig.value == "Fulfillment" && txt_vtype == "Fisica"){
            alert("Ya existe un pago asociado al lugar de despacho actual y por lo tanto no puede ser cambiado");
            form.cmbLugarAtencion.value = form.hdnLugarDespacho.value;
            return;
         };

         if (txt_vtype =="Fisica" && form.cmbFormaPago.value == "Diferido"){
            form.cmbFormaPago.value = "";
            form.cmbLugarAtencion.value = form.hdnLugarDespacho.value;
            return;
         };

         form.hdnLugarDespachoType.value = txt_vtype;
         form.hdnWorkflowType.value= txt_workflow;

         form.hdnLugarDespacho.value = form.cmbLugarAtencion.value;
         parent.bottomFrame.location.replace("/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT_PL_PKG.PL_SELECT_SIG_ESTADO?AN_NXTYPEID="+wn_nxtypeid+"&AV_NPWORKFLOWTYPE="+txt_workflow+"&AV_NXSTATUS1="+wv_nxstatus1);
      };

      function makeWorkflow(atentionid,workflow,vtype) {
         this.atentionid   = atentionid;
         this.workflow     = workflow;
         this.vtype        = vtype;
      };

      var workflowArr = new Array();

      function makeIndicadores(status,rejection,sign) {
         this.status       = status;
         this.rejection    = rejection;
         this.sign         = sign;
      }

      var IndicadoresArr = new Array();

      function deleteOptionNS(theForm, thecmb){
         var selLength = thecmb.length;
         if (selLength>0){
            for (var j=1;j<selLength;j++){
               thecmb.options[selLength-j]=null;
            }
            history.go(0);
         }
      }

      function deleteOptionIE(theForm, thecmb){
         var selLength = thecmb.length;
         if (selLength>0){
            for (var j=1;j<selLength;j++){
               thecmb.remove(selLength - j);
            }
         }
      }

      function limpiaCampos_Combo(theCombo){
      // Reseteo lista de sites:
         var agt= navigator.userAgent.toLowerCase();
         var isExplorer = (agt.indexOf("msie") != -1);
         form = document.frmdatos;
         if (form!=null ) {
            if (theCombo=="undefined" || theCombo==null) {
               alert("Site no existe");
            }else{
               if (isExplorer == false){
                  deleteOptionNS(form,theCombo)
               }
               else {
                  deleteOptionIE(form,theCombo)
                };
             };
          };
      }


      function ChangeSalesMan(objThis){
         form = document.frmdatos;
         var txtCustomerId   = form.txtCompanyId.value;
         var txtSite         = form.txtSiteId.value;
         var txtUnknwnSiteId  = "";
         try {
            txtUnknwnSiteId  = form.hdnUnkwnSiteId.value;
         }catch (e) {
            txtUnknwnSiteId  = 0;
         }
         var txtVendedorId   = objThis.options[objThis.selectedIndex].value;  
         var txtVendedor       = objThis.options[objThis.selectedIndex].text;
         var txtIdspecialty  = form.hdnSubCategoria.value;
         var txtCustAlcanceExclusividad  = form.hdnCustAlcanceExclusividad.value;//JGALINDO
         if (form.hdnOrderCreator.value == txtVendedorId) {
            return;
         }
         if (txtVendedor != ""){
             url = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_PL_PKG.PL_CHANGE_SALESMAN?an_swcustomerid="+txtCustomerId+"&an_swsiteid="+txtSite+"&an_vendedorid="+txtVendedorId+"&av_vendedorname="+txtVendedor+"&an_swspecialtyid="+txtIdspecialty+"&an_alcExclusivity="+txtCustAlcanceExclusividad+"&an_unknwnSiteId="+txtUnknwnSiteId;
             parent.bottomFrame.location.replace(url);
         }
      }

      function SelectDealer(objThis) {
         form = document.frmdatos;

         var txtCustAlcanceExclusividad  = form.hdnCustAlcanceExclusividad.value;//JGALINDO

         var txt_vendedor = objThis.value;
         //form.txtVendedor.value = objThis.options[objThis.selectedIndex].text;
         //form.hdnVendedor.value = objThis.value;

         var txtSite       = form.txtSiteId.value;
         var txtcustomerid = form.txtCompanyId.value;

         if (txt_vendedor != ""){
            var txturl = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT_PL_PKG.PL_SELECT_DEALER?AN_IDVENDEDOR="+txt_vendedor+"&an_customerid="+txtcustomerid+"&an_siteid="+txtSite+"&an_alcExclusivity="+txtCustAlcanceExclusividad;
            parent.bottomFrame.location.replace(txturl);
         }

      }

      function ValidateSelectedSalesMan(objThis){
   form = document.frmdatos;
   var txtCustomerId   = form.txtCompanyId.value;
      var txtSite         = form.txtSiteId.value;
      var txtVendedorId   = objThis.options[objThis.selectedIndex].value;  
      var txtVendedor       = objThis.options[objThis.selectedIndex].text;
   var txtIdspecialty  = form.hdnSubCategoria.value;
   if (txtVendedor != ""){
       url = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_PL_PKG.PL_VALIDATE_SALESMAN?an_swcustomerid="+txtCustomerId+"&an_swsiteid="+txtSite+"&an_vendedorid="+txtVendedorId+"&av_vendedorname="+txtVendedor+"&an_swspecialtyid="+txtIdspecialty;
       parent.bottomFrame.location.replace(url);
   }
      }

      function getCustomerDetail2(){
         form = document.frmdatos;
         customerId = form.txtCompanyId.value;
         if (customerId==""){
            alert("Primero debe ingresar el nombre de la empresa");
            return;
         }
         url = "/portal/page/portal/nextel/CUST_DETAIL?customerId=" + customerId;
         url = "/portal/pls/portal/WEBSALES.NPSL_GENERAL_PL_PKG.WINDOW_FRAME?av_title="+escape("PORTAL NEXTEL")+"&av_url="+escape(url);
         window.open(url,"WinCustomer","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,screenX=60,top=40,left=60,screenY=40,width=850,height=600");
         return;
      }

      function ShowStatusList(){
         form = document.frmdatos;
         var txt_workflowtype = form.hdnWorkflowType.value;
         url = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT_PL_PKG.PL_STATUS_ORDER_LIST?an_pedido="+wn_nxpedidoid +"&av_estado_actual="+ wv_nxstatus1 +"&av_specialty="+ wv_nxspecialty +"&av_flagprocesoautom="+ wv_npFlagProcesoAutom +"&av_fechaprocesoautom="+ wv_npFechaProcesoAutom+"&av_representante="+"xxxx"+"&an_nxtypeid="+ wn_nxtypeid +"&av_npworkflowtype="+txt_workflowtype+"&av_nxstatus1="+ wv_nxstatus1 ;
         url = "/portal/pls/portal/WEBSALES.NPSL_GENERAL_PL_PKG.WINDOW_FRAME?av_title="+escape("Orden > Lista Estados")+"&av_url="+escape2(url);
         WinAsist = window.open(url,"WinAsist","toolbar=no,location=0,directories=no,status=yes,menubar=0,scrollbars=no,resizable=no,screenX=50,top=200,left=400,screenY=45,width=300,height=250,modal=yes");
      }


      function esHoraValida(hora){
          if (!(hora.length==5)){
             return false;
          }
          if  (!(hora.substring(2,3)==":")){
             return false;
          }
          if (!( (parseInt(hora.substring(0,2)) >= 0) && (parseInt(hora.substring(0,2)) <= 23) )){
             return false;
          }
          if (!( (parseInt(hora.substring(3,5)) >= 0) && (parseInt(hora.substring(3,5)) <= 59) )){
             return false;
          }
          return true;
      }

      function validateSave(){
         form = document.frmdatos;
         /* form.btnGrabar.disabled  = true;*/
         /* form.btnGrabarInbox.disabled  = true;         */
         if (form.flgSave.value=="1"){ return; }

         var wn_cantServ            = vItemsBorrado.size();
         var wv_item_id             = "";
         var wv_fecha_firma         = form.txtFechaHoraFirma.value.substring(0,10);
         var wv_hora_firma          = form.txtFechaHoraFirma.value.substring(11,16);
         var wv_fecha_entrega       = form.txtFechaHoraEntrega.value.substring(0,10);
         var wv_hora_entrega        = form.txtFechaHoraEntrega.value.substring(11,16);
         var wv_fecha_proceso_autom = form.txtFechaProceso.value.substring(0,10);
         var wn_decrip_long;
         
         /*Verificaci�n de la direcci�n de entrega*/
         if (form.txtDirEntrega.value.length == 0)
          { alert("Debe ingresar la direcci�n de env�o");
            form.txtDirEntrega.focus();
            return;
          }       

         /* Verificacion del campo Fecha Hora Firma */
         if (form.txtEstadoOrden.value == "TIENDA01" || form.txtEstadoOrden.value == "ADM_VENTAS" || form.txtEstadoOrden.value == "CALLCENTER FF" || form.txtEstadoOrden.value == "BACKOFFICE") {
            if (form.txtFechaHoraFirma.value == ""){
               alert("Debe ingresar la fecha y hora de firma");
               /*form.btnGrabar.disabled = false;*/
               /*form.btnGrabarInbox.disabled  = false;*/
               form.txtFechaHoraFirma.select();
               return;
            };
            /*if (!isValidDate(wv_fecha_firma) || !isValidHour(wv_hora_firma + ":00") ){*/
            if (!isValidDate(wv_fecha_firma) || !isValidHour(wv_hora_firma) ){
               /*form.btnGrabar.disabled = false;*/
               /*form.btnGrabarInbox.disabled  = false;*/
               form.txtFechaHoraFirma.select();
               return;
            };
         };


    /* Validaci�n de la Descripci�n */
    wn_decrip_long = form.txtDetalle.value.length;
    if ( wn_decrip_long > 4000) {
      alert("El campo 'Descripci�n' tiene " + wn_decrip_long +" letras y es mayor que el maximo permitido (4000). Disminuya la"+
         " cantidad de letras o guarde una parte de esta como Notas.");
      form.txtDetalle.select();
      return;
    }

         /* Verificaci�n del campo Fecha proceso Autom�tico */
         if ( wv_npFlagProcesoAutom == "0"){
            if (form.txtFechaProceso.value == ""){
               alert("Debe ingresar la fecha de proceso autom�tico");
               /*form.btnGrabar.disabled = false;*/
               /*form.btnGrabarInbox.disabled  = false;*/
               form.txtFechaProceso.select();
               return;
            };
            if (!isValidDate(wv_fecha_proceso_autom)){
               /*form.btnGrabar.disabled = false;*/
               /*form.btnGrabarInbox.disabled  = false;*/
               form.txtFechaProceso.select();
               return;
            };
         };
   
   
      /* Validamos que se seleccione un vendedor */         
   if (form.cmbVendedor.value == "" ){
      alert("Debe seleccionar un Vendedor");
      form.cmbVendedor.focus();
      /*form.btnGrabar.disabled = false;*/
      /*form.btnGrabarInbox.disabled  = false;*/
      return;
   }else{
      form.hdnVendedor.value = form.cmbVendedor.value;
      form.txtVendedor.value = form.cmbVendedor.options[form.cmbVendedor.selectedIndex].text; 
   };   

          //******************************************************//
          //**  MODIFICACION PARA BOLSA          *//
          //******************************************************//
          // Verificamos si la orden maneja bolsa y valida el ingreso de los campos
	if (wn_nprolid_pooling_bag_edit == "1" ){
          if (trBolsa.className == "show" &&  (!(wv_nxtipoproceso == "BOLSA" && wv_nxspecialty == "DESACTIVACION") )  ){
             if (form.cmbProductoBolsa.value != ""){
                if (form.txtFechaActiv.value == ""){
         	   alert("Debe indicar la Fecha Ejecuci�n de la transaci�n de Bolsa");
                   form.txtFechaActiv.focus();
                   return;
                }
                if (!isDateFieldBetweenRange(form.txtFechaActiv, 1, 30, "Activaci�n de Bolsa")){
                   return;
                };
                if (form.hdnFlagEquipPlanBolsa.value == "0"){
                   alert("La compa�ia no tiene ningun equipo en Plan Bolsa que forme parte de su plantilla.");
                };
             }
          }
	}
          //******************************************************//


         /* Verificacion del campo Fecha Hora Entrega */
         if (form.txtFechaHoraEntrega.value != ""){
            if (form.txtEstadoOrden.value == "ALMACEN_DESPACHO" || form.txtEstadoOrden.value == "ALMACEN_DELIVERY"){
               if (form.txtEstadoOrden.value=="ALMACEN_DELIVERY" && form.txtFechaHoraEntrega.value==""){
                  alert("Debe ingresar la fecha y hora de entrega");
                  /*form.btnGrabar.disabled = false;*/
                  /*form.btnGrabarInbox.disabled  = false;*/
                  form.txtFechaHoraEntrega.select();
                  return;
               };
               /*if (!isValidDate(wv_fecha_entrega) || !isValidHour(wv_hora_entrega + ":00") ){*/
               if (!isValidDate(wv_fecha_entrega) || !isValidHour(wv_hora_entrega) ){
                  /*form.btnGrabar.disabled = false;*/
                  /*form.btnGrabarInbox.disabled  = false;*/
                  form.txtFechaHoraEntrega.select();
                  return;
               };
            };
         };

         for(i=0; i<wn_cantServ; i++){
            objServicio = vItemsBorrado.elementAt(i);
            wv_item_id = wv_item_id + "|" + objServicio.item_id;
         };

         form.hdnItemBorrados.value = wv_item_id;
         fSetRejects();

         /* Verificacion para el Order Entry */
         /*
         if (form.cmbSiguienteEstado.value == "ALMACEN_INVENTARIO"){
            if (form.hdnCodBSCS.value == ""){
               url = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT_PL_PKG.PL_CODBSCS_LIST?av_ruc="+"'||wv_swruc||'"+"&av_swtipoperson="+"'||wv_swtipoperson||'"+"&av_nptipodoc="+"'||wv_nptipodoc||'";
               url = "/portal/pls/portal/WEBSALES.NPSL_GENERAL_PL_PKG.WINDOW_FRAME?av_title="+escape("Orden > Edici�n")+"&av_url="+escape2(url);
               valor_CodBSCS = window.showModalDialog(url,"C�digo BSCS", "dialogHeight:220px; dialogWidth:280px; help:no");
               if (valor_CodBSCS != undefined){
                  form.hdnCodBSCS.value = valor_CodBSCS; }
               else {
                  if (valor_CodBSCS == undefined ){
                     form.btnGrabar.disabled = false;
                     form.btnGrabarInbox.disabled  = false;
                     return; };
               }
            };
         };
         */
         /* Fin : Order Entry*/

         /* Obtenemos los valores de los ComboBox */
         form.hdnScoring.value            =   form.cmbScoring.value;
         form.hdnRepresentanteCC.value    =   form.cmbRepresentanteCC.value;
         form.hdnAnalistaCredito.value    =   form.cmbAnalistaCredito.value;
         form.hdnAutorizadoCredito.value  =   form.cmbAutorizadoCredito.value;
         form.hdnFormaPago.value          =   form.cmbFormaPago.value;
         form.hdnProductoBolsaId.value    =   form.cmbProductoBolsa.value;
         form.hdnFechaActiv.value         =   form.txtFechaActiv.value;
         form.hdnRespPagoId.value         =   form.cmbRespPago.value;

         /* Valida Datos adicionales de la orden */
         if (!validateOrdenFieldAdd("table_order_add")){
            return;
         }


         if (form.flgSave.value   == "1"){
            return;
         }

         form.flgSave.value   = "1";
         form.target="bottomFrame";
         form.action="/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT_PL_PKG.PL_AC_ORDER_EDIT_SAVE"
         form.submit();

      };



      function fGetNumberItemSig(){
         var form = document.frmdatos;
         for (var k = 0; k < wn_items; k++) {
            if (form.item_code[k].value==-1) //disponible
               return k;
         }
         return 0;
      }

      function ChangeItemDetail(item_index) {
            var form = document.frmdatos;
            if (document.frmdatos.txtNumeroGuia.value != ""){
               alert("La gu�a ya fue generada. No puede modificar el item");
               return;
            };

            var num_rows = getNumRows("table_items");

/*          if (getNumRows("table_items")>1){
               var idPromoheader    =form.hdnnpPromoHeaderId[item_index].value;
               var PromoHeaderName  =form.hdnnpPromoHeaderName[item_index].value;
            }else{
               var idPromoheader    =form.hdnnpPromoHeaderId.value;
               var PromoHeaderName  =form.hdnnpPromoHeaderName.value;
            }
            if (idPromoheader!="" && idPromoheader!=0 && idPromoheader!="0"){
               fEditPromotion(idPromoheader,PromoHeaderName,item_index);
               return ;
            }
*/

            var frameUrl = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT03_PL_PKG.PL_ORDER_ITEM_EDIT"
               +"?item_index="+ item_index
               +"&item_code="       + escape(eval("form.item_code"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_product_id="       + escape(eval("form.item_product_id"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_product_dsc="      + escape(eval("form.item_product_dsc"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_prod_line_id="     + escape(eval("form.item_prod_line_id"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_plan_id="       + escape(eval("form.item_plan_id"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_plan_dsc="      + escape(eval("form.item_plan_dsc"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_quantity="      + escape(eval("form.item_quantity"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&txtnpTelefono="      + escape(eval("form.txtnpTelefono"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&hdnnpTelefonoNuevo="       + escape(eval("form.hdnnpTelefonoNuevo"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_imei="          + escape(eval("form.item_imei"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&hdnnpImeiNuevo="     + escape(eval("form.hdnnpImeiNuevo"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_product_price="       + escape(eval("form.item_product_price"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_except_prodprice="    + escape(eval("form.item_except_prodprice"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_total="         + escape(eval("form.item_total"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_adde_period="      + escape(eval("form.item_adde_period"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_adde_type="     + escape(eval("form.item_adde_type"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_own_equip="     + escape(eval("form.item_own_equip"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_own_equip_new="       + escape(eval("form.item_own_equip_new"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&hdnnpPromoHeaderId="       + escape(eval("form.hdnnpPromoHeaderId"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&hdnnpPromoDetailId="       + escape(eval("form.hdnnpPromoDetailId"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&hdnnpOracleCode="       + escape(eval("form.hdnnpOracleCode"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&hdnnpRealImei="      + escape(eval("form.hdnnpRealImei"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&item_services="      + escape(eval("form.item_services"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&product_type="       + escape(form.hdnProductType.value)
               +"&specialtyid="     + escape(form.hdnSubCategoria.value)
               +"&customer_id_bscs="      + escape(form.hdnCodBSCS.value)
               +"&handset_allowed="       + escape(form.hdnHandSetAllowed.value)
               +"&main_object_type="      + escape(form.hdnMainObjectType.value)
               +"&product_handling="      + escape(form.hdnProductHandling.value)
               +"&rate_plan_handling="       + escape(form.hdnRatePlanHandling.value)
               +"&additional_service_allowed="  + escape(form.hdnAdditionalServiceAllowed.value)
               +"&consignment_allowed="   + escape(form.hdnConsignmentAllowed.value)
               +"&PedidoID="        + escape(form.hdnPedidoID.value)  
               +"&price_type="         + escape(form.hdnPriceType.value)
               +"&service_type="       + escape(form.hdnServiceType.value)
               +"&tipo_compa�ia="      + escape(form.txtTipoCompania.value)
               +"&additional_object_type="   + escape(form.hdnAdditionalObjectType.value)
               +"&main_object_validate="  + escape(form.hdnMainObjectValidate.value)
               +"&additional_object_valid="  + escape(form.hdnAdditionalObjectValid.value)
               +"&prod_release_id_orig="  + escape(eval("form.hdnnpprodreleaseidorig"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&prod_release_name_orig="   + escape(eval("form.hdnswnameproducto"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&plan_orig="          + escape(eval("form.hdnnpplanorig"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&plan_id_orig="       + escape(eval("form.hdnnpplanidorig"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&av_npadditionaldrivingfield="
               +"&av_called_from="              + "ORD"
               +"&hdnmodality="                 + escape(eval("form.hdnmodality"+(num_rows>1?"["+item_index+"]":"")+".value"))
               +"&hdnreplacementmode="          + escape(eval("form.hdnreplacementmode"+(num_rows>1?"["+item_index+"]":"")+".value"))
 	       +"&hdnaddendahandling="          + escape(form.hdnFlagAddenda.value);


            deleteItemEnabled   = false;
            var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
            var popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
      }

      function fSetPromotion(){
         var form = document.frmdatos;
         var mainobjecttype, pricetype, additionalobjecttype;
         mainobjecttype             = form.hdnMainObjectType.value;
         pricetype                  = form.hdnPriceType.value;
         additionalobjecttype       = form.hdnAdditionalObjectType.value;
         if (mainobjecttype=="H" && additionalobjecttype=="N" && pricetype==1){
            CellPromotion.className="show";
         }else{
            CellPromotion.className="hidden";
         }
      }

      function ChangeItemNewDetail(window_type) {
      /*

         if (window_type == "prueba_HTML_TABLAS_PORTAL"){
            var frameUrl = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT03_PL_PKG.PRUEBA_1"
            var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
            var popupWin = window.open(winUrl, "detalle","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
            return;
         };

         if (window_type == "prueba_HTML_URL"){
            var popupWin = window.open("https://lmant9ias/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT03_PL_PKG.PRUEBA_1", "detalle","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
            return;
         };

         if (window_type == "prueba_HTML_JSP"){
            var popupWin = window.open("https://lmant9ias/websales/prueba1.html", "detalle","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
            return;
         };

         if (window_type == "prueba_BLANK"){
            //var popupWin = window.open("https://lmant9ias/websales/Bottom.html", "detalle","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
            var popupWin = window.open("https://lmant9ias/websales/Bottom.html", "detalle","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
            return;
         };
      */

         if (document.frmdatos.txtNumeroGuia.value != ""){
            alert("La gu�a ya fue generada. No puede agregar un item.");
            return;
         };
         
         if (document.frmdatos.hdnAutorizSalesRq.value=="3"){
            alert("Esta orden contiene Item(s) con Excepci�n que fueron Aprobados, es por ello que no se podr� a�adir m�s Item");
            return;
         }

         //deleteItemEnabled = false;
         if (promptWindow != null ) {
            promptWindow.close();
         };
         var form = document.frmdatos;
         var frameUrl = "/portal/pls/portal/!WEBCCARE.NPAC_ORDER_EDIT03_PL_PKG.PL_ORDER_ITEM_EDIT"
                        +"?item_index=0"
                        +"&item_typeWindow=" + window_type
                        +"&item_code=-1"
                        +"&item_product_id="
                        +"&item_product_dsc="
                        +"&item_prod_line_id="
                        +"&item_plan_id="
                        +"&item_plan_dsc="
                        +"&item_quantity="
                        +"&txtnpTelefono="
                        +"&hdnnpTelefonoNuevo="
                        +"&item_imei="
                        +"&hdnnpImeiNuevo="
                        +"&item_product_price="
                        +"&item_except_prodprice="
                        +"&item_total="
                        +"&item_adde_period="
                        +"&item_adde_type="
                        +"&item_own_equip="
                        +"&item_own_equip_new="
                        +"&hdnnpPromoHeaderId="
                        +"&hdnnpPromoDetailId="
                        +"&hdnnpOracleCode="
                        +"&hdnnpRealImei="
                        +"&item_services="
                        +"&product_type="                + escape(form.hdnProductType.value)
                        +"&specialtyid="                 + escape(form.hdnSubCategoria.value)
                        +"&customer_id_bscs="            + escape(form.hdnCodBSCS.value)
                        +"&handset_allowed="             + escape(form.hdnHandSetAllowed.value)
                        +"&main_object_type="            + escape(form.hdnMainObjectType.value)
                        +"&product_handling="            + escape(form.hdnProductHandling.value)
                        +"&rate_plan_handling="          + escape(form.hdnRatePlanHandling.value)
                        +"&additional_service_allowed="  + escape(form.hdnAdditionalServiceAllowed.value)
                        +"&consignment_allowed="         + escape(form.hdnConsignmentAllowed.value)
                        +"&price_type="                  + escape(form.hdnPriceType.value)
                        +"&service_type="                + escape(form.hdnServiceType.value)
                        +"&tipo_compa�ia="               + escape(form.txtTipoCompania.value)
                        +"&additional_object_type="      + escape(form.hdnAdditionalObjectType.value)
                        +"&main_object_validate="        + escape(form.hdnMainObjectValidate.value)
                        +"&additional_object_valid="     + escape(form.hdnAdditionalObjectValid.value)
                        +"&prod_release_id_orig="
                        +"&prod_release_name_orig="
                        +"&plan_orig="
                        +"&plan_id_orig="
                   +"&av_npadditionaldrivingfield="
                        +"&av_called_from="              + "ORD"
                        +"&hdnmodality="
                        +"&hdnreplacementmode="
 	                +"&hdnaddendahandling="          + escape(form.hdnFlagAddenda.value);

         var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
         var popupWin = window.open(winUrl, "Orden_Item","status=yes, location=0, width=450, height=500, left=300, top=30, screenX=50, screenY=100");
      }


      // Javascript para Recibos:
      function editPayment() {
         var form = document.frmdatos;
         var frameUrl = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT02_PL_PKG.PL_ORDER_PAYMENT_EDIT"
                        +"?hdnPagoBanco="          + escape(form.hdnPagoBanco.value)
                        +"&hdnPagoNroVoucher="     + escape(form.hdnPagoNroVoucher.value)
                        +"&hdnPagoImporte="        + escape(form.hdnPagoImporte.value)
                        +"&hdnPagoFecha="          + escape(form.hdnPagoFecha.value)
                        +"&hdnPagoDisponible="     + escape(form.hdnPagoDisponible.value)
                        +"&hdnRuc="                + escape(form.txtRucDisabled.value)
                        +"&txtImporteFactura="     + escape(form.txtImporteFactura.value)
                        +"&hdnTotalPaymentOrig="   + escape(form.hdnTotalPaymentOrig.value);
         var winUrl = "/portal/pls/portal/WEBSALES.NPSL_NEW_GENERAL_PL_PKG.PL_FRAME?av_url="+escape(frameUrl);
         var popupWin = window.open(winUrl, "Orden_Pagos","status=yes, location=0, width=450, height=500, left=50, top=100, screenX=50, screenY=100");
      }


      function CheckDate(obj) {
         var wv_datestr = obj.value;
         var wv_hoy_str = new Date();
         var day_act    = parseFloat(wv_hoy_str.getDate());
         var month_act  = parseFloat(wv_hoy_str.getMonth()+1);
         var year_act   = parseFloat(wv_hoy_str.getYear());

         var wv_message = "La fecha debe ser mayor o igual a la fecha actual";

         if ( wv_datestr != "" ){
            if ( !isValidDate(wv_datestr)){
               obj.select();
               return;
            };

            var day_new    = parseFloat(wv_datestr.substring(0,2));
            var month_new  = parseFloat(wv_datestr.substring(3,5));
            var year_new   = parseFloat(wv_datestr.substring(6,10));
            if (year_new < year_act){
               alert(wv_message);
               obj.select();
               return;
            };
            if (year_new == year_act){
               if (month_new < month_act){
                  alert(wv_message);
                  obj.select();
                  return;
               };
               if (month_new == month_act){
                  if (day_new < day_act){
                     alert(wv_message);
                     obj.select();
                     return;
                  };
               }
            }
         }
         return true;
      };

      function fGenerarComprobantes(){
         var form = document.frmdatos;
         var wn_lugardespacho = form.cmbLugarAtencion.value;
         var wv_tipodespacho;
         form.btnGenerarComprobantes.disabled = true;
        /* form.btnGrabar.disabled  = true;*/
        /* form.btnGrabarInbox.disabled  = true;*/
         for (i=1; i < workflowArr.length ; i++) {
            subjObj = workflowArr[i];
            if (subjObj.atentionid == wn_lugardespacho) {
               wv_tipodespacho = subjObj.vtype;
            };
         };
         a = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT_PL_PKG.PL_DOCUMENT_GENERATION?an_pedidoid="+wn_nxpedidoid+"&an_lugardespacho="+wn_lugardespacho+"&av_tipodespacho="+wv_tipodespacho;
         parent.bottomFrame.location.replace(a);
      };

      function fMuestraHelpFechaHora(){
         alert("Ejemplo de formato Fecha Hora Firma: 14/07/2004 16:05");
      };

      function fCopyCodBSCS(){
         var form = document.frmdatos;
         if (form.cmbCodBSCS.value != ""){
            var txt_CodBSCS = form.cmbCodBSCS.options[form.cmbCodBSCS.selectedIndex].text;
            window.clipboardData.setData("Text",txt_CodBSCS);
            return;
         };
      };

      function SelectCodBSCS(objThis){
         document.frmdatos.hdnCodBSCS.value = objThis.value;
      };

      function fVerifModifDirEntrega(flag){ /* el flag nos indica en que momento se esta realizando la verificacion, 1: al cargar la pagina, 2: cuando se vuelve a la direccion orig. */
         if (flag == 1){ /* si se llama al cargar la p�gina, se verifica los valores q trae el SP de la BD */
            if (trim(wv_entregaDir.toUpperCase()) != trim(wv_npdirentrega.toUpperCase())){
               document.frmdatos.txtDirEntregaMensaje.className = "show"; }
         }
         if (flag == 2){ /* se verifica en caso se modifique el campo de direcci�n */
            if (trim(document.frmdatos.txtDirEntrega.value.toUpperCase()) == trim(wv_entregaDir.toUpperCase())){
               document.frmdatos.txtDirEntregaMensaje.className = "hidden"; };
            else {
               document.frmdatos.txtDirEntregaMensaje.className = "show"; }
         };
      };

      function fCopyVendedor(){
         var form = document.frmdatos;
         if (form.cmbVendedor.value != ""){
            var txt_Vendedor = form.cmbVendedor.options[form.cmbVendedor.selectedIndex].text;
            window.clipboardData.setData("Text",txt_Vendedor);
            return;
         };
      };

      function fValidarFormaPago(objThis){
         var form = document.frmdatos;
         var forma_pago = objThis.value;
         if (forma_pago != ""){
            var tipo_LugarDespacho = fGetTypeDespacho(form.cmbLugarAtencion.value);
            if (forma_pago == "Diferido" && tipo_LugarDespacho != "Fulfillment" && form.cmbLugarAtencion.value != ""){
               form.cmbFormaPago.value = "";
               alert("Esta forma de pago no esta disponible para Tienda");
               return;
            };

            if (forma_pago == "Descuento por Planilla" && wv_swtype != "Employee"){
               form.cmbFormaPago.value = ""; /* form.hdnFormaPagoOrig.value; */
               alert("Esta forma de pago s�lo es disponible para empleados");
               return;
            };
         };
         form.hdnFormaPagoOrig.value = form.cmbFormaPago.value;
      };

      function fGetTypeDespacho(lugar_despacho){
         for (i=1; i < workflowArr.length ; i++) {
            subjObj = workflowArr[i];
            if (subjObj.atentionid == lugar_despacho) {
               return subjObj.vtype;
            };
         };
      };

      function fDeshabilitaBotonesImeis(){
         form = document.frmdatos;
         if (form.txtNumeroGuia.value != ""){
            form.btnBorrar.disabled       = "true";
            form.btnBadImei.disabled      = "true";
            form.btnCheckAll.disabled     = "true";
            //form.btnListaImeis.disabled   = "true";
            form.btnUncheckOne.disabled   = "true";
         };
      };

      /*  Determina cual es el item del IMEI con el que se va a trabajar  */
      function SeteaItemIndex(objThis){
         var oindexRow = objThis.parentNode.parentNode.rowIndex;
         form.hdn_item_imei_selecc.value = oindexRow -1;
      }

      function fValidaSimImeiRepetido(sim_imei_new){
         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
         for(i=0 ; i< (table.rows.length - 1) ; i++){
            if (form.item_imei_imei[i].value != "" && form.item_imei_imei[i].value == sim_imei_new){
               alert("SIM/IMEI ya esta registrado, verifique");
               form.txtImeis.focus();
               return true;
            };
         };
         return false;
      };

      function LastKeyDown(){
         glastKey=window.event.keyCode;
      };

      function AddImei(objThis){
         if (document.frmdatos.txtNumeroGuia.value != ""){
            alert("La gu�a ya fue generada. No puede adicionar un SIM/IMEI.");
            form.txtImeis.select();
            return;
         };

         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
         var row_activo = false;
         var item_index;

         if (objThis.value == ""){
            return;
         };

         if (table.rows.length < 2){
            alert("No se puede realizar la acci�n");
            form.txtImeis.select();
            return;
         };

         if (table.rows.length == 2){
            if (form.item_imei_imei.value=="")
               row_activo = true;
         }
         else{
            if (table.rows.length > 2){
               if (fValidaSimImeiRepetido(objThis.value)){
                  form.txtImeis.select();
                  return; }

               for (m=0; m<(table.rows.length - 1); m++){
                  if (form.item_imei_imei[m].value==""){
                     row_activo = true;
                     break; }
               }
            }
         }

         if (!row_activo){
            alert("No se puede registrar el SIM/IMEI");
            form.txtImeis.select();
            return;}

         if (objThis.value.length != 15 || !ContentOnlyNumber(objThis.value) ) {
            alert("N�mero de SIM/IMEI no valido");
            form.txtImeis.select();
            return; };
         if (form.hdn_item_imei_selecc.value == ""){
            alert("Seleccione un Item de SIM/IMEI");
            form.txtImeis.select();
            return; }

         if (row_activo){
            if (objThis.value!=""){
               if (table.rows.length == 2){
                  if (form.item_imei_imei.value == ""){
                     form.item_imei_imei.value = objThis.value;
                     grid_region.scrollTop=table_imeis.childNodes.item(0).childNodes.item(1).childNodes.item(0).offsetTop;
                  }else {
                     alert("El campo seleccionado ya esta registrado");
                     form.txtImeis.select();
                     return false; };
               }
               else {
                  if (form.item_imei_imei[form.hdn_item_imei_selecc.value].value == ""){
                     form.item_imei_imei[form.hdn_item_imei_selecc.value].value = objThis.value;
                     grid_region.scrollTop=table_imeis.childNodes.item(0).childNodes.item(form.hdn_item_imei_selecc.value).childNodes.item(0).offsetTop;
                  }else{
                     alert("El campo seleccionado ya esta registrado");
                     form.txtImeis.select();
                     return false; };
               };
               objThis.value = "";
               if (table.rows.length==2){
                  if (form.item_imei_imei.value==""){
                     form.item_imei_radio.checked = true;
                     form.hdn_item_imei_selecc.value = 0; }
               }
               else{
                  if (table.rows.length > 2){
                     for (m=0; m<(table.rows.length - 1); m++){
                        if (form.item_imei_imei[m].value==""){
                           form.item_imei_radio[m].checked = true;
                           form.hdn_item_imei_selecc.value = m;
                           break; }
                     }
                  }
               }
               form.hdnFlagItemImeis.value = "1";
               form.txtImeis.select();
            };
         };
         
         form.txtImeis.focus();
         form.txtImeis.select();    
      };

      function ImeiBorra(){
         if (document.frmdatos.txtNumeroGuia.value != ""){
            alert("La gu�a ya fue generada. No puede borrar el SIM/IMEI.");
            return;
         };

         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
         if (table.rows.length < 2){
            alert("No se puede realizar la acci�n");
            return; };

         if (table.rows.length > 2 && form.item_imei_imei[form.hdn_item_imei_selecc.value].value ==""){
            alert("No se puede realizar la acci�n, SIM/IMEI vacio");
            return; };

         if (table.rows.length == 2 && form.item_imei_imei.value ==""){
            alert("No se puede realizar la acci�n, SIM/IMEI vacio");
            return false; };

         if (confirm("Desea borrar el IMEI de este item?")){
            if (form.hdn_item_imei_selecc.value == ""){
               alert("Seleccione un item");}
            else{
               try{
                  parent.mainFrame.document.frmdatos.hdnChangedOrder.value="S";
               }catch(e){;}
               if (table.rows.length > 2){
                  form.item_imei_imei[form.hdn_item_imei_selecc.value].value = "";
                  form.item_imei_check[form.hdn_item_imei_selecc.value].value = "N"; }
               else{
                  form.item_imei_imei.value = "";
                  form.item_imei_check.value = "N"; }
            }
         }

         form.hdnFlagItemImeis.value = "1";
      };

      /*
        JPEREZ: 19/06/08
        Se modifica por cambio en espicificaciones: Ya no ser� Bad IMEI sino Bad SIM
        (el SIM es el que se marca como defectuoso)        
      */
      function ImeiBadImei(){
         /*if (document.frmdatos.txtNumeroGuia.value != ""){
            alert("La gu�a ya fue generada. No puede hacer bad SIM/IMEI.");
            return;
         };*/

         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");

         if (table.rows.length < 2){
            alert("No se puede realizar la acci�n");
            return;
         };

         if ( table.rows.length > 2 ){
            if (form.item_imei_sim[form.hdn_item_imei_selecc.value].value ==""){
               alert("No se puede realizar la acci�n, SIM/IMEI vacio");
               return; }
            else {
               form.item_imei_bad[form.hdn_item_imei_selecc.value].value = form.item_imei_sim[form.hdn_item_imei_selecc.value].value ;
               form.item_imei_sim[form.hdn_item_imei_selecc.value].value = "";  }
         }
         else {
            if (form.item_imei_sim.value == ""){
               alert("No se puede realizar la acci�n, SIM/IMEI vacio");
               return false;  }
            else {
               form.item_imei_bad.value = form.item_imei_sim.value ;
               form.item_imei_sim.value = ""; }
         }
         form.hdnFlagItemImeis.value = "1";
         try{
          parent.mainFrame.document.frmdatos.hdnChangedOrder.value="S";
         }catch(e){;}
      };

      function ImeiCkeckAll(){
         /*if (document.frmdatos.txtNumeroGuia.value != ""){
            alert("La gu�a ya fue generada. No puede hacer check all de los SIM/IMEIs.");
            return;
         };*/
        var vForm = parent.mainFrame.document.frmdatos;
         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
         if (table.rows.length < 2){
            alert("No se puede realizar la acci�n");
            return;
         };

         if (table.rows.length > 2){
            for(i=0; i<(table.rows.length - 1); i++){
               form.item_imei_check[i].value = "S"; }
         }
         else{
            form.item_imei_check.value = "S";   }

         form.hdnFlagItemImeis.value = "1";
         
         try{
          vForm.hdnChangedOrder.value="S";
         }catch(e){;}
      };

      function ImeiUncheckOne(){
         /*if (document.frmdatos.txtNumeroGuia.value != ""){
            alert("La gu�a ya fue generada. No puede hacer uncheck al SIM/IMEI.");
            return;
         };*/
         var vForm = parent.mainFrame.document.frmdatos;
         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
         if (table.rows.length < 2){
            alert("No se puede realizar la acci�n");
            return;
         };

         if (table.rows.length > 2){
            form.item_imei_check[form.hdn_item_imei_selecc.value].value = "N"; }
         else {
            form.item_imei_check.value = "N"; }
         form.hdnFlagItemImeis.value = "1";
         
         try{
            vForm.hdnChangedOrder.value="S";
         }catch(e){;}
      };

      function ImeiListaImies() {
         table2 = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
         table = document.all ? document.all["tableImeisAux"]:document.getElementById("tableImeisAux");
         var elmTBODY = document.getElementById("CuerpoTabla");
         var elmTR;
         var elmTD;
         var elmText;
         var j=0;
		 var imei=""; //CEM

         if (table2.rows.length < 2){			
            alert("No se puede realizar la acci�n");
            return;
         };

         if (document.all) {
            if (table2.rows.length > 2){				
               for(i=0 ; i< (table2.rows.length - 1) ; i++){
                  if (form.item_imei_imei[i].value != ""){
                     var row = table.insertRow(-1);
                     var cell = row.insertCell(j);
                     elmText = form.item_imei_imei[i].value;
					 imei=imei+form.item_imei_imei[i].value+"\n"; //CEM					 
                     cell.innerHTML = elmText;
                  };
               };
            };
            else {
               if (table2.rows.length == 2){			      
                  if (form.item_imei_imei.value != ""){
                     var row = table.insertRow(-1);
                     var cell = row.insertCell(j);
                     elmText = form.item_imei_imei.value;
					 imei=imei+form.item_imei_imei.value+"\n"; //CEM
                     cell.innerHTML = elmText;
                  };
               };
            };
         }

         event.returnValue = false;
         //window.clipboardData.setData("Text",divDataImeis.innerHTML);
		 window.clipboardData.setData("Text",imei); //CEM		 
         alert("Data copiada exit�samente!");		 
         /* Limpiamos la tabla aux */
         var longuitud = table.rows.length - 1;
         for(i= longuitud ; i>=0 ; i--){
            table.deleteRow(i);
         };
         return;
         
      }




function SetExceptionBasicRent() {         
   var vform    = document.frmdatos;
   if (getNumRows("table_items")==0) {
      alert("Agregue al menos un item a la orden.");
      return false;
   }
   var popupWin = window.open("about:blank", "sc_exception","status=yes,scrollbars=yes,resizable=yes,location=0,width=900, height=500, left=50, top=100,screenX=50,screenY=100");            
   vform.action ="/portal/pls/portal/!WEBSALES.NPSL_ORDER_ITEM_PL_PKG.PL_ITEM_EXCEPTION_EDIT"
   vform.target ="sc_exception"
   vform.submit();
}

/*Consultar la informaci�n de excepci�n por renta.*/
function GetExceptionBasicRent(pedidoid) {
   var url = "/portal/pls/portal/!WEBSALES.NPSL_ORDER_ITEM01_PL_PKG.PL_ITEM_EXCEPTION_DETAIL?wn_pedidoid=" + pedidoid;
   var popupWin = window.open(url, "sc_exception","status=yes,scrollbars=yes,resizable=yes,location=0,width=900, height=500, left=50, top=100,screenX=50,screenY=100");
}

/* Permite limpiar las excepciones de un Item especifico */
function clearException(item){
   var form = document.frmdatos;
   if (wn_items==1){
      /* CAMPO DE EXCEPCIONES - Renta Basica */
      form.item_excepBasicRentDesc.value="";
      form.item_excepBasicRentException.value="";
      /* CAMPO DE EXCEPCIONES - Renta de Alquiler */
      form.item_excepRentDesc.value="";
      form.item_excepRentException.value="";
      /* CAMPO DE EXCEPCIONES - Servicios Gratis */
      form.item_excepServiceId.value="";
      form.item_excepServiceDiscount.value="";
      /* CAMPO DE EXCEPCIONES - Minutos Adicionales */
      form.item_excepMinAddConexDirecChecked.value="";
      form.item_excepMinAddInterConexChecked.value="";
   }else{
      /* CAMPO DE EXCEPCIONES - Renta Basica */
      form.item_excepBasicRentDesc[item].value="";
      form.item_excepBasicRentException[item].value="";
      /* CAMPO DE EXCEPCIONES - Renta de Alquiler */
      form.item_excepRentDesc[item].value="";
      form.item_excepRentException[item].value="";
      /* CAMPO DE EXCEPCIONES - Servicios Gratis */
      form.item_excepServiceId[item].value="";
      form.item_excepServiceDiscount[item].value="";
      /* CAMPO DE EXCEPCIONES - Minutos Adicionales */
      form.item_excepMinAddConexDirecChecked[item].value="";
      form.item_excepMinAddInterConexChecked[item].value="";
   }
}

/*inicio corrigiendo items device borrados*/
function fxIndiceItemDevice(){
   vForm = document.frmdatos;
   var hdnIndice_imei = vForm.hdnIndice_imei;
   var hdnIndice = vForm.hdnIndice;
   var hdnModality = vForm.hdnItemValuetxtItemModality;
   var idDevice = 0;
   var idDeviceEvaluado = 0;
   var specificationId = "<%=strCategoryId%>";
   if(specificationId=="null"){
     specificationId = vForm.cmbSubCategoria.value;
   }
    if(specificationId==2001 || specificationId==2009 || specificationId==2010 || specificationId==2018 || specificationId==2002){
     //bloque para agrupar los items device
     if(hdnIndice_imei!=null){
       if(hdnIndice_imei.length==undefined){
         idDevice = hdnIndice_imei.value;
       }else{
         for(i=0; i<hdnIndice_imei.length; i++) {
           if(idDeviceEvaluado!=hdnIndice_imei[i].value){         
             if(i==0){
               idDevice = hdnIndice_imei[i].value;
             }else{
               idDevice = idDevice+"_"+hdnIndice_imei[i].value;
             }
             idDeviceEvaluado = hdnIndice_imei[i].value;
           }    
         }
       }
     }
     //bloque para actualizar los ids de los items
     if(hdnIndice!=null){
       if(hdnIndice.length==undefined){
         hdnIndice.value = idDevice;
       }else{
         var cont = 0;
         for(i=0; i<hdnIndice.length; i++) {
           if((hdnModality[i].value=="Propio") || (hdnModality[i].value=="Alquiler en Cliente")){
             hdnIndice[i].value = 0;
           }else{
             hdnIndice[i].value = idDevice.split("_")[cont];
             cont++;
           }
         }
       }
     }      
   }
 }
 /*fin corrigiendo items device borrados*/
