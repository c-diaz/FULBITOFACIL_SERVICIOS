/* Permite mostrar y ocultar el boton de Excepciones */
function fxShowException(bShow){
   if (bShow){
      divException.className="show";
   }else{
      divException.className="hidden";
   }
}


/* Permite levantar una pantalla para ingresar la excepci�n */
   function fxSetException(strSessionId, strSpecid) {      
      if (deleteItemEnabled){
         var vform = document.frmdatos;
         var numRows = getNumRows("items_table");
         var prefix  = "hdnItemValue";
         if (numRows==0) {
            alert("Agregue al menos un item a la orden.");
            return false;
         }                
         var urlPage = "?";
         if(vform.txtCompanyId != null)urlPage = urlPage + "strCustomerId=" + vform.txtCompanyId.value + "&"; 
         if(vform.hdnNumeroOrder != null)urlPage = urlPage + "strOrderId=" + vform.hdnNumeroOrder.value + "&";         
         urlPage = urlPage + "strFrom=" + "ORD" + "&";
         urlPage = urlPage + "strSpecId=" + strSpecid + "&";  
         urlPage = urlPage + "strSessionId=" + strSessionId + "&";         
         urlPage = urlPage + "strAction=" + "NEW" + "&";         
         //if(vform.cmbSolucion != null)urlPage = urlPage + "strSolutionId="   + vform.cmbSolucion.options[form.cmbSolucion.selectedIndex].value + "&"; //Soluci�n id
         if(vform.cmbDivision != null)urlPage = urlPage + "strDivisionId="   + vform.cmbDivision.options[form.cmbDivision.selectedIndex].value + "&"; //Divisi�n id
         if(vform.cmbCategoria != null)urlPage = urlPage + "strCategory="     + vform.cmbCategoria.options[form.cmbCategoria.selectedIndex].text + "&"; //CAtegor�a
         if(vform.hdnPeriodoIni != null)urlPage = urlPage + "strBeginPeriod='" + (vform.hdnPeriodoIni.value=="null"?"":vform.hdnPeriodoIni.value) + "&"; //Periodos de inicio
         if(vform.hdnPeriodoFin != null)urlPage = urlPage + "strEndPeriod='" + (vform.hdnPeriodoFin.value=="null"?"":vform.hdnPeriodoFin.value) + "&"; //Periodos de inicio
               
         if (numRows>1){
            for (var i=0; i<numRows; i++){
               if(vform.txtItemProduct[i] != null)urlPage = urlPage + "pstrItemDesc=" + vform.txtItemProduct[i].value + "&"; //revisar campo
               if(vform.hdnItemValuetxtItemProduct[i] != null)urlPage = urlPage + "pstrItemId=" + vform.hdnItemValuetxtItemProduct[i].value + "&"; //revisar campo        
               if(vform.txtItemQuantity[i] != null)urlPage = urlPage + "pstrItemQty=" + vform.txtItemQuantity[i].value + "&";    
               if(vform.hdnItemValuetxtItemRatePlan[i] != null)urlPage = urlPage + "pstrItemPlanId=" + vform.hdnItemValuetxtItemRatePlan[i].value + "&"; //revisar campo                    
               if(vform.txtItemRatePlan[i] != null)urlPage = urlPage + "pstrItemPlanDesc=" + vform.txtItemRatePlan[i].value + "&"; //revisar campo   
               if(vform.txtItemModality[i] != null)urlPage = urlPage + "pstrItemSaleModality=" + vform.txtItemModality[i].value + "&"; //modalidad de salida                                  
               if(vform.item_services[i] != null)urlPage = urlPage + "pstrItemServIds=" + (vform.item_services[i].value=="null"?"":vform.item_services[i].value) + "&"; //servicios adicionales
               if(vform.hdnItemValuetxtItemModality[i] != null)urlPage = urlPage + "pstrItemSaleModality=" + vform.hdnItemValuetxtItemModality[i].value + "&"; 
               //Falta strPerformFlagPeriod
               //Si es que la orden ya tiene excepciones
               if(vform.txtItemExceptionRent[i] != null)urlPage = urlPage + "pstrItemRentExc=" + vform.txtItemExceptionRent[i].value + "&"; //excepci�n alquiler
               if(vform.txtItemExceptionRevenue[i] != null)urlPage = urlPage + "pstrItemRevenueExc=" + vform.txtItemExceptionRevenue[i].value + "&"; //excepci�n renta
               if(vform.txtItemExceptionServiceId[i] != null)urlPage = urlPage + "pstrItemExcServiceId=" + vform.txtItemExceptionServiceId[i].value + "&"; //servicios con excepci�n
               if(vform.txtItemExceptionServiceDisc[i] != null)urlPage = urlPage + "pstrItemExcServiceDiscnt=" + vform.txtItemExceptionServiceDisc[i].value + "&"; //descuento en servicios con excepci�n   
               if(vform.txtItemExceptionMinAdiCD[i] != null)urlPage = urlPage + "pstrItemMinAdiCD=" + vform.txtItemExceptionMinAdiCD[i].value + "&"; //Minutos adicionales CD
               if(vform.txtItemExceptionMinAdiIT[i] != null)urlPage = urlPage + "pstrItemMinAdiIT=" + vform.txtItemExceptionMinAdiIT[i].value + "&"; //Minutos adicionales Telefon�a               
            }
         }else{            
            if(vform.txtItemProduct != null)urlPage = urlPage + "pstrItemDesc=" + vform.txtItemProduct.value + "&";
            if(vform.hdnItemValuetxtItemProduct != null)urlPage = urlPage + "pstrItemId=" + vform.hdnItemValuetxtItemProduct.value + "&";        
            if(vform.txtItemQuantity != null)urlPage = urlPage + "pstrItemQty=" + vform.txtItemQuantity.value + "&";    
            if(vform.hdnItemValuetxtItemRatePlan != null)urlPage = urlPage + "pstrItemPlanId=" + vform.hdnItemValuetxtItemRatePlan.value + "&";                    
            if(vform.txtItemRatePlan != null)urlPage = urlPage + "pstrItemPlanDesc=" + vform.txtItemRatePlan.value + "&";   
            if(vform.txtItemModality != null)urlPage = urlPage + "pstrItemSaleModality=" + vform.txtItemModality.value + "&";                 
            if(vform.item_services != null)urlPage = urlPage + "pstrItemServIds=" + (vform.item_services.value=="null"?"":vform.item_services.value) + "&";
            if(vform.hdnItemValuetxtItemModality != null)urlPage = urlPage + "pstrItemSaleModality=" + vform.hdnItemValuetxtItemModality.value + "&";   
                
            //Falta strPerformFlagPeriod
            //Si es que la orden ya tiene excepciones
            if(vform.txtItemExceptionRent != null)urlPage = urlPage + "pstrItemRentExc=" + vform.txtItemExceptionRent.value + "&"; //excepci�n alquiler
            if(vform.txtItemExceptionRevenue != null)urlPage = urlPage + "pstrItemRevenueExc=" + vform.txtItemExceptionRevenue.value + "&"; //excepci�n renta    
            if(vform.txtItemExceptionServiceId != null)urlPage = urlPage + "pstrItemExcServiceId=" + vform.txtItemExceptionServiceId.value + "&"; //servicios con excepci�n    
            if(vform.txtItemExceptionServiceDisc != null)urlPage = urlPage + "pstrItemExcServiceDiscnt=" + vform.txtItemExceptionServiceDisc.value + "&"; //descuento en servicios con excepci�n       
            if(vform.txtItemExceptionMinAdiCD != null)urlPage = urlPage + "pstrItemMinAdiCD=" + vform.txtItemExceptionMinAdiCD.value + "&"; //Minutos adicionales CD    
            if(vform.txtItemExceptionMinAdiIT != null)urlPage = urlPage + "pstrItemMinAdiIT=" + vform.txtItemExceptionMinAdiIT.value + "&"; //Minutos adicionales Telefon�a                                              
         }     
         var frameUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpException.jsp"+urlPage+"type_window=NEW";               
         var winUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpExceptionFrame.jsp?av_url="+escape(frameUrl);
         var popupWin = window.open(winUrl, "Orden_Exception","status=yes, location=0, width=900, height=500, left=50, top=100, screenX=50, screenY=100");
         
      } else
         alert("No puede agregar, cierre antes la ventana de edici�n de Items");
   }


/* Permite limpiar las excepciones de un Item especifico */
function clearException(item){
   var form = document.frmdatos;
   if (wn_items==1){
      /* CAMPO DE EXCEPCIONES - Renta Basica */
      form.item_excepBasicRentDesc.value="";
      form.item_excepBasicRentException.value="";
      /* CAMPO DE EXCEPCIONES - Renta de Alquiler */
      form.item_excepRentDesc.value="";
      form.item_excepRentException.value="";
      /* CAMPO DE EXCEPCIONES - Servicios Gratis */
      form.item_excepServiceId.value="";
      form.item_excepServiceDiscount.value="";
      /* CAMPO DE EXCEPCIONES - Minutos Adicionales */
      form.item_excepMinAddConexDirecChecked.value="";
      form.item_excepMinAddInterConexChecked.value="";
   }else{
      /* CAMPO DE EXCEPCIONES - Renta Basica */
      form.item_excepBasicRentDesc[item].value="";
      form.item_excepBasicRentException[item].value="";
      /* CAMPO DE EXCEPCIONES - Renta de Alquiler */
      form.item_excepRentDesc[item].value="";
      form.item_excepRentException[item].value="";
      /* CAMPO DE EXCEPCIONES - Servicios Gratis */
      form.item_excepServiceId[item].value="";
      form.item_excepServiceDiscount[item].value="";
      /* CAMPO DE EXCEPCIONES - Minutos Adicionales */
      form.item_excepMinAddConexDirecChecked[item].value="";
      form.item_excepMinAddInterConexChecked[item].value="";
   }
}   
   
/* Permite levantar una pantalla para editar la excepci�n */
   function fxEditException(strSessionId, strAction, strSpecid) {           
      if (deleteItemEnabled){
         var vform = document.frmdatos;
         var numRows = getNumRows("items_table");
         var prefix  = "hdnItemValue";
         if (numRows==0) {
            alert("Agregue al menos un item a la orden.");
            return false;
         }            
         var urlPage = "?";
         if(vform.txtCompanyId != null)urlPage = urlPage + "strCustomerId=" + vform.txtCompanyId.value + "&"; 
         if(vform.hdnNumeroOrder != null)urlPage = urlPage + "strOrderId=" + vform.hdnNumeroOrder.value + "&";         
         urlPage = urlPage + "strFrom=" + "ORD" + "&";
         urlPage = urlPage + "strSpecId=" + strSpecid + "&";  
         urlPage = urlPage + "strSessionId=" + strSessionId + "&"; 
         urlPage = urlPage + "strAction=" + strAction + "&";         
         //if(vform.solution_id != null)urlPage = urlPage + "strSolutionId="   + vform.solution_id.value + "&"; //Soluci�n id
         if(vform.hdnDivisionId != null)urlPage = urlPage + "strDivisionId="   + vform.hdnDivisionId.value + "&"; //Division id
         if(vform.txtCategoria != null)urlPage = urlPage + "strCategory="     + vform.txtCategoria.value + "&"; //CAtegor�a                             
         if(vform.hdnPeriodoIni != null)urlPage = urlPage + "strBeginPeriod='"      + (vform.hdnPeriodoIni.value=="null"?"":vform.hdnPeriodoIni.value) + "&"; //Periodos de inicio
         if(vform.hdnPeriodoFin != null)urlPage = urlPage + "strEndPeriod='"        + (vform.hdnPeriodoFin.value=="null"?"":vform.hdnPeriodoFin.value) + "&"; //Periodos de inicio
         if (numRows>1){
            for (var i=0; i<numRows; i++){                      
               if(vform.hdnItemValuetxtItemProduct[i] != null)urlPage = urlPage + "pstrItemId="           + (vform.hdnItemValuetxtItemProduct[i].value=="null"?"":vform.hdnItemValuetxtItemProduct[i].value) + "&"; //revisar campo
               if(vform.txtItemProduct[i] != null)urlPage = urlPage + "pstrItemDesc="         + (vform.txtItemProduct[i].value=="null"?"":vform.txtItemProduct[i].value) + "&"; //revisar campo
               if(vform.txtItemQuantity[i] != null)urlPage = urlPage + "pstrItemQty="          + vform.txtItemQuantity[i].value + "&";
               if(vform.hdnItemValuetxtItemRatePlan[i] != null)urlPage = urlPage + "pstrItemPlanId="       +fxRound(vform.hdnItemValuetxtItemRatePlan[i].value,0) + "&"; //revisar campo
               if(vform.txtItemRatePlan[i] != null)urlPage = urlPage + "pstrItemPlanDesc="     + vform.txtItemRatePlan[i].value + "&"; //revisar campo
               if(vform.txtItemModality[i] != null)urlPage = urlPage + "pstrItemSaleModality=" + vform.txtItemModality[i].value + "&"; //modalidad de salida               
               if(vform.item_services[i] != null)urlPage = urlPage + "pstrItemServIds="      + (vform.item_services[i].value=="null"?"":vform.item_services[i].value) + "&"; //servicios adicionales
               if(vform.hdnItemValuetxtItemModality[i] != null)urlPage = urlPage + "pstrItemSaleModality=" + vform.hdnItemValuetxtItemModality[i].value + "&"; 
               //Falta strPerformFlagPeriod
               //Si es que la orden ya tiene excepciones
               if(vform.txtItemExceptionRent[i] != null)urlPage = urlPage + "pstrItemRentExc="          + vform.txtItemExceptionRent[i].value + "&"; //excepci�n alquiler
               if(vform.txtItemExceptionRevenue[i] != null)urlPage = urlPage + "pstrItemRevenueExc="       + vform.txtItemExceptionRevenue[i].value + "&"; //excepci�n renta
               if(vform.txtItemExceptionServiceId[i] != null)urlPage = urlPage + "pstrItemExcServiceId="     + (vform.txtItemExceptionServiceId[i].value=="null"?"":vform.txtItemExceptionServiceId[i].value) + "&"; //servicios con excepci�n
               if(vform.txtItemExceptionServiceDisc[i] != null)urlPage = urlPage + "pstrItemExcServiceDiscnt=" + (vform.txtItemExceptionServiceDisc[i].value=="null"?"":vform.txtItemExceptionServiceDisc[i].value) + "&"; //descuento en servicios con excepci�n   
               if(vform.txtItemExceptionMinAdiCD[i] != null)urlPage = urlPage + "pstrItemMinAdiCD="         + vform.txtItemExceptionMinAdiCD[i].value + "&"; //Minutos adicionales CD
               if(vform.txtItemExceptionMinAdiIT[i] != null)urlPage = urlPage + "pstrItemMinAdiIT="         + vform.txtItemExceptionMinAdiIT[i].value + "&"; //Minutos adicionales Telefon�a
               
            }
         }else{                
               if(vform.txtItemProduct != null)urlPage = urlPage + "pstrItemDesc="             + (vform.txtItemProduct.value=="null"?"":vform.txtItemProduct.value) + "&";
               if(vform.hdnItemValuetxtItemProduct != null)urlPage = urlPage + "pstrItemId="   + vform.hdnItemValuetxtItemProduct.value + "&"; 
               if(vform.txtItemQuantity != null)urlPage = urlPage + "pstrItemQty="              + vform.txtItemQuantity.value + "&";
               if(vform.hdnItemValuetxtItemRatePlan != null)urlPage = urlPage + "pstrItemPlanId="           + fxRound(vform.hdnItemValuetxtItemRatePlan.value,0) + "&"; 
               if(vform.txtItemRatePlan != null)urlPage = urlPage + "pstrItemPlanDesc="         + vform.txtItemRatePlan.value + "&"; 
               if(vform.txtItemModality != null)urlPage = urlPage + "pstrItemSaleModality="     + vform.txtItemModality.value + "&";                
               if(vform.item_services != null)urlPage = urlPage + "pstrItemServIds="          + (vform.item_services.value=="null"?"":vform.item_services.value) + "&";
               if(vform.hdnItemValuetxtItemModality != null)urlPage = urlPage + "pstrItemSaleModality="     + vform.hdnItemValuetxtItemModality.value + "&"; 
               //Falta strPerformFlagPeriod
               //Si es que la orden ya tiene excepciones
               if(vform.txtItemExceptionRent != null)urlPage = urlPage + "pstrItemRentExc="          + vform.txtItemExceptionRent.value + "&"; //excepci�n alquiler
               if(vform.txtItemExceptionRevenue != null)urlPage = urlPage + "pstrItemRevenueExc="       + vform.txtItemExceptionRevenue.value + "&"; //excepci�n renta
               if(vform.txtItemExceptionServiceId != null)urlPage = urlPage + "pstrItemExcServiceId="     + (vform.txtItemExceptionServiceId.value=="null"?"":vform.txtItemExceptionServiceId.value) + "&"; //servicios con excepci�n
               if(vform.txtItemExceptionServiceDisc != null)urlPage = urlPage + "pstrItemExcServiceDiscnt=" +(vform.txtItemExceptionServiceDisc.value=="null"?"":vform.txtItemExceptionServiceDisc.value) + "&"; //descuento en servicios con excepci�n   
               if(vform.txtItemExceptionMinAdiCD != null)urlPage = urlPage + "pstrItemMinAdiCD="         + vform.txtItemExceptionMinAdiCD.value + "&"; //Minutos adicionales CD
               if(vform.txtItemExceptionMinAdiIT != null)urlPage = urlPage + "pstrItemMinAdiIT="         + vform.txtItemExceptionMinAdiIT.value + "&"; //Minutos adicionales Telefon�a                              
         }
         //alert(urlPage);         
         var frameUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpException.jsp"+urlPage+"type_window=NEW";               
         var winUrl = appContext+"/DYNAMICSECTION/DynamicSectionItems/DynamicSectionItemsPage/PopUpExceptionFrame.jsp?av_url="+escape(frameUrl);
         var popupWin = window.open(winUrl, "Orden_Exception","status=yes, location=0, width=900, height=500, left=50, top=100, screenX=50, screenY=100");
               
      } else
         alert("No puede agregar, cierre antes la ventana de edici�n de Items");
   }
   
   //Redondea el n�mero con la cantidad de decimales pasados como segundo par�metro.
   // Ejemplo: fxRound(34.10, 0) devuelve 34
   function fxRound(originalNumber, dec) {
      var number = parseFloat(originalNumber);
      var decimals = parseFloat(dec);
      decimals = (!decimals ? 2 : decimals);
      return Math.round(number * Math.pow(10, decimals)) / Math.pow(10, decimals);
   }