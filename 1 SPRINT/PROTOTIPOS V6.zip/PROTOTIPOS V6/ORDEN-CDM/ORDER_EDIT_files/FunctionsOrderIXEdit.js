/**
Desarrollador : Carmen Gremios
*/
/** INICIO CONSTANTES **/
   var V_INBOX_ALMACEN_DELIVERY="ALMACEN_DELIVERY";
   var V_INBOX_ALMACEN_DESPACHO="ALMACEN_DESPACHO";
   var V_ACTION_RETROCEDER = "RETROCEDER";
   var V_ACTION_AVANZAR = "AVANZAR"
   

/** FIN CONSTANTES **/

/** Inicio Seccion Rechazos */
   
function fxReloadRejects(){
   var Form = document.frmdatos;
   var table = document.all?document.all["tableRejects"]:document.getElementById("tableRejects");
   var tbody = table.getElementsByTagName("tbody")[0]; //ingreso al cuerpo de la tabla.         
   var CellMotiv,CellState,CellCreBy,CellDateC,CellSubs,CellSubBy;
   if (tbody.hasChildNodes()){                         
      for(var i=0;i<gpRejectArr.length-gIndexRejectIni;i++){                        
         CellMotiv    =  tbody.childNodes.item(i+1).childNodes.item(1);
         CellState    =  tbody.childNodes.item(i+1).childNodes.item(2);
         CellCreBy    =  tbody.childNodes.item(i+1).childNodes.item(3);
         CellDateC    =  tbody.childNodes.item(i+1).childNodes.item(4);
         CellSubs     =  tbody.childNodes.item(i+1).childNodes.item(5);
         CellSubBy    =  tbody.childNodes.item(i+1).childNodes.item(6);
         
         CellMotiv.innerHTML=gpRejectArr[i].npreason;
         CellState.innerHTML=(gpRejectArr[i].npstatus=="S")?"Subsanado":"Pendiente";
         CellCreBy.innerHTML=gpRejectArr[i].npcreatedby;
         CellDateC.innerHTML=gpRejectArr[i].npdatecreated;
         CellSubs.innerHTML =gpRejectArr[i].npmodifiedby;
         CellSubBy.innerHTML=gpRejectArr[i].mpmodifydate;
      }
      
      for(var k=0;k<gIndexRejectIni;k++){     
         row = tbody.insertRow(-1);                 
         
         col = row.insertCell(-1);
         col.className = "CellContent";               
         col.innerHTML = i+1+k;
         
         col = row.insertCell(-1);
         col.className = "CellContent";               
         col.innerHTML =  gpRejectArr[i+k].npreason; 
         
         col = row.insertCell(-1);
         col.className = "CellContent";               
         col.innerHTML =  (gpRejectArr[i+k].npstatus=="S")?"Subsanado":"Pendiente";
         
         col = row.insertCell(-1);
         col.className = "CellContent";               
         col.innerHTML =  gpRejectArr[i+k].npcreatedby; 
         
         col = row.insertCell(-1);
         col.className = "CellContent";               
         col.innerHTML =  gpRejectArr[i+k].npdatecreated;
         
         col = row.insertCell(-1);
         col.className = "CellContent";               
         col.innerHTML =  gpRejectArr[i+k].npmodifiedby;
         
         col = row.insertCell(-1);
         col.className = "CellContent";               
         col.innerHTML =  gpRejectArr[i+k].mpmodifydate;
         
         col = row.insertCell(-1);
         col.className = "CellContent";               
         col.innerHTML =  "&nbsp;";
      }
   }
   
   fxSetRejects();
}

function fxSetRejects(){
   var Form = document.frmdatos;
   var Rejects="";
   Form.hdnRejects.value="";
   for(var i=0;i<gpRejectArr.length;i++){
      Rejects+=gpRejectArr[i].nporderrejectid + "|";
      Rejects+=gpRejectArr[i].nppedidoid + "|";
      Rejects+=gpRejectArr[i].npreason + "|";
      Rejects+=gpRejectArr[i].npdescription + "|";
      Rejects+=gpRejectArr[i].npstatus + "|";
      Rejects+=gpRejectArr[i].npcreatedby + "|";
      Rejects+=gpRejectArr[i].npdatecreated + "|";
      Rejects+=gpRejectArr[i].npmodifiedby + "|";
      Rejects+=gpRejectArr[i].mpmodifydate + "|";
      Rejects+=gpRejectArr[i].npinbox+ "|";
      Rejects+=gpRejectArr[i].isModified+ "|";
   }
   Form.hdnRejects.value=Rejects;
}
      
function fxSetRejectArr(valor){
   gpRejectArr  =null;
   gpRejectArr  =new Array();
   gIndexRejectIni=valor-gIndexReject;
   gIndexReject=0;
}
      
function fxLoadRejectArr(ObjectReject){
   gpRejectArr[gIndexReject]=new fxCloneObject(ObjectReject);
   gIndexReject++;
}

function fxCloneObject(ObjectReject){
   for (var i in ObjectReject){
      this[i] = ObjectReject[i];
   }
}
/* Fin Seccion Rechazos */

/************************ INICIO DE SECCIONES DINAMICAS ********************************/    

/* ------------------------Funciones Administrador de Secciones Dinamicas------------------------------ */
var VOrderSections = null;
VOrderSections = new Vector(); 
function fxValidateSectionsforSaving(){
   var ki = 0;        
   for ( ki = 0 ; ki < VOrderSections.size() ; ki++){            
      objSection = VOrderSections.elementAt(ki);            
      if ((objSection.eventHandler != "") && (objSection.evenType == "ON_VALIDATE")){                           
         resultado  = eval(objSection.eventHandler+" == true");              
         if (resultado == false )
            return false;
      }
   }
   return true;
}
    
function fxValidateSectFinalStatByObjType(){
   var ki = 0;
   for ( ki = 0 ; ki < VOrderSections.size() ; ki++){
      objSection = VOrderSections.elementAt(ki);
      if (objSection.evenType == "ON_FINAL_STATUS"){
         resultado  = eval(objSection.eventHandler+" == true");
         if (resultado == false )
            return false;
      }
   }
   return true;
}     
/*----------- Funciones Administrador de Secciones Dinamicas ---------*/
    
/* ----------------- Inicio Billing Account --------------------------*/    
    

function fxCloneObject(ObjectReject){
   for (var i in ObjectReject){
      this[i] = ObjectReject[i];
   }
}

function fxLoadNewBillAccArr(ObjectReject){    	  
   var tam= apNewBillAcc.length;    
   apNewBillAcc[tam]=new fxCloneObject(ObjectReject);
   indBillAcc++;
}  

function fxLoadUpdBillAccArr(ObjectReject,index){    	 
   apNewBillAcc[index]=new fxCloneObject(ObjectReject); 
}     
    
function fxReloadBillAccList(customerId,siteId,cod,ind){
   var table = document.all?document.all["tableBillAcc"]:document.getElementById("tableBillAcc");
   var tbody = table.getElementsByTagName("tbody")[0]; //ingreso al cuerpo de la tabla.         
   var CellBillName,CellIconoDel;        
   
   if (cod>0){		             
      var tam= apNewBillAcc.length;                    
      row = table.insertRow(-1); 
      row.id =tam;
      
      col = row.insertCell(-1);
      col.className = "CellContent";               
      col.innerHTML = indBillAcc;
      
      col = row.insertCell(-1);
      col.className = "CellContent";               
      col.innerHTML = "<a href=javascript:fxShowDetailBA("+cod+","+customerId+","+siteId+","+tam+");>"+apNewBillAcc[tam-1].billAccName+"</a>"; 
                       		              
      col = row.insertCell(-1);
      col.className = "CellContent";    
      col.align     = "right";              
      col.innerHTML =  "<a href=javascript:fxDelete("+tam+")><img src='/websales/images/Eliminar.gif' alt='Eliminar' border='0' hspace=2></a>";
      
     // fxVerArray(tam-1);
   }else if (cod ==0){     	  
      if (tbody.hasChildNodes()){   
         var rowIndice=document.getElementById(ind).rowIndex;          	  	 
         CellBillName =  table.rows[rowIndice].cells[1];            	                      
         CellIconoDel =  table.rows[rowIndice].cells[2];           	                                 
         
         CellBillName.innerHTML="<a href=javascript:fxShowDetailBA("+apNewBillAcc[ind-1].billAccId+","+customerId+","+siteId+","+ind+");>"+apNewBillAcc[ind-1].billAccName+"</a>";
         CellIconoDel.innerHTML="<a href=javascript:fxDelete("+ind+");><img src='/websales/images/Eliminar.gif' alt='Eliminar' border='0' hspace=2></a>";
      }    
     // fxVerArray(ind-1);
   }        
}
      

    
   /* function fxVerArray(i){
    	 var variable=  "id->"+apNewBillAcc[i].billAccId +" name-->"+apNewBillAcc[i].billAccName + " "+
                      " title->"+apNewBillAcc[i].titleName +" FName->"+apNewBillAcc[i].contfName +" "+ 
                      " lName->"+apNewBillAcc[i].contlName +" Cargo->"+apNewBillAcc[i].cargo +" "+        
                      " pArea->"+apNewBillAcc[i].phoneArea +" pNumber->"+apNewBillAcc[i].phoneNumber +" "+
                      " ad1->"+apNewBillAcc[i].address1 +" ad2->"+apNewBillAcc[i].address2 +" "+ 
                      " dep->"+apNewBillAcc[i].depart +" prov->"+apNewBillAcc[i].prov +" "+
                      " dist->"+apNewBillAcc[i].dist +" zipCode->"+apNewBillAcc[i].zipCode +" "+
                      " state->"+apNewBillAcc[i].state + //" tipo->"+apNewBillAcc[i].tipo +" "+ 
                      " bscsCustId->"+apNewBillAcc[i].bscsCustId +" bscsSeq->"+apNewBillAcc[i].bscsSeq;

        alert(variable);  
    }*/
    
function fxMakeBillAccNew(billAccId,billAccName,titleName,contfName,contlName,
                     cargo,phoneArea,phoneNumber,address1,address2,
                     depart,prov,dist,zipCode,state,bscsCustId,bscsSeq){
   this.billAccId     =   billAccId;
   this.billAccName   =   billAccName;
   this.titleName     =   titleName;
   this.contfName     =   contfName;
   this.contlName     =   contlName;
   this.cargo         =   cargo;
   this.phoneArea     =   phoneArea;
   this.phoneNumber   =   phoneNumber;
   this.address1      =   address1;
   this.address2      =   address2;        
   this.depart        =   depart;
   this.prov          =   prov;
   this.dist          =   dist;
   this.zipCode       =   zipCode;    
   this.state         =   state;    
   //this.tipo          =   tipo;  
   this.bscsCustId    =   bscsCustId;
   this.bscsSeq       =   bscsSeq;     
}
  

function fxRenumeric(tablename,count){    
   eval("var table = document.all?document.all['"+tablename+"']:document.getElementById('"+tablename+"');");       
   var CellIndex;                         
   for(var i=1;i<=count;i++){              
      CellIndex =  table.rows[i].cells[0];  	  
      CellIndex.innerHTML= i;
   }
}  
/*---------------------- fin de Billing Account -----------------------*/

/*---------------------- Inicio de Responsables de Pago -----------------------*/



/*---------------------- fin de Responsables de Pago -----------------------*/


/************************ FIN DE SECCIONES DINAMICAS ********************************/


/*---------------------- Inicio Back Request --------------------------*/


 
/*---------------------- Fin Back Request --------------------------*/
/**/
//Inbox

/* function fxCambiarInbox(valor,specId){  
   alert(" valor-->"+valor+" specId-->"+specId);
   var Form = document.frmdatos;
   if (valor=='RETROCEDER'){    
      idRegionInboxBack.style.display='';                 
      idRegionInboxNext.style.display='none';    
      Form.cmbInboxBack.value="";
   }else if (valor=='SALTAR'){    
      idRegionInboxBack.style.display='none';        
      idRegionInboxNext.style.display='';
      DeleteSelectOptions(Form.cmbInboxNext);               
      var opcion=new Option('','');
      if (specId==2015){  
         opcion=new Option('EDICION','EDICION');
         Form.cmbInboxNext.options[1]=opcion;
         opcion=new Option('CREDITOS','CREDITOS');
         Form.cmbInboxNext.options[2]=opcion;      
         opcion=new Option('ADM_VENTAS','ADM_VENTAS');
         Form.cmbInboxNext.options[3]=opcion;      
         opcion=new Option('CERRADO','CERRADO');
         Form.cmbInboxNext.options[4]=opcion;    
         Form.cmbInboxNext.value="";
      }
      if (specId==2013){  
         opcion=new Option('BACKOFFICE','BACKOFFICE');
         Form.cmbInboxNext.options[1]=opcion;
         opcion=new Option('CALLCENTER','CALLCENTER');
         Form.cmbInboxNext.options[2]=opcion;      
         opcion=new Option('ACTIVACION/PROGRAMC','ACTIVACION/PROGRAMC');
         Form.cmbInboxNext.options[3]=opcion;      
         opcion=new Option('CERRADO','CERRADO');
         Form.cmbInboxNext.options[4]=opcion; 
         Form.cmbInboxNext.value="";
      }
      if (specId==2024){  
         opcion=new Option('CALLCENTER','CALLCENTER');
         Form.cmbInboxNext.options[1]=opcion;
         opcion=new Option('ACTIVACION/PROGRAMC','ACTIVACION/PROGRAMC');
         Form.cmbInboxNext.options[2]=opcion;      
         opcion=new Option('CERRADO','CERRADO');
         Form.cmbInboxNext.options[3]=opcion;   
         Form.cmbInboxNext.value="";
      }         
   }else 
   { 
      DeleteSelectOptions(Form.cmbInboxNext);     
      idRegionInboxBack.style.display='none';        
      idRegionInboxNext.style.display='none';           
   }
   //alert("al salir");
   //return;
 }*/
//Fin Inbox
/*
//Generacion de Comprobantes
function fxGenerarComprobantes(){
   var form = document.frmdatos;
   var wn_lugardespacho = form.cmbLugarAtencion.value;
   var wv_tipodespacho;
   form.btnGenerarComprobantes.disabled = true;
   for (i=1; i < workflowArr.length ; i++) {
      subjObj = workflowArr[i];
      if (subjObj.atentionid == wn_lugardespacho) {
         wv_tipodespacho = subjObj.vtype;
      };
   };
   //a = "/portal/pls/portal/WEBCCARE.NPAC_ORDER_EDIT_PL_PKG.PL_DOCUMENT_GENERATION?an_pedidoid="+wn_nxpedidoid+"&an_lugardespacho="+wn_lugardespacho+"&av_tipodespacho="+wv_tipodespacho;
   parent.bottomFrame.location.replace(a);
};
*/

//Validando

function fxValidateSave(){   
   form = document.frmdatos;     
   //if (form.flgSave.value=="1"){ return ; }   
   
   //var wn_cantServ            = vItemsBorrado.size();
   var wv_item_id             = "";
   var wv_fecha_firma         = "";
   var wv_hora_firma          = "";
   var wv_fecha_entrega       = "";
   var wv_hora_entrega        = "";
   
   try{
      wv_fecha_firma         = form.txtFechaHoraFirma.value.substring(0,10);      
      wv_hora_firma          = form.txtFechaHoraFirma.value.substring(11,16);   
   }catch(e){}
   
   try{
      wv_fecha_entrega       = form.txtFechaHoraEntrega.value.substring(0,10);
      wv_hora_entrega        = form.txtFechaHoraEntrega.value.substring(11,16);   
   }catch(e){}

    /** HTENORIO COR1108**/
    /** Comments: Variables innecesarios**/         
   /*var wv_fecha_proceso_autom = "";
   
   try{
      wv_fecha_proceso_autom = form.txtFechaProceso.value.substring(0,10);
   }catch(e){}*/
   
   var wn_decrip_long;
   
   try{
   /* Verificacion del campo Fecha Hora Firma */
      if (form.txtEstadoOrden.value == "TIENDA01" || form.txtEstadoOrden.value == "ADM_VENTAS" || form.txtEstadoOrden.value == "CALLCENTER FF" || form.txtEstadoOrden.value == "BACKOFFICE") {
         if (form.txtFechaHoraFirma.value == ""){
            alert("Debe ingresar la fecha y hora de firma");         
            form.txtFechaHoraFirma.select();
            return false;
         };
      };      
      
      if (form.txtFechaHoraFirma.value != ""){        
         if (!isValidDate(wv_fecha_firma) || !isValidHour(wv_hora_firma) ){
            form.txtFechaHoraFirma.select();
            return false;
         };
      };
   }catch(e){}
   
   /* Validaci�n de la Descripci�n */
   wn_decrip_long = form.txtDetalle.value.length;
   if ( wn_decrip_long > 4000) {
      alert("El campo 'Descripci�n' tiene " + wn_decrip_long +" letras y es mayor que el maximo permitido (4000). Disminuya la"+
      " cantidad de letras o guarde una parte de esta como Notas.");
      form.txtDetalle.select();
      return false;
   }
    /** HTENORIO COR1108**/
    /** Comments: Esta validacion de fecha de programacion automatica se realizara en JP_ORDER_EDIT_ORDER_ShowPage**/         
   /*try{
      if (form.txtFechaProceso.value!=""){
         if (fxCheckDate(form.txtFechaProceso)!=true)
            return false;
      };
   }catch(e){}*/
   
   if (form.cmbAction.value.toUpperCase()!= V_ACTION_RETROCEDER ){  // ----  AGREGADO TMOGROVEJO FIN 29/09/2008
      /* Validamos que se seleccione un vendedor */   
      if (form.cmbVendedor.value == "" ){
         alert("Debe seleccionar un Vendedor");
         form.cmbVendedor.focus();
         return false;
      }else{
         form.hdnVendedor.value = form.cmbVendedor.value;
         form.txtVendedor.value = form.cmbVendedor.options[form.cmbVendedor.selectedIndex].text; 
      };
      
      /* Inicio Data */
       try{
        if (form.hdnDataFieldsVisibles.value == "S"){
          form.hdncmbVendedorData.value    = form.cmbVendedorData.options[form.cmbVendedorData.selectedIndex].text;
          form.hdnVendedorDataId.value    = form.cmbVendedorData.options[form.cmbVendedorData.selectedIndex].value;
          if (form.hdnVendedorDataId.value == ""){
            alert("El Vendedor Data es obligatorio");
            form.cmbVendedorData.focus();
            return false;
          }
        }
      }catch(e){}
      /* Fin Data */
      
   };   
   
   
   try{   
      /* Verificacion del campo Fecha Hora Entrega */   
      if (form.txtEstadoOrden.value == V_INBOX_ALMACEN_DELIVERY && form.hdnAction.value.toUpperCase() == V_ACTION_AVANZAR ){
        if (form.txtFechaHoraEntrega.value==""){
         alert("Debe ingresar la fecha y hora de entrega");                 
         form.txtFechaHoraEntrega.select();
         return false;
        }
      }   

      if (form.txtFechaHoraEntrega.value != ""){      
         if (!isValidDate(wv_fecha_entrega) || !isValidHour(wv_hora_entrega) ){
            form.txtFechaHoraEntrega.select();
            return false;
         };
         if (!fxCheckDate2(wv_fecha_entrega)){
            form.txtFechaHoraEntrega.select();
            return false;
        }
      };    
   }catch(e){}
   
   /* Verificaci�n del transportista */   
   if (form.txtEstadoOrden.value == V_INBOX_ALMACEN_DESPACHO || form.txtEstadoOrden.value == V_INBOX_ALMACEN_DELIVERY){ //ALMACEN_DELIVERY   
      if (form.cmbTransportista.disabled!=true ){
         if (form.cmbTransportista.value == "" || form.cmbTransportista.value == "0" ){
            alert("Debe ingresar el transportista");
            form.cmbTransportista.focus();
            return false;
         }   
      }
   }

   try{
      if (idRegionInboxNext.style.display=="" && form.cmbInboxNext.value=="" ){         
         form.cmbInboxNext.focus();         
         return false;
      }      
   }catch(e) {      
   }    
   fxSetRejects();   
   /*if (form.flgSave.value   == "1"){
      return false;
   }   */
   return true;
};
    
function fxDeleteRowsOfTable(nameTable){
   //alert("fxDeleteRowsOfTable nameTable -->"+nameTable);
   var table = document.all ? document.all[nameTable]:document.getElementById(nameTable);   
   var longitud=table.rows.length;
   //alert("fxDeleteRowsOfTable longitud -->"+longitud);
   for(var i=0; i<longitud;i++){   
      table.deleteRow(0);
   }
}

// SECCIONES DINAMICAS

var codPostal = new Array();  
var aCodDpto = new Array();
var aCodProv = new Array();
var aCodDist = new Array();
  
/*************************** INICIO MIGRACION FUNCTIONORDEREDIT.js ************************/
var workflowArr = new Array();
function fxMakeWorkflow(atentionid,workflow,vtype) {
   this.atentionid   = atentionid;
   this.workflow     = workflow;
   this.vtype        = vtype;
};

function fxCreateReject(nporderrejectid,nppedidoid,npreason,npdescription,npstatus,npcreatedby,npdatecreated,npmodifiedby,mpmodifydate,npinbox){
   this.nporderrejectid =nporderrejectid;
   this.nppedidoid      =nppedidoid;
   this.npreason        =npreason;
   this.npdescription   =npdescription;
   this.npstatus        =npstatus;
   this.npcreatedby     =npcreatedby;
   this.npdatecreated   =npdatecreated;
   this.npmodifiedby    =npmodifiedby;
   this.mpmodifydate    =mpmodifydate;
   this.npinbox         =npinbox;
   this.isModified      ="false";
}

/*function fxValidarFormaPago(objThis){
   var form = document.frmdatos;
   var forma_pago = objThis.value;
   if (forma_pago != ""){
      var tipo_LugarDespacho = fxGetTypeDespacho(form.cmbLugarAtencion.value);
      if (forma_pago == "Diferido" && tipo_LugarDespacho != "Fulfillment" && form.cmbLugarAtencion.value != ""){
         form.cmbFormaPago.value = "";
         alert("Esta forma de pago no esta disponible para Tienda");
         return;
      };
      
      if (forma_pago == "Descuento por Planilla" && wv_swtype != "Employee"){
         form.cmbFormaPago.value = ""; 
         alert("Esta forma de pago s�lo es disponible para empleados");
         return;
     };
   };
   form.hdnFormaPagoOrig.value = form.cmbFormaPago.value;
}

function fxGetTypeDespacho(lugar_despacho){
   for (i=1; i < workflowArr.length ; i++) {
      subjObj = workflowArr[i];
      if (subjObj.atentionid == lugar_despacho) {
         return subjObj.vtype;
      };
   };
}*/

function fxMuestraHelpFechaHora(){
   alert("Ejemplo de formato Fecha Hora Firma: 14/07/2004 16:05");
};

function fxCheckDate(obj) {
   var wv_datestr = obj.value;
   var wv_hoy_str = new Date();
   var day_act    = parseFloat(wv_hoy_str.getDate());
   var month_act  = parseFloat(wv_hoy_str.getMonth()+1);
   var year_act   = parseFloat(wv_hoy_str.getYear());
   
   var wv_message = "La fecha debe ser mayor o igual a la fecha actual";
   
   if ( wv_datestr != "" ){
      if ( !isValidDate(wv_datestr)){
         obj.select();
         return;
      };
   
      var day_new    = parseFloat(wv_datestr.substring(0,2));
      var month_new  = parseFloat(wv_datestr.substring(3,5));
      var year_new   = parseFloat(wv_datestr.substring(6,10));
      if (year_new < year_act){
         alert(wv_message);
         obj.select();
         return;
      };
      if (year_new == year_act){
         if (month_new < month_act){
            alert(wv_message);
            obj.select();
            return;
         };
         if (month_new == month_act){
            if (day_new < day_act){
               alert(wv_message);
               obj.select();
               return;
            };
         }
      }
   }
   return true;
};

function fxCheckDate2(obj) {
   var wv_datestr = obj;
   var wv_hoy_str = new Date();
   
   var day_act    = parseFloat(wv_hoy_str.getDate());
   var month_act  = parseFloat(wv_hoy_str.getMonth()+1);
   var year_act   = parseFloat(wv_hoy_str.getYear());
   
   var wv_message = "La fecha debe ser menor o igual a la fecha actual";
   
   if ( wv_datestr != "" ){
      if ( !isValidDate(wv_datestr)){
        return false;
      };
   
      var day_new    = parseFloat(wv_datestr.substring(0,2));
      var month_new  = parseFloat(wv_datestr.substring(3,5));
      var year_new   = parseFloat(wv_datestr.substring(6,10));
      if (year_new > year_act){
         alert(wv_message);
         return false;
      };
      if (year_new == year_act){
         if (month_new > month_act){
            alert(wv_message);
            return false;
         };
         if (month_new == month_act){
            if (day_new > day_act){
               alert(wv_message);
               return false;
            };
         }
      }
   }
   return true;
};

function fxCheckDateHour(obj) {
   var wv_datestr = obj.value;
   var wv_hoy_str = new Date();
   var day_act    = parseFloat(wv_hoy_str.getDate());
   var month_act  = parseFloat(wv_hoy_str.getMonth()+1);
   var year_act   = parseFloat(wv_hoy_str.getYear());
   var hour_act   = parseFloat(wv_hoy_str.getHours());
   var min_act    = parseFloat(wv_hoy_str.getMinutes());

   var wv_fecha         = wv_datestr.substring(0,10);      
   var wv_hora          = wv_datestr.substring(11,16);     
   
   var wv_message = "La fecha debe ser mayor o igual a la fecha actual";
   
   if ( wv_datestr != "" ){
      if ( !isValidDate(wv_fecha) || !isValidHour(wv_hora) ){
         obj.select();
         return;
      };
   
      var day_new     = parseFloat(wv_fecha.substring(0,2));
      var month_new   = parseFloat(wv_fecha.substring(3,5));
      var year_new    = parseFloat(wv_fecha.substring(6,10));
      var hour_new    = parseFloat(wv_hora.substring(0,2));
      var minute_new  = parseFloat(wv_hora.substring(3,6));

      if (year_new < year_act){
         alert(wv_message);
         obj.select();
         return;
      };
      if (year_new == year_act){
         if (month_new < month_act){
            alert(wv_message);
            obj.select();
            return;
         };
         if (month_new == month_act){
            if (day_new < day_act){
               alert(wv_message);
               obj.select();
               return;
            };
            if(hour_act < hour_new){
               alert(wv_message);
               obj.select();
               return;            
            };
            if(hour_act == hour_new){
               if(minute_new < min_act){
                  alert(wv_message);
                  obj.select();
                  return;
               };
            }
         }
      }
   }
   return true;
};

function getCustomerDetail(){
   form = document.frmdatos;
   customerId = form.txtCompanyId.value;
   if (customerId==""){
      alert("Primero debe ingresar el nombre de la empresa");
      return;
   }
   url = "/portal/page/portal/nextel/CUST_DETAIL?customerId=" + customerId;
   url = "/portal/pls/portal/WEBSALES.NPSL_GENERAL_PL_PKG.WINDOW_FRAME?av_title="+escape("PORTAL NEXTEL")+"&av_url="+escape(url);
   window.open(url,"WinCustomer","toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,screenX=60,top=40,left=60,screenY=40,width=850,height=600");
   return;
}
/*************************** FIN MIGRACION FUNCTIONORDEREDIT.js ************************/      
      
function fxShowMessage(strMessage){
   form = document.frmdatos;
   alert(strMessage);
}   
   
/** HTENORIO COR1108**/
/** Comments: Nueva funcion, enviando la fecha del sistema del servidor, generado desde un jsp**/      
function fxCheckServerDate(obj, av_hoy_str) {
   var wv_datestr = obj.value;
   var wv_hoy_str = av_hoy_str;
   var day_act    = parseFloat(wv_hoy_str.getDate());
   var month_act  = parseFloat(wv_hoy_str.getMonth()+1);
   var year_act   = parseFloat(wv_hoy_str.getYear());
   
   var wv_message = "La fecha debe ser mayor o igual a la fecha actual";
   
   if ( wv_datestr != "" ){
      if ( !isValidDate(wv_datestr)){
         obj.select();
         return;
      };
   
      var day_new    = parseFloat(wv_datestr.substring(0,2));
      var month_new  = parseFloat(wv_datestr.substring(3,5));
      var year_new   = parseFloat(wv_datestr.substring(6,10));
      if (year_new < year_act){
         alert(wv_message);
         obj.select();
         return;
      };
      if (year_new == year_act){
         if (month_new < month_act){
            alert(wv_message);
            obj.select();
            return;
         };
         if (month_new == month_act){
            if (day_new < day_act){
               alert(wv_message);
               obj.select();
               return;
            };
         }
      }
   }
   return true;
};
   
      function fxImeiBorraEdit(){
         if (document.frmdatos.txtNumeroGuia.value != ""){
            alert("La gu�a ya fue generada. No puede borrar el SIM/IMEI.");
            return;
         };

         var table = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
         if (table.rows.length < 2){
            alert("No se puede realizar la acci�n");
            return; };

         if (table.rows.length > 2 && (form.item_imei_imei[form.hdn_item_imei_selecc.value].value =="" && form.item_imei_sim[form.hdn_item_imei_selecc.value].value =="")){
            alert("No se puede realizar la acci�n, SIM/IMEI vacio");
            return; };

         if (table.rows.length == 2 && (form.item_imei_imei.value =="" && form.item_imei_sim.value=="")){
            alert("No se puede realizar la acci�n, SIM/IMEI vacio");
            return false; };

         if (confirm("Desea borrar el IMEI de este item?")){
            if (form.hdn_item_imei_selecc.value == ""){
               alert("Seleccione un item");}
            else{
               try{
                  parent.mainFrame.document.frmdatos.hdnChangedOrder.value="S";
               }catch(e){;}
               if (table.rows.length > 2){
                  form.item_imei_imei[form.hdn_item_imei_selecc.value].value = "";
                  form.item_imei_sim[form.hdn_item_imei_selecc.value].value = "";
                  form.item_imei_check[form.hdn_item_imei_selecc.value].value = "N"; 
               }
               else{
                  form.item_imei_imei.value = "";
                  form.item_imei_sim.value = "";
                  form.item_imei_check.value = "N"; 
               }
            }
         }

         form.hdnFlagItemImeis.value = "1";
      };

  /*JOYOLAR 07/08/2008 */

 function fCopyCodBSCSEdit(){
 	var form = document.frmdatos;
   if (form.hdnCodBscsDetail.value != ""){
     var txt_CodBSCSDetail = form.hdnCodBscsDetail.value;
     window.clipboardData.setData("Text",txt_CodBSCSDetail);
	   return;
	 };
 };
 
 function fxCopyListaSIM() {

    table2 = document.all ? document.all["table_imeis"]:document.getElementById("table_imeis");
    table = document.all ? document.all["tableImeisAux"]:document.getElementById("tableImeisAux");
    var elmTBODY = document.getElementById("CuerpoTabla");
    var elmTR;
    var elmTD;
    var elmText;
    var j=0;
    var sim=""; //CEM
    var imei="";
	
    if (table2.rows.length < 2){			
      alert("No se puede realizar la acci�n");
      return;
    };
    	
    if (document.all) {
      if (table2.rows.length > 2){				
         //sim="SIM"+"\n";
			sim="IMEI"+"\t"+"SIM"+"\n";
         for(i=0 ; i< (table2.rows.length - 1) ; i++){
            //if (form.item_imei_sim[i].value != ""){
               var row = table.insertRow(-1);
               var cell = row.insertCell(j);
               elmText = form.item_imei_sim[i].value;
               //sim=sim+form.item_imei_sim[i].value+"\n";
               //sim=sim+form.item_imei_sim[i].value+"\t"+form.item_imei_imei[i].value+"\n";
					sim=sim+form.item_imei_imei[i].value+"\t"+form.item_imei_sim[i].value+"\n";
               cell.innerHTML = elmText;
            //};
         };
      };
      else {
         if (table2.rows.length == 2){			      
            //if (form.item_imei_sim.value != ""){
               var row = table.insertRow(-1);
               var cell = row.insertCell(j);
               elmText = form.item_imei_sim.value;
               //sim="SIM"+"\n";
					sim="IMEI"+"\t"+"SIM"+"\n";
               //sim=sim+form.item_imei_sim.value+"\n";
               //sim=sim+form.item_imei_sim.value+"\t"+form.item_imei_imei.value+"\n";
					sim=sim+form.item_imei_imei.value+"\t"+form.item_imei_sim.value+"\n";
               cell.innerHTML = elmText;
            //};
         };
      };
    }
    
    event.returnValue = false;
    //window.clipboardData.setData("Text",divDataImeis.innerHTML);
    window.clipboardData.setData("Text",sim); //CEM		 
    alert("Data copiada exit�samente!");		 
    /* Limpiamos la tabla aux */
    var longuitud = table.rows.length - 1;
    for(i= longuitud ; i>=0 ; i--){
       table.deleteRow(i);
    }
    return;         
}
 