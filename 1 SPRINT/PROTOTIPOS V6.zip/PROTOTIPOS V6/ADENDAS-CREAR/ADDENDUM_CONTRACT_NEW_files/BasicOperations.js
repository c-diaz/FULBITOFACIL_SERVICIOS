/*
   Developer: Fabio Alarc�n
*/
   var agt=navigator.userAgent.toLowerCase();
   var major = parseInt(navigator.appVersion);
   var minor = parseFloat(navigator.appVersion);
   var isNetscape = (
   (agt.indexOf("mozilla")!=-1) &&
   (agt.indexOf("spoofer")==-1) &&
   (agt.indexOf("compatible") == -1) &&
   (agt.indexOf(";nav") != -1)
   );
   var isExplorer = (agt.indexOf("msie") != -1);

   // Elimina los items(options) de un objeto "Select"
   function DeleteSelectOptions(thecmb){
	  if (thecmb != null){
      	var selLength = thecmb.length;
      	if (selLength>0){
        	for (var j=1;j<selLength;j++){
            	if (isExplorer == true)
                	thecmb.remove(selLength - j);
           		else 
               		thecmb.options[selLength-j]=null;
         	}
      	}
	  }
   }
   
   // Agrega un item en un objeto "Select"
   function AddNewOption(TheCmb, Value, Description) {
      var option = new Option(Description, Value);
      var i = TheCmb.options.length;
      TheCmb.options[i] = option;
   }

   // Elimina un item en un objeto "Select" dada el �ndice respectivo
   function DeleteAnOption(TheCmb, ItemId) {
      if ( (ItemId >= 0) && (ItemId < TheCmb.length) ) {
         if (isExplorer == true)
            TheCmb.remove(ItemId);
         else 
            TheCmb.options[ItemId]=null;
      }
   }
   
   // Pone por defecto un item dado(Value) en un objeto "Select"
   function SetCmbDefaultValue(TheCmb, DefaultValue) {
      var cmbLength = TheCmb.length;
      for (var j=0; j<cmbLength; j++) {
         if ( TheCmb.options[j].value == DefaultValue ) {
            TheCmb.options[j].selected=true;
         }
      }
   }

   // Pone por defecto un item dado(Text) en un objeto "Select"
   function SetCmbDefaultText(TheCmb, DefaultTextValue) {
      var cmbLength = TheCmb.length;
      for (var j=0; j<cmbLength; j++) {
         if ( TheCmb.options[j].text == DefaultTextValue ) {
            TheCmb.options[j].selected=true;
         }
      }
   }
   
   
   // Pone un "check" en un objeto "CheckBox"
   function SetChkBoxChecked(TheCheckBox, DefaultValue) {
      if (TheCheckBox.value == DefaultValue) {
         TheCheckBox.checked = true;
      }
   }
   
   // Selecciona una "option" en un objeto "Radio"
   function SetRadioOptionSelected(TheRadio, DefaultValue) {
      var radioLength = TheRadio.length;
      for (var j = 0; j < radioLength; j++) {
         if ( TheRadio[j].value == DefaultValue ) {
            TheRadio[j].checked = true;
            break;
         }
      }
   }

   // Verifica si objeto "Radio" tiene "option" seleccionada
   function isRadioChecked(TheRadio) {
      var ret_value = false;
      var radioLength = TheRadio.length;
      for (var j = 0; j < radioLength; j++) {
         if ( TheRadio[j].checked) {
            ret_value = true;
            break;
         }
      }
      return ret_value;
   }
   
   // Elimina los espacios en blanco por la izquierda y derecha
   function trim(str) {
      var cadena = "";
      if (str!="") {
         for(var i = 0 ; i<str.length && str.charAt(i)==" " ; i++ ) ;
         cadena = str.substring(i,str.length);
         for(var i = cadena.length-1 ; i >=0 && cadena.charAt(i)==" " ; i-- ) ;
         cadena = cadena.substring(0,i+1);
      }
      return cadena;
   }
   
   

   //  Verifica si valor dado existe en objecto "Select"
   function CheckSelectItemExistance(TheCmb, Value) {
      var retValue = "";
      var cmbLength = TheCmb.length;
      for (var j = 0; j < cmbLength; j++) {
         if ( TheCmb.options[j].value == Value ) {
            retValue = TheCmb.options[j].value;
            break;
         }
      }
      return retValue!=""?true:false;
   }
   
   //  Obtiene el indice de un valor dado en objecto "Select", si indice no existe, el valor no existe, retorna -1
   function GetSelectItemIndex(TheCmb, Value) {
      var retValue = -1;
      var cmbLength = TheCmb.length;
      for (var j = 0; j < cmbLength; j++) {
         if ( TheCmb.options[j].value == Value ) {
            retValue = j;
            break;
         }
      }
      return retValue;
   }

   
   /* 
      Estas dos funciones tienen una equivalente, por lo tanto debe evitarse su uso.
      Usar: DeleteSelectOptions(thecmb) en su reeemplazo
   */
   
   // Elimina los items de un objeto "Select" (En Netscape)
   function deleteOptionNS(thecmb){
     var selLength = thecmb.length;
     if (selLength>0){
       for (var j=1;j<selLength;j++){
         thecmb.options[selLength-j]=null;
       }
       //history.go(0);
     }
   }

   // Elimina los items de un objeto "Select" (En Explorer)
   function deleteOptionIE(thecmb){
     var selLength = thecmb.length;
     if (selLength>0){
       for (var j=1;j<selLength;j++){
         thecmb.remove(selLength - j);
       }
     }
   }


    //jgalindo 
   // Elimina TODOS los items(options) de un objeto "Select"
   function DeleteAllSelectOptions(thecmb){
      var selLength = thecmb.length;
      if (selLength>0){
         for (var j=1;j<=selLength;j++){
            if (isExplorer == true)
               thecmb.remove(selLength - j);
            else 
               thecmb.options[selLength-j]=null;
         }
      }
   }




   function isDateFieldValid(dateField) {
      dateStr = dateField.value; // Fecha est� en formato DD/MM/YYYY
       if ( dateStr == "" ) return true;
           if ( !isValidDate(dateStr) ) {
              dateField.focus();
              dateField.select();
              return false;
        }
         return true;
   }

   //Redondea el n�mero con la cantidad de decimales pasados como segundo par�metro.
   // Ejemplo: fxRound(34.10, 0) devuelve 34
   function fxRound(originalNumber, dec) {
      var number = parseFloat(originalNumber);
      var decimals = parseFloat(dec);
      decimals = (!decimals ? 2 : decimals);
      return Math.round(number * Math.pow(10, decimals)) / Math.pow(10, decimals);
   } 

   //Coloca los campos de un formulario a modo de solo lectura   
   function fxPutFieldReadOnly(form) {
	 for (var i=0;i<form.elements.length;i++){
		form.elements[i].disabled=true;
	 }
   } 

   function fxHideElement(tableOcultar) {       
      if (document.getElementById) { // DOM3 = IE5, NS6 
         document.getElementById(tableOcultar).style.visibility = 'hidden'; 
      }                       
   } 
   
   function fxShowElement(tableMostrar) { 
      if (document.getElementById) { // DOM3 = IE5, NS6 
         document.getElementById(tableMostrar).style.visibility = 'visible'; 
      }
   }